"""Tests for the v7 fix pass (2.6.11): script hygiene, version and document consistency."""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_sourced_shell_files_declare_their_shell():
    for rel in ("scripts/_lib.sh", "scripts/env.example.sh"):
        head = "\n".join(_read(rel).splitlines()[:2])
        assert "bash" in head, rel


def test_no_stale_create_policy_wording():
    assert "create-policy" not in _read("scripts/01_azure_setup.sh")


def test_synapse_identity_failure_reaches_the_friendly_message():
    text = _read("scripts/01_azure_setup.sh")
    assert 'mi="$(synapse_mi)" || true' in text


def test_secret_scope_match_is_literal():
    assert 'grep -Fq' in _read("scripts/02_databricks_cli_setup.sh")


def test_render_sql_message_matches_the_rule_for_urls():
    sys.path.insert(0, str(ROOT / "scripts"))
    import render_sql
    try:
        render_sql.render("${BRIDGE_JDBC_URL}", {"BRIDGE_JDBC_URL": "jdbc:sqlserver://h;db=x'"})
    except ValueError as exc:
        assert "semicolon" not in str(exc)
    else:
        raise AssertionError("quote in a JDBC URL must be rejected")
    assert render_sql.render("${BRIDGE_JDBC_URL}", {"BRIDGE_JDBC_URL": "jdbc:sqlserver://h;db=x"}) == "jdbc:sqlserver://h;db=x"
    try:
        render_sql.render("${X}", {"X": "a;b"})
    except ValueError as exc:
        assert "semicolon" in str(exc)
    else:
        raise AssertionError("semicolon must be rejected for ordinary values")


def test_release_validation_states_a_real_test_count():
    text = _read("docs/RELEASE_VALIDATION.md")
    assert "TESTCOUNT" not in text
    claimed = int(re.search(r"\*\*(\d+) passed", text).group(1))
    defined = sum(len(re.findall(r"^\s*def test_", p.read_text(encoding="utf-8"), re.M))
                  for p in (ROOT / "tests").glob("test_*.py"))
    assert claimed >= defined  # parametrised tests make the run larger than the def count


def test_review_findings_has_no_stale_claims():
    text = _read("docs/REVIEW_FINDINGS.md")
    assert "can never print" not in text


def test_agents_doc_calls_the_old_system_legacy():
    text = _read("AGENTS.md")
    assert not re.search(r"(?<!legacy-)\bv6\b", text)


def test_version_tag_follows_init():
    version = re.search(r'__version__ = "([^"]+)"', _read("src/bridge/__init__.py")).group(1)
    assert f"version: {version}" in _read("databricks.yml")
    for rel in ("docs/DATA_DICTIONARY.md", "docs/CODE_STRUCTURE.md", "docs/PACKAGE_GUIDE.md"):
        assert f"(v{version})" in _read(rel).splitlines()[0], rel
    assert f"(v{version})" in _read("docs/RELEASE_VALIDATION.md")
