from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


def test_prod_requires_manual_approval_and_acceptance_evidence():
    source = (ROOT / ".github/workflows/ci-cd.yml").read_text()
    workflow = yaml.safe_load(source)
    condition = workflow["jobs"]["deploy-prod"]["if"]
    assert "workflow_dispatch" in condition
    assert "dev_acceptance_evidence != ''" in condition
    assert "push" not in condition
    assert "github.ref == 'refs/heads/main'" in condition


def test_deploy_uses_protected_environment():
    source = (ROOT / ".github/workflows/bundle-deploy.yml").read_text()
    assert "environment: ${{ inputs.environment }}" in source
    assert "databricks bundle validate" in source
    assert "databricks bundle deploy" in source


def test_primary_guide_has_order_and_manual_boundaries():
    guide = (ROOT / "docs/START_HERE_COMPLETE_SETUP.md").read_text()
    for phrase in (
        "Synapse administrator", "UC service credential", "JDBC connection",
        "GitHub", "acceptance", "11:00", "PROD",
        "dev_acceptance_evidence", "BUNDLE_VAR_job_identity",
    ):
        assert phrase in guide
