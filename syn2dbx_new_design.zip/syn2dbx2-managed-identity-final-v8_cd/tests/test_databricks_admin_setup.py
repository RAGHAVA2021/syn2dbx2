"""Basic offline safety checks for the administrator-only setup helper."""
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "databricks_admin_setup", ROOT / "tools" / "databricks_admin_setup.py"
)
setup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(setup)


def test_setup_refuses_non_config_path():
    with pytest.raises(ValueError):
        setup.config_path("../secrets.json")


def test_synapse_sql_replacements_and_login():
    doc = {"staging": {"root": "abfss://staging@storageacct.dfs.core.windows.net"}}
    sql = setup.synapse_setup_sql(doc, "mi-bridge-dev", "dbo")
    assert "N'mi-bridge-dev'" in sql
    assert "N'staging'" in sql
    assert "N'storageacct'" in sql
    assert "N'dbo'" in sql
    assert "<synapse-login-identity>" not in sql


def test_synapse_sql_rejects_injection():
    doc = {"staging": {"root": "abfss://staging@storageacct.dfs.core.windows.net"}}
    with pytest.raises(ValueError):
        setup.synapse_setup_sql(doc, "x'; DROP USER y;--", "dbo")


def test_dry_run_synapse_does_not_open_connection():
    assert "DRY RUN" in setup.apply_synapse_sql(None, None, {}, "SELECT 1", False)


def test_synapse_ddl_refuses_nightly_managed_identity():
    with pytest.raises(PermissionError, match="Synapse administrator"):
        setup.apply_synapse_sql(None, None, {}, "SELECT 1", True)


def test_synapse_setup_requires_preexisting_master_key():
    doc = {"staging": {"root": "abfss://staging@storageacct.dfs.core.windows.net"}}
    sql = setup.synapse_setup_sql(doc, "mi-bridge-dev", "dbo")
    assert "Database master key missing" in sql
    assert "EXEC (N'CREATE MASTER KEY')" not in sql


def test_dry_run_uc_does_not_execute():
    result = setup.apply_uc_sql(None, "CREATE SCHEMA IF NOT EXISTS c.s;\n", False)
    assert result["executed"] == 0
