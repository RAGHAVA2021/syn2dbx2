import copy
import json
import os
import sys
import time
from pathlib import Path

import pytest

# Spark's collect() returns naive datetimes in the process time zone; pin it so the suite
# gives the same result on a laptop in Sydney as on the UTC CI runner.
os.environ["TZ"] = "UTC"
if hasattr(time, "tzset"):
    time.tzset()

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tools"))


@pytest.fixture
def inventory():
    return copy.deepcopy(json.loads((ROOT / "config" / "inventory.example.json").read_text()))
