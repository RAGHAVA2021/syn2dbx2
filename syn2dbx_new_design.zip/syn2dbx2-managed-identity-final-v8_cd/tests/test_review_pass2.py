"""Second review pass: variable documentation, env-file consistency and doc/config sync."""
import importlib.util
import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def _load(rel, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_every_env_variable_has_a_purpose_comment():
    lines = (ROOT / "scripts" / "env.example.sh").read_text().splitlines()
    missing = []
    for i, line in enumerate(lines):
        if line.startswith("export BRIDGE_"):
            prev = lines[i - 1].strip() if i else ""
            if not prev.startswith("#"):
                missing.append(line.split("=")[0])
    assert not missing, missing


def test_bundle_variables_have_descriptions():
    doc = yaml.safe_load((ROOT / "databricks.yml").read_text())
    missing = [k for k, v in doc["variables"].items() if not (v or {}).get("description")]
    assert not missing, missing


def _leaf_paths(obj, prefix=""):
    for k, v in obj.items():
        if k == "_comments":
            continue
        path = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            yield from _leaf_paths(v, path)
        else:
            yield path


def test_settings_example_documents_every_leaf_key():
    doc = json.loads((ROOT / "config" / "settings.example.json").read_text())
    comments = doc["_comments"]
    missing = [p for p in _leaf_paths(doc) if p not in comments
               and not any(p.startswith(c + ".") for c in comments)]
    assert not missing, missing


def test_inventory_example_documents_mapping_fields():
    doc = json.loads((ROOT / "config" / "inventory.example.json").read_text())
    text = " ".join(doc["_comments"])
    for field in ("mapping_id", "enabled", "mandatory", "allow_empty", "verify_source_count",
                  "estimated_bytes", "source_schema_hash", "jdbc_partition_column", "columns"):
        assert field in text, field


def test_env_consistency_check_flags_disagreeing_duplicates():
    mod = _load("scripts/render_settings.py", "render_settings_p2")
    ok = {"BRIDGE_STAGING_URL": "abfss://stg@acct1.dfs.core.windows.net/", "BRIDGE_STAGING_CONTAINER": "stg",
          "BRIDGE_STORAGE_ACCOUNT": "acct1",
          "BRIDGE_MANIFEST_URL": "abfss://up@acct2.dfs.core.windows.net/",
          "BRIDGE_MANIFEST_PATH_TEMPLATE": "abfss://up@acct2.dfs.core.windows.net/m/{business_date}/r.csv",
          "BRIDGE_SYNAPSE_SERVER": "ws.sql.azuresynapse.net", "BRIDGE_SYNAPSE_DATABASE": "pool",
          "BRIDGE_JDBC_URL": "jdbc:sqlserver://ws.sql.azuresynapse.net:1433;databaseName=pool;encrypt=true"}
    assert mod.consistency_problems(ok) == []
    bad = {**ok, "BRIDGE_STAGING_CONTAINER": "other", "BRIDGE_STORAGE_ACCOUNT": "zzz",
           "BRIDGE_MANIFEST_URL": "abfss://x@acct2.dfs.core.windows.net/",
           "BRIDGE_JDBC_URL": "jdbc:sqlserver://wrong.sql.azuresynapse.net:1433;databaseName=nope"}
    assert len(mod.consistency_problems(bad)) == 5


def test_pause_flags_are_not_reset_by_github_setup():
    text = (ROOT / "scripts" / "05_github_setup.sh").read_text()
    assert "setv NIGHTLY_PAUSE_STATUS PAUSED" not in text and "keeping existing" in text


def test_release_validation_test_count_is_current():
    text = (ROOT / "docs" / "RELEASE_VALIDATION.md").read_text()
    assert "v2.6.9" not in text and "404 passed" not in text
