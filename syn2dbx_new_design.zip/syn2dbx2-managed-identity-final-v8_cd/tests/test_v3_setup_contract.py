"""Keep the beginner setup documentation aligned with runtime JDBC options."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_jdbc_connection_allowlist_covers_every_dynamic_reader_option():
    loader = (ROOT / "src/bridge/loader.py").read_text()
    guide = (ROOT / "docs/JDBC_CONNECTION_SETUP.md").read_text()
    expected = (
        "dbtable,query,partitionColumn,lowerBound,upperBound,numPartitions,"
        "queryTimeout,fetchsize,preferTimestampNTZ"
    )
    assert expected in guide
    for option in ("queryTimeout", "fetchsize", "preferTimestampNTZ",
                   "partitionColumn", "lowerBound", "upperBound", "numPartitions"):
        assert f'.option("{option}"' in loader
        assert option in expected


def test_readme_has_single_authoritative_start():
    readme = (ROOT / "README.md").read_text()
    assert "START_HERE_COMPLETE_SETUP.md" in readme
    assert "It is the authoritative managed-identity installation order" not in readme
    for name in ("JDBC_CONNECTION_SETUP.md", "GITHUB_OIDC_SETUP.md"):
        assert (ROOT / "docs" / name).is_file()


def test_profile_failure_has_actionable_permission_diagnostic():
    setup = (ROOT / "tools/databricks_admin_setup.py").read_text()
    assert "dedicated-pool DMV permissions" in setup
    assert "profile_tables=false" in setup
