"""Tests for the v6 fix pass (2.6.10): scripts, multi-schema Synapse grants, bootstrap tolerance, doc claims."""
import importlib.util
import shutil
import subprocess
from pathlib import Path

import pytest

import databricks_admin_setup as setup

ROOT = Path(__file__).resolve().parents[1]
DOC = {"staging": {"root": "abfss://staging@storageacct.dfs.core.windows.net"}}


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def _load_render_sql():
    spec = importlib.util.spec_from_file_location("render_sql", ROOT / "scripts" / "render_sql.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---- multi-schema Synapse grants ---------------------------------------------------------
def test_synapse_sql_grants_every_extra_schema():
    sql = setup.synapse_setup_sql(DOC, "mi-bridge-dev", "dbo", ["sales", "hr"])
    for schema in ("sales", "hr"):
        assert f"SCHEMA_ID(N'{schema}') IS NULL" in sql
        assert f"QUOTENAME(N'{schema}')" in sql


def test_synapse_sql_extra_schema_duplicates_skipped_and_injection_rejected():
    sql = setup.synapse_setup_sql(DOC, "mi-bridge-dev", "dbo", ["dbo", "sales", "sales"])
    assert sql.count("SCHEMA_ID(N'sales')") == 1
    assert "SCHEMA_ID(N'dbo') IS NULL" not in sql
    with pytest.raises(ValueError):
        setup.synapse_setup_sql(DOC, "mi-bridge-dev", "dbo", ["x'; DROP USER y;--"])


def test_admin_notebook_passes_all_schemas():
    text = _read("src/setup/00_admin_setup.py")
    assert "schemas[0], schemas[1:]" in text


# ---- bootstrap tolerates a compute that rejects a Spark conf ---------------------------------
class _FakeConf:
    def __init__(self, reject):
        self.reject, self.set_calls = set(reject), []

    def set(self, key, value):
        self.set_calls.append((key, value))
        if key in self.reject:
            raise RuntimeError("CONFIG_NOT_AVAILABLE: " + key)


class _FakeSpark:
    def __init__(self, reject=()):
        self.conf = _FakeConf(reject)


def _run_rebase_block(spark):
    text = _read("src/notebooks/_bootstrap.py")
    block = text[text.index("PARQUET_REBASE_CONFS"):]
    ns = {"spark": spark}
    exec(compile(block, "_bootstrap_block", "exec"), ns)  # noqa: S102 - our own source file
    return ns


def test_bootstrap_does_not_abort_when_a_conf_is_rejected():
    spark = _FakeSpark(reject={"spark.sql.parquet.int96RebaseModeInRead"})
    ns = _run_rebase_block(spark)
    assert ns["REJECTED_CONFS"] == ["spark.sql.parquet.int96RebaseModeInRead"]
    assert len(spark.conf.set_calls) == 4          # the other three were still attempted


def test_bootstrap_sets_all_four_confs_when_accepted():
    ns = _run_rebase_block(_FakeSpark())
    assert ns["REJECTED_CONFS"] == []


# ---- scripts folder ----------------------------------------------------------------------
SCRIPTS = ["00_check_tools.sh", "01_azure_setup.sh", "02_databricks_cli_setup.sh", "05_github_setup.sh", "_lib.sh",
           "env.example.sh"]


@pytest.mark.parametrize("name", SCRIPTS)
def test_shell_scripts_parse(name):
    path = ROOT / "scripts" / name
    assert path.exists()
    if shutil.which("bash"):
        subprocess.run(["bash", "-n", str(path)], check=True)


def test_script_files_exist():
    for name in ("README.md", "render_sql.py", "uc_admin_setup.sql.template", "synapse_00_check_master_key.sql",
                 "synapse_10_jdbc_reader_master.sql", "synapse_11_jdbc_reader_pool.sql"):
        assert (ROOT / "scripts" / name).exists(), name
    assert (ROOT / "infra" / "summary_webhook_schema.json").exists()


def test_mutating_scripts_are_dry_run_by_default():
    lib = _read("scripts/_lib.sh")
    assert 'CONFIRM' in lib
    for name in ("01_azure_setup.sh", "02_databricks_cli_setup.sh", "05_github_setup.sh"):
        assert "confirm" in _read(f"scripts/{name}"), name


def test_render_sql_rejects_unset_placeholder_and_unsafe_values():
    mod = _load_render_sql()
    tpl = "GRANT USE CATALOG ON CATALOG `${BRIDGE_CATALOG}` TO `${BRIDGE_PRINCIPAL}`;"
    ok = mod.render(tpl, {"BRIDGE_CATALOG": "ops_dev", "BRIDGE_PRINCIPAL": "app-1"})
    assert "ops_dev" in ok and "${" not in ok
    with pytest.raises(ValueError, match="not set"):
        mod.render(tpl, {"BRIDGE_CATALOG": "ops_dev"})
    with pytest.raises(ValueError, match="placeholder"):
        mod.render(tpl, {"BRIDGE_CATALOG": "<catalog>", "BRIDGE_PRINCIPAL": "x"})
    with pytest.raises(ValueError, match="quote"):
        mod.render(tpl, {"BRIDGE_CATALOG": "a`; DROP", "BRIDGE_PRINCIPAL": "x"})


def test_render_sql_allows_semicolons_only_in_jdbc_url():
    mod = _load_render_sql()
    url = "jdbc:sqlserver://h:1433;databaseName=p;encrypt=true"
    assert url in mod.render("URL '${BRIDGE_JDBC_URL}'", {"BRIDGE_JDBC_URL": url})
    with pytest.raises(ValueError):
        mod.render("X '${BRIDGE_OTHER}'", {"BRIDGE_OTHER": "a;b"})


def test_every_template_variable_is_in_env_example():
    mod = _load_render_sql()
    import re
    template = _read("scripts/uc_admin_setup.sql.template")
    names = set(re.findall(r"\$\{(BRIDGE_[A-Z0-9_]+)\}", template))
    env_example = _read("scripts/env.example.sh")
    missing = [n for n in sorted(names) if n not in env_example]
    assert not missing, missing
    assert mod is not None


# ---- documentation claims ------------------------------------------------------------------------
def test_start_here_names_the_new_steps_and_scripts():
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    for needle in ("java -version", "az extension add --name databricks", "scripts/01_azure_setup.sh",
                   "scripts/02_databricks_cli_setup.sh", "summary_webhook_schema.json",
                   "synapse_00_check_master_key.sql", "NIGHTLY_PAUSE_STATUS=UNPAUSED", "ROLLBACK_APPROVERS_GROUP",
                   "management-policy"):
        assert needle in text, needle


def test_every_script_referenced_by_start_here_exists():
    import re
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    for rel in sorted(set(re.findall(r"scripts/[A-Za-z0-9_.]+\.(?:sh|py|sql|template|md)", text))):
        if rel in {"scripts/env.dev.sh", "scripts/env.prod.sh"}:   # created by the installer, git-ignored
            continue
        assert (ROOT / rel).exists(), rel


def test_docs_no_longer_claim_acceptance_sends_a_notification():
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    assert "Validate delivery with the notification test/acceptance workflow" not in text
    assert "It does **not** send a notification" in text


def test_acceptance_check_15_reads_secret_only():
    code = _read("src/notebooks/acceptance_checks.py")
    assert "dbutils.secrets.get" in code
    section = code[code.index("summary webhook secret (read-only"):]
    assert "requests.post" not in section and "urlopen" not in section


def test_jdbc_guide_creates_the_schema():
    assert "CREATE SCHEMA IF NOT EXISTS" in _read("docs/JDBC_CONNECTION_SETUP.md")


def test_version_is_consistent():
    import re
    init = _read("src/bridge/__init__.py")
    version = re.search(r'__version__ = "([^"]+)"', init).group(1)
    assert f"version: {version}" in _read("databricks.yml")
    assert _read("CHANGELOG.md").startswith(f"## {version}")


def test_start_here_review_pass_items():
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    assert "## Roadmap: who does what, in order" in text
    assert "gh variable set NIGHTLY_PAUSE_STATUS --env prod" in text
    assert "every nightly task would fail at start-up" not in text      # the bootstrap now tolerates a rejected conf
    assert "check 12" in text and "Java 17+" in text
    assert "\n0a. " not in text                                           # odd list numbering removed


def test_start_here_code_fences_balanced_and_links_resolve():
    import re
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    assert text.count("```") % 2 == 0
    for rel in re.findall(r"\]\((?!http)([^)#]+)\)", text):
        assert (ROOT / "docs" / rel).exists(), rel


# ---- document <-> script agreement -----------------------------------------------------------
def _case_labels(script):
    import re
    text = _read(f"scripts/{script}")
    labels = set()
    for line in text.splitlines():
        m = re.match(r"^\s{2}([a-z][a-z0-9|-]*)\)\s*$", line)
        if m:
            labels.update(m.group(1).split("|"))
    return labels


def test_every_script_subcommand_in_docs_exists():
    import re
    for doc in ("docs/START_HERE_COMPLETE_SETUP.md", "scripts/README.md"):
        text = _read(doc)
        for script, sub in re.findall(r"scripts/(0\d_[a-z_]+\.sh) ([a-z][a-z-]+)", text):
            assert sub in _case_labels(script), (doc, script, sub)


def test_every_bridge_variable_used_by_scripts_is_in_env_example():
    import re
    env = set(re.findall(r"BRIDGE_[A-Z0-9_]+", _read("scripts/env.example.sh")))
    used = set()
    for path in (ROOT / "scripts").iterdir():
        if path.suffix in {".sh", ".template", ".py"} and path.name != "env.example.sh":
            used |= set(re.findall(r"BRIDGE_[A-Z0-9_]+", path.read_text(encoding="utf-8")))
    assert used - env == set(), sorted(used - env)


def test_uc_template_sections_named_in_docs_exist():
    import re
    template = _read("scripts/uc_admin_setup.sql.template")
    present = set(re.findall(r"^-- ===== ([A-G])\.", template, re.M))
    assert present == set("ABCDEFG")


def test_jdbc_reader_login_name_matches_everywhere():
    for name in ("synapse_10_jdbc_reader_master.sql", "synapse_11_jdbc_reader_pool.sql"):
        assert "bridge_jdbc_reader" in _read(f"scripts/{name}")
    assert 'BRIDGE_JDBC_USER="bridge_jdbc_reader"' in _read("scripts/env.example.sh")
    assert "CREATE LOGIN bridge_jdbc_reader" in _read("docs/START_HERE_COMPLETE_SETUP.md")


def test_lifecycle_prefix_default_matches_settings_example():
    import json
    prefix = json.loads(_read("config/settings.example.json"))["staging"]["prefix"]
    assert f'BRIDGE_STAGING_PREFIX="{prefix}"' in _read("scripts/env.example.sh")
    assert f"/{prefix}/" in _read("infra/adls_lifecycle_policy.json")


def test_file_flow_table_references_existing_files():
    import re
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    assert "## File flow: which file, in which order" in text
    block = text[text.index("## File flow"):text.index("## 0. What the bridge does")]
    for rel in set(re.findall(r"`((?:scripts|docs|sql|infra|config|src|tools)/[A-Za-z0-9_./-]+\.[a-z]+)`", block)):
        if rel.endswith(("env.dev.sh", "env.prod.sh", "settings.json")):
            continue
        assert (ROOT / rel).exists() or (ROOT / "scripts" / rel).exists(), rel


def test_uc_privilege_check_template_renders_and_is_read_only():
    mod = _load_render_sql()
    import re
    text = _read("scripts/uc_check_privileges.sql.template")
    env = {n: "x1" for n in set(re.findall(r"\$\{(BRIDGE_[A-Z0-9_]+)\}", text))}
    out = mod.render(text, env)
    live = [l for l in out.splitlines() if l.strip() and not l.lstrip().startswith("--")]
    assert live and all(l.split()[0].upper() in {"SELECT", "SHOW", "DESCRIBE"} for l in live)
    assert "uc_check_privileges.sql.template" in _read("docs/START_HERE_COMPLETE_SETUP.md")


# ---- numbered steps, feature branch ------------------------------------------------------------
def _load(rel, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def _steps():
    import sys
    sys.path.insert(0, str(ROOT / "scripts"))
    return _load("scripts/steps.py", "bridge_steps")


def test_steps_are_numbered_consecutively_and_complete():
    steps = _steps().STEPS
    assert [s["n"] for s in steps] == list(range(1, len(steps) + 1))
    for s in steps:
        for key in ("phase", "title", "who", "where", "kind", "doc", "check"):
            assert s.get(key), (s["n"], key)
        assert s["kind"] in {"cmd", "sql", "manual"}


def test_step_commands_files_and_sections_exist():
    import re
    mod = _steps()
    for s in mod.STEPS:
        for cmd in s.get("cmds", []):
            m = re.search(r"bash scripts/(0\d_[a-z_]+\.sh) ([a-z-]+)", cmd)
            if m:
                assert m.group(2) in _case_labels(m.group(1)), (s["n"], cmd)
            for rel in re.findall(r"(?:python3|python) ((?:scripts|tools)/[A-Za-z0-9_]+\.py)", cmd):
                assert (ROOT / rel).exists(), (s["n"], rel)
        for rel in s.get("files", []) + [s.get("template")]:
            if rel:
                assert (ROOT / rel).exists(), (s["n"], rel)
        if s.get("section"):
            assert mod.section_text(_read(s["template"]), s["section"]).startswith("-- ===== " + s["section"])


def test_step_sql_renders_for_every_sql_step():
    import re
    mod = _steps()
    render = _load_render_sql()
    for s in mod.STEPS:
        if s["kind"] == "sql" and s.get("template"):
            raw = _read(s["template"])
            if s.get("section"):
                raw = mod.section_text(raw, s["section"])
            env = {n: "x1" for n in re.findall(r"\$\{(BRIDGE_[A-Z0-9_]+)\}", raw)}
            env.update({"BRIDGE_JDBC_URL": "jdbc:sqlserver://h:1433;databaseName=p"})
            assert "${" not in render.render(raw, env), s["n"]


def test_step_by_step_doc_is_generated_from_steps():
    assert _read("docs/STEP_BY_STEP.md") == _steps().markdown()


def test_start_here_points_to_the_steps_and_feature_branch_section():
    text = _read("docs/START_HERE_COMPLETE_SETUP.md")
    for needle in ("STEP_BY_STEP.md", "scripts/steps.py", "## 10a. Test on your own feature branch first",
                   "feature_<you>_", "Never delete a managed table's files"):
        assert needle in text, needle


FEATURE_DOC = {"staging": {"root": "abfss://staging@storageacct.dfs.core.windows.net"}}


def _feature_tools():
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    return _load("tools/make_feature_inventory.py", "make_feature_inventory")


def _inventory():
    import json
    return json.loads(_read("config/inventory.example.json"))


def test_feature_inventory_moves_every_write_to_personal_names():
    mf = _feature_tools()
    doc = _inventory()
    out = mf.make_feature_inventory(doc, "Raghav.Asem@Company.com")
    assert out["control"]["schema"] == "feature_raghav_asem_" + doc["control"]["schema"]
    assert out["staging"]["prefix"] == "bridge-stage-feature-raghav_asem"
    assert all(m["target_schema"].startswith("feature_raghav_asem_") for m in out["mappings"])
    assert out["mappings"][0]["source_object"] == doc["mappings"][0]["source_object"]   # what is exported is unchanged
    assert doc["mappings"][0]["target_schema"] == "gold"                                 # the input is not modified
    assert out["notifications"] == doc["notifications"]


def test_feature_inventory_webhook_override_needs_both_values():
    mf = _feature_tools()
    out = mf.make_feature_inventory(_inventory(), "a@b.c", "test-scope", "test-key")
    assert out["notifications"]["summary_webhook"] == {"secret_scope": "test-scope", "url_secret_key": "test-key"}
    with pytest.raises(ValueError):
        mf.make_feature_inventory(_inventory(), "a@b.c", "test-scope", None)


def test_feature_reset_sql_only_drops_personal_schemas():
    mf = _feature_tools()
    out = mf.make_feature_inventory(_inventory(), "me@x.y")
    sql = mf.reset_sql(out, "me@x.y")
    assert sql.count("DROP SCHEMA IF EXISTS") == 2 and "CASCADE" in sql and "feature_me_" in sql
    with pytest.raises(ValueError, match="not a personal feature schema"):
        mf.reset_sql(_inventory(), "me@x.y")                      # the shared DEV inventory is refused
    with pytest.raises(ValueError):
        mf.feature_slug("@@@")


def test_feature_target_is_personal_and_not_used_by_the_workflows():
    import yaml
    bundle = yaml.safe_load(_read("databricks.yml"))
    feature = bundle["targets"]["feature"]
    assert feature["mode"] == "development" and "user_name" in feature["run_as"]
    assert "service_principal_name" not in feature["run_as"]
    for wf in (".github/workflows/ci-cd.yml", ".github/workflows/bundle-deploy.yml"):
        assert "feature" not in _read(wf).replace("feature branch", "")
    assert "config/inventory.feature.json" in _read(".gitignore")


def test_prepare_deploy_supports_feature_environment(tmp_path):
    import shutil
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    pd = _load("tools/prepare_deploy.py", "prepare_deploy_feature")
    (tmp_path / "config").mkdir()
    (tmp_path / "databricks.yml").write_text(_read("databricks.yml").replace("<dev-workspace>", "adb-1"))
    mf = _feature_tools()
    import json
    out = mf.make_feature_inventory(_inventory(), "me@x.y")
    (tmp_path / "config" / "inventory.feature.json").write_text(json.dumps(out))
    info = pd.prepare("feature", tmp_path)
    assert info["control"].endswith("feature_me_bridge_control")
    assert (tmp_path / "config" / "inventory.json").exists()
    shutil.rmtree(tmp_path)


def _render_settings():
    return _load("scripts/render_settings.py", "render_settings")


def test_render_settings_fills_env_values_and_rejects_gaps():
    import json
    rs = _render_settings()
    example = json.loads(_read("config/settings.example.json"))
    env = {var: "v1" for _, var, _ in rs.MAPPING}
    env.update({"BRIDGE_STAGING_URL": "abfss://c@a.dfs.core.windows.net/", "BRIDGE_SYNAPSE_SERVER": "ws.sql.azuresynapse.net",
                "BRIDGE_MANIFEST_PATH_TEMPLATE": "abfss://u@a.dfs.core.windows.net/m/{business_date}/row_counts.csv"})
    out = rs.render(example, env)
    assert out["staging"]["root"] == "abfss://c@a.dfs.core.windows.net"          # trailing slash removed
    assert out["synapse"]["server"] == "ws.sql.azuresynapse.net" and out["control"]["catalog"] == "v1"
    env.pop("BRIDGE_CONTROL_CATALOG")
    with pytest.raises(ValueError, match="BRIDGE_CONTROL_CATALOG"):
        rs.render(example, env)
    env["BRIDGE_CONTROL_CATALOG"] = "<catalog>"
    with pytest.raises(ValueError, match="placeholder"):
        rs.render(example, env)


def test_render_settings_never_overwrites_without_force(tmp_path, monkeypatch):
    rs = _render_settings()
    target = tmp_path / "settings.json"
    target.write_text("{}")
    assert rs.main(["--output", str(target)]) == 1
    assert target.read_text() == "{}"


# ---- Databricks-side permission check -----------------------------------------------------
def _pc():
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    return _load("tools/permission_check.py", "permission_check_mod")


def test_permission_report_passes_fails_and_hides_secrets():
    pc = _pc()
    r = pc.Report()
    r.check("ok", lambda: "fine")
    r.check("denied", lambda: (_ for _ in ()).throw(PermissionError("PERMISSION_DENIED accessToken=abc eyJ" + "a" * 40)), "ask the owner")
    r.skip("later", "not set")
    text = r.render()
    assert "[PASS] ok" in text and "[FAIL] denied" in text and "[SKIP] later" in text
    assert "-> ask the owner" in text and "1 passed, 1 failed, 1 skipped" in text
    assert "SOME CHECKS FAILED" in text and "abc" not in text and "eyJaaaa" not in text
    assert len(r.failed) == 1


def test_permission_report_all_pass_message():
    pc = _pc()
    r = pc.Report()
    r.check("a", lambda: None)
    assert "ALL PERMISSION CHECKS PASSED" in r.render()


def test_permission_path_and_name_rules():
    pc = _pc()
    assert pc.abfss_root("abfss://up@acct.dfs.core.windows.net/m/{business_date}/row_counts.csv") == "abfss://up@acct.dfs.core.windows.net"
    with pytest.raises(ValueError):
        pc.abfss_root("https://acct.blob.core.windows.net/c")
    name = pc.scratch_schema("Raghav.Asem@Company.com", "A1b2-c3d4;DROP")
    assert name.startswith("perm_check_raghav_asem_") and ";" not in name and " " not in name


def test_permission_notebook_is_read_only_apart_from_throwaway_objects():
    code = _read("src/setup/01_permission_check.py")
    assert "CREATE SCHEMA" in code and "DROP SCHEMA IF EXISTS" in code and "finally:" in code
    import re
    assert "print(dbutils.secrets" not in code
    assert not re.search(r"spark\.sql\(f?[\"']\s*(GRANT|REVOKE|ALTER|DELETE|UPDATE)", code)   # hints mention GRANT, code never runs one
    assert "raise AssertionError" in code                                  # a failed check fails the notebook/job
    for needle in ("get_token", "HAS_PERMS_BY_NAME", "databricks.connection", "dbutils.fs.put", "dbutils.fs.rm"):
        assert needle in code
    assert "01_permission_check.py" in _read("docs/START_HERE_COMPLETE_SETUP.md")


# ---- run the permission notebook end to end against fakes --------------------------------
class _Row(list):
    def first(self):
        return self[0]


class _NotebookDF:
    def __init__(self, rows):
        self.rows = rows

    def first(self):
        return self.rows[0]

    def count(self):
        return len(self.rows)


class _NotebookSpark:
    def __init__(self, deny=()):
        self.deny, self.statements = deny, []

    def sql(self, text):
        self.statements.append(text)
        if any(d in text for d in self.deny):
            raise PermissionError("PERMISSION_DENIED: " + text[:40])
        if "COUNT(*)" in text:
            return _NotebookDF([(1,)])
        return _NotebookDF([("me@x.y",)])

    @property
    def read(self):
        outer = self

        class R:
            def format(self, *_):
                return self

            def option(self, *_):
                return self

            def load(self):
                return _NotebookDF([(1,)])
        return R()


class _FakeDbutils:
    def __init__(self):
        self.widgets = type("W", (), {"text": staticmethod(lambda *a: None),
                                      "get": staticmethod(lambda n: {"source_schemas": "dbo", "target_catalog": "",
                                                                       "settings_file": "config/settings.json"}.get(n, ""))})
        self.files = {}
        self.fs = type("F", (), {})()
        self.fs.put = lambda path, text, overwrite: self.files.__setitem__(path, text)
        self.fs.head = lambda path: self.files[path]
        self.fs.rm = lambda path: self.files.pop(path)
        self.fs.ls = lambda path: [path + "/a"]
        self.secrets = type("S", (), {"get": staticmethod(lambda scope, key: "https://logic.example/hook?sig=abc")})()
        self.credentials = type("C", (), {"getServiceCredentialsProvider": staticmethod(
            lambda name: type("P", (), {"get_token": staticmethod(lambda scope: type("T", (), {"token": "t"})())})())})()


def _run_permission_notebook(monkeypatch, capsys, spark, pool_rows=1):
    import contextlib
    import json
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    sys.path.insert(0, str(ROOT / "src"))
    monkeypatch.chdir(ROOT)
    import databricks_admin_setup as das
    settings = json.loads(_read("config/inventory.example.json"))
    settings["staging"]["root"] = "abfss://staging@contosostage.dfs.core.windows.net"
    settings["manifest"]["path_template"] = "abfss://upstream@contosocontrol.dfs.core.windows.net/m/{business_date}/row_counts.csv"
    monkeypatch.setattr(das, "settings_file", lambda rel: settings)

    class Conn:
        def query(self, sql, *a, **k):
            return [(pool_rows, "mi-login", "mi-user")]

    @contextlib.contextmanager
    def fake_connection(spark_, dbutils_, doc):
        yield Conn()
    monkeypatch.setattr(das, "connection", fake_connection)
    glb = {"spark": spark, "dbutils": _FakeDbutils(), "__name__": "__main__"}
    code = compile(_read("src/setup/01_permission_check.py"), "01_permission_check.py", "exec")
    try:
        exec(code, glb)  # noqa: S102 - our own notebook source
        error = None
    except AssertionError as exc:
        error = exc
    return capsys.readouterr().out, error, glb


def test_permission_notebook_all_pass_with_fakes(monkeypatch, capsys):
    out, error, glb = _run_permission_notebook(monkeypatch, capsys, _NotebookSpark())
    assert error is None, out
    assert "ALL PERMISSION CHECKS PASSED" in out and "[FAIL]" not in out
    assert glb["dbutils"].files == {}                       # the probe file was removed again
    assert any(s.startswith("DROP SCHEMA IF EXISTS") for s in glb["spark"].statements)
    assert "logic.example" not in out and "sig=abc" not in out


def test_permission_notebook_reports_missing_rights_and_still_drops_scratch(monkeypatch, capsys):
    spark = _NotebookSpark(deny=("CREATE SCHEMA",))
    out, error, _ = _run_permission_notebook(monkeypatch, capsys, spark)
    assert error is not None
    assert "[FAIL] catalog" in out and "CREATE SCHEMA" in out and "-> Ask for: GRANT USE CATALOG, CREATE SCHEMA" in out


def test_permission_notebook_flags_missing_synapse_right(monkeypatch, capsys):
    out, error, _ = _run_permission_notebook(monkeypatch, capsys, _NotebookSpark(), pool_rows=0)
    assert error is not None and "[FAIL] Synapse: CREATE TABLE" in out and "01_export_setup.sql" in out
