# 4A — serverless CETAS + serverless JDBC fallback

Production-oriented Synapse dedicated SQL pool → ADLS Gen2 → Unity Catalog managed Delta full-refresh package for static nightly source tables.

## Compute split

| Stage | Compute | Purpose |
|---|---|---|
| Plan / Synapse checks | Serverless | Uses `mssql-python` for command-capable T-SQL connection |
| CETAS | Serverless Databricks task; CETAS executes in Synapse | Issues CETAS DDL through `mssql-python` |
| JDBC fallback | Serverless | Unity Catalog JDBC connection; only `FALLBACK_REQUIRED` tables |
| Delta publish | Serverless | Publishes only `VALIDATED` stages |
| Finalize | Serverless | Final success/failure/fallback summary |

**Flow:** `Refresh complete → serverless plan/CETAS → serverless UC-JDBC fallback only when required → serverless Delta publish → final summary`

No dedicated cluster is defined in the nightly job. A UC JDBC connection is required for fallback reads.

## Important prerequisites

- Unity Catalog enabled workspace and serverless jobs available.
- Serverless network connectivity to the Synapse SQL endpoint and ADLS.
- `mssql-python==1.15.0` is installed by the job environment for serverless command/control SQL.
- The run identity has the required Synapse CETAS permissions and storage access.
- The upstream row-count manifest CSV and its `_SUCCESS` marker are the completion signal; source tables remain static after it.
- Recovery cutoff remains 11:00 Australia/Sydney; do not rerun the previous night after the cutoff.

## Where to start

**New developers: begin with [START_HERE_COMPLETE_SETUP.md](docs/START_HERE_COMPLETE_SETUP.md).**
This is the authoritative, sequential DEV-to-PROD installation runbook, with
administrator commands, manual/script boundaries, permissions, checks, and
the protected release procedure included in the same document. References
below offer deeper implementation background. `DATABRICKS_FIRST_SETUP.md` covers the optional
administrator notebook workflow; `DEPLOYMENT_FROM_SCRATCH.md`, `FIRST_RUN.md`
and `SETUP_CHECKLIST.md` are supplemental historical references. Where they
differ, follow `START_HERE_COMPLETE_SETUP.md` and the current source code.

Read the documents in this order:

1. `docs/START_HERE_COMPLETE_SETUP.md`: **install in this order**; start here.
2. `docs/UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md`: administrator CLI and SQL details.
3. `docs/JDBC_CONNECTION_SETUP.md`: separate JDBC driver, connection and grants.
4. `docs/GITHUB_OIDC_SETUP.md`: GitHub environment federation and deployment.
5. `docs/PACKAGE_GUIDE.md`: folder and file inventory.
6. `docs/DESIGN.md` and `AGENTS.md`: architecture and invariants.
7. `docs/UPSTREAM_MANIFEST_SPEC.md`: upstream file contract.
8. `docs/RUNBOOK.md` and `docs/RELEASE_VALIDATION.md`: recovery and acceptance.

Reading paths by role (installer, upstream team, admins, operator, developer,
approver) are in `docs/PACKAGE_GUIDE.md`, "Suggested reading order".

**Numbered steps:** `python3 scripts/steps.py list` shows the whole setup as 31 ordered steps driven by one config file per environment ([docs/STEP_BY_STEP.md](docs/STEP_BY_STEP.md)). Test on a feature branch in your own `feature_<you>_*` schemas first (`START_HERE` section 10a), then merge; the GitHub runner deploys DEV and, by approved dispatch, PROD.

**Scripts:** `scripts/` holds the runnable form of the setup commands (dry-run unless `CONFIRM=yes`); see `scripts/README.md`. **Local tests need Java 17+** (PySpark) and run with the timezone pinned to UTC.

Keep the nightly schedule PAUSED until DEV connectivity, permissions, CETAS,
fallback, publish and notification acceptance checks pass
(`docs/RELEASE_VALIDATION.md`).

**Promotion gate:** merging to `main` triggers tests and DEV deployment only.
PROD requires a manual workflow dispatch on the tested SHA, the
`dev_acceptance_evidence` field, and a protected PROD Environment reviewer.
An accepted deployment is not proof of functional acceptance.

Run the tests with `python -m pytest tests -q`.

The setup notebook **renders** Synapse DDL but cannot execute it using the
nightly managed identity. The Synapse administrator provisions the database
master key and applies approved DDL separately.

