# Databricks notebook source
# Administrator-only, manually run from a Databricks Git folder.
# No schedule. Dry run unless the operator explicitly approves apply.
import sys
from pathlib import Path

repo = next((p for p in [Path.cwd(), *Path.cwd().parents]
             if (p / "tools" / "databricks_admin_setup.py").exists()), None)
if repo is None:
    raise RuntimeError("Run this notebook from the package's Databricks Git folder")
sys.path.insert(0, str(repo / "tools"))
import databricks_admin_setup as setup

for name, default in {
    "action": "preflight",
    "settings_file": "config/settings.json",
    "inventory_file": "config/inventory.dev.json",
    "source_schemas": "dbo",
    "exclude_objects": "",
    "profile_tables": "false",
    "target_catalog": "",
    "target_schema": "",
    "synapse_login_identity": "",
    "job_principal": "",
    "consumer_group": "",
    "apply_changes": "false",
    "confirmation": "",
}.items():
    dbutils.widgets.text(name, default)

def arg(name):
    return dbutils.widgets.get(name).strip()

action = arg("action")
apply_changes = arg("apply_changes").lower() == "true"
if apply_changes and arg("confirmation") != "APPLY_DEV_SETUP":
    raise ValueError("Set confirmation=APPLY_DEV_SETUP to approve a mutating action")
if action == "synapse_setup" and apply_changes:
    raise PermissionError("Render Synapse setup with apply_changes=false; an approved Synapse "
                          "administrator must execute the SQL separately")

settings = setup.settings_file(arg("settings_file"))
if action == "preflight":
    print(setup.preflight(spark, dbutils, settings))
elif action == "synapse_setup":
    schemas = [x.strip() for x in arg("source_schemas").split(",") if x.strip()]
    if not schemas:
        raise ValueError("source_schemas must name at least one schema")
    sql = setup.synapse_setup_sql(
        settings, arg("synapse_login_identity"), schemas[0], schemas[1:]
    )
    if not apply_changes:
        print(sql)
    print(setup.apply_synapse_sql(spark, dbutils, settings, sql, apply_changes))
elif action == "inventory":
    print(setup.generate_inventory(
        spark, dbutils, settings, arg("source_schemas"), arg("target_catalog"),
        arg("target_schema"), arg("inventory_file"), apply_changes,
        arg("exclude_objects"), arg("profile_tables").lower() == "true"
    ))
elif action == "uc_setup":
    sql = setup.uc_setup_sql(
        arg("inventory_file"), arg("job_principal"), arg("consumer_group")
    )
    if not apply_changes:
        print(sql)
    print(setup.apply_uc_sql(spark, sql, apply_changes))
else:
    raise ValueError("action must be preflight, synapse_setup, inventory or uc_setup")
