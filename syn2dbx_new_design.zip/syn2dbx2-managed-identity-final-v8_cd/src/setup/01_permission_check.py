# Databricks notebook source
# Permission check for the person who will set up and test: run it in your Databricks Git folder, AS YOURSELF.
# It proves (read-only except two throw-away objects it removes again) that YOUR USER can do what the package needs:
#   Unity Catalog:  list the catalogs, create a schema and table (then drop them), read the JDBC connection
#   Service credential: get a Synapse SQL token; connect to the dedicated pool; the pool-side rights CETAS needs
#   Storage:        read and write the staging folder, read the manifest folder
#   Secrets:        read the webhook secret (shape only, never printed)
# Nothing is granted, created permanently or printed that is secret. Safe to re-run.
# Run it as a serverless notebook with mssql-python==1.15.0 and azure-identity installed (see START_HERE section 9).
import secrets
import sys
from pathlib import Path

repo = next((p for p in [Path.cwd(), *Path.cwd().parents] if (p / "tools" / "permission_check.py").exists()), None)
if repo is None:
    raise RuntimeError("Run this notebook from the package's Databricks Git folder")
sys.path.insert(0, str(repo / "tools"))
sys.path.insert(0, str(repo / "src"))
import permission_check as pc  # noqa: E402
import databricks_admin_setup as setup  # noqa: E402
from bridge import contract, synapse  # noqa: E402

for name, default in {
    "settings_file": "config/settings.json",
    "source_schemas": "dbo",
    "target_catalog": "",          # catalog you will create your schemas in; empty = control.catalog
    "driver_jar_path": "",         # optional: /Volumes/<catalog>/<schema>/<volume>/mssql-jdbc-<version>.jar
    "operations_group": "",        # optional: reports whether you are a member
    "rollback_approvers_group": "",
}.items():
    dbutils.widgets.text(name, default)
arg = lambda n: dbutils.widgets.get(n).strip()  # noqa: E731

settings = setup.settings_file(arg("settings_file"))
me = spark.sql("SELECT current_user()").first()[0]
catalogs = sorted({arg("target_catalog") or settings["control"]["catalog"], settings["control"]["catalog"]})
for c in catalogs:
    contract.ident(c, "catalog")
schemas = [s.strip() for s in arg("source_schemas").split(",") if s.strip()]
for s in schemas:
    contract.ident(s, "source schema")
staging_root = pc.abfss_root(settings["staging"]["root"])
manifest_root = pc.abfss_root(settings["manifest"]["path_template"])
report = pc.Report()
print(f"Checking permissions for: {me}\n")

# ---- Unity Catalog ------------------------------------------------------------------
for cat in catalogs:
    report.check(f"catalog {cat}: USE CATALOG (can list schemas)",
                 lambda cat=cat: f"{spark.sql(f'SHOW SCHEMAS IN `{cat}`').count()} schemas visible",
                 f"Ask the catalog owner for: GRANT USE CATALOG ON CATALOG `{cat}` TO `{me}`")


def create_and_drop(cat):
    name = pc.scratch_schema(me, secrets.token_hex(4))
    full = f"`{cat}`.`{name}`"
    spark.sql(f"CREATE SCHEMA {full}")
    try:
        spark.sql(f"CREATE TABLE {full}.t (id INT)")
        spark.sql(f"INSERT INTO {full}.t VALUES (1)")
        assert spark.sql(f"SELECT COUNT(*) FROM {full}.t").first()[0] == 1
    finally:
        spark.sql(f"DROP SCHEMA IF EXISTS {full} CASCADE")
    return "created a schema, a table and a row, then dropped them (you own what you create)"


report.check(f"catalog {catalogs[-1]}: CREATE SCHEMA / TABLE", lambda: create_and_drop(catalogs[-1]),
             f"Ask for: GRANT USE CATALOG, CREATE SCHEMA ON CATALOG `{catalogs[-1]}` TO `{me}`")
report.check("service credential visible",
             lambda: spark.sql(f"DESCRIBE SERVICE CREDENTIAL `{settings['synapse']['auth']['credential_name']}`").count() and "found",
             "Ask the credential owner for ACCESS (GRANT ACCESS ON SERVICE CREDENTIAL ... TO your user)")
conn_name = settings["synapse"]["uc_jdbc_connection"]
report.check("UC JDBC connection visible", lambda: spark.sql(f"DESCRIBE CONNECTION `{contract.ident(conn_name, 'connection')}`").count() and "found",
             "Ask for: GRANT USE CONNECTION ON CONNECTION ... TO your user")

# ---- Service credential and Synapse --------------------------------------------------
auth = settings["synapse"]["auth"]
report.check("service credential gives a Synapse SQL token",
             lambda: bool(dbutils.credentials.getServiceCredentialsProvider(auth["credential_name"]).get_token(synapse.SQL_SCOPE).token) and "token received",
             "ACCESS on the service credential is missing, or the credential points at the wrong access connector")
synapse_ok = []


def synapse_login():
    with setup.connection(spark, dbutils, settings) as conn:
        row = conn.query("SELECT DB_NAME(), SUSER_SNAME(), USER_NAME()")
    synapse_ok.append(True)
    return f"database={row[0][0]} login={row[0][1]} user={row[0][2]}"


report.check("Synapse dedicated pool login via the credential", synapse_login,
             "The access connector identity has no user in the pool (START_HERE section 6), the pool is paused, or networking blocks serverless")


def has_perm(securable, klass, permission):
    with setup.connection(spark, dbutils, settings) as conn:
        value = conn.query(f"SELECT HAS_PERMS_BY_NAME({securable}, '{klass}', '{permission}')")[0][0]
    if int(value or 0) != 1:
        raise PermissionError(f"the Synapse login does not hold {permission} on {klass}")
    return "yes"


if synapse_ok:
    meta = contract.ident(settings["staging"]["metadata_schema"], "schema")
    for perm in ("CREATE TABLE", "ALTER ANY EXTERNAL DATA SOURCE", "ALTER ANY EXTERNAL FILE FORMAT", "ADMINISTER DATABASE BULK OPERATIONS"):
        report.check(f"Synapse: {perm}", lambda perm=perm: has_perm("DB_NAME()", "DATABASE", perm),
                     "Run sql/synapse/01_export_setup.sql as the Synapse administrator (START_HERE section 6)")
    report.check(f"Synapse: ALTER on schema {meta}", lambda: has_perm(f"N'{meta}'", "SCHEMA", "ALTER"), "Same script grants this")
    for sch in schemas:
        report.check(f"Synapse: SELECT on source schema {sch}", lambda sch=sch: has_perm(f"N'{sch}'", "SCHEMA", "SELECT"),
                     f"GRANT SELECT ON SCHEMA::[{sch}] to the access connector's Synapse user")
else:
    report.skip("Synapse pool-side rights", "skipped because the pool login failed")

# ---- UC JDBC fallback read --------------------------------------------------------------
report.check("UC JDBC connection runs a query (with the package's options)",
             lambda: spark.read.format("jdbc").option("databricks.connection", conn_name).option("query", "SELECT 1 AS ok")
             .option("queryTimeout", "60").option("fetchsize", "1000").option("preferTimestampNTZ", "true").load().first()[0] == 1 and "SELECT 1 worked",
             "USE CONNECTION missing, the driver JAR is unreadable, an option is not in externalOptionsAllowList, or the JDBC login is wrong (JDBC_CONNECTION_SETUP.md)")
if arg("driver_jar_path"):
    report.check("JDBC driver JAR readable", lambda: len(dbutils.fs.ls(arg("driver_jar_path"))) == 1 and "found",
                 "READ VOLUME on the volume, or the path is wrong")
else:
    report.skip("JDBC driver JAR readable", "set the driver_jar_path widget to test it")

# ---- Storage -----------------------------------------------------------------------------
probe = f"{staging_root}/{settings['staging']['prefix']}/_perm_check/{pc.scratch_schema(me, 'file')}.txt"


def staging_write_read_delete():
    dbutils.fs.put(probe, "permission check", True)
    try:
        assert dbutils.fs.head(probe).startswith("permission check")
    finally:
        dbutils.fs.rm(probe)
    return "wrote, read and deleted a one-line file"


report.check("staging: READ + WRITE FILES", staging_write_read_delete,
             "Ask the external-location owner for: GRANT READ FILES, WRITE FILES ON EXTERNAL LOCATION ... TO your user")
report.check("manifest: READ FILES (listing)", lambda: f"{len(dbutils.fs.ls(manifest_root))} entries visible",
             "Ask for: GRANT READ FILES ON EXTERNAL LOCATION ... TO your user (read only; never write)")

# ---- Secrets and groups --------------------------------------------------------------------
hook = settings["notifications"]["summary_webhook"]


def webhook_shape():
    from urllib.parse import urlparse
    parts = urlparse(dbutils.secrets.get(hook["secret_scope"], hook["url_secret_key"]))
    assert parts.scheme == "https" and parts.hostname and not parts.username, "the secret is not an https URL"
    return "readable, https URL (not shown)"


report.check("webhook secret readable", webhook_shape,
             "READ on the secret scope, or the secret has not been stored yet (START_HERE section 8)")
for label in ("operations_group", "rollback_approvers_group"):
    if arg(label):
        member = spark.sql(f"SELECT is_account_group_member('{arg(label).replace(chr(39), '')}')").first()[0]
        report.rows.append((pc.PASS if member else pc.SKIP, f"member of {label}", "yes" if member else
                            "no: you cannot press Run now on that job (not an error for a feature-branch bundle that runs as you)", ""))
    else:
        report.skip(f"member of {label}", f"set the {label} widget to test it")

print(report.render())
if report.failed:
    raise AssertionError(f"{len(report.failed)} permission check(s) failed; see the FAIL lines above")
