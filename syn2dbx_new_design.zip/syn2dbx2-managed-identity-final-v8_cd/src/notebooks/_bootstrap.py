# Databricks notebook source
# Shared setup, run from the other notebooks with %run ./_bootstrap
import os
import sys

_src = os.path.abspath(os.path.join(os.getcwd(), ".."))
if _src not in sys.path:
    sys.path.insert(0, _src)

from bridge import contract, control, loader, notification, planning, process, synapse  # noqa: E402,F401

# Datetime conversions assume UTC so wall-clock values are preserved exactly.
spark.conf.set("spark.sql.session.timeZone", "UTC")


def widget(name, default=""):
    try:
        dbutils.widgets.text(name, default)
    except Exception:
        pass
    return dbutils.widgets.get(name).strip()


def load_settings():
    # A job runner cannot redirect privileged reads/writes by overriding a widget.
    path = os.path.abspath(os.path.join(_src, "..", "config", "inventory.json"))
    return contract.load_inventory(path)


# SQL Server uses the proleptic Gregorian calendar, including 0001-01-01 sentinels.
# Confirm CETAS physical encodings on the target runtime before enabling the job.
# Databricks documents only a short list of Spark settings as changeable on serverless.
# If this compute rejects one of these, do NOT abort every task at start-up: the Spark
# default for these settings (EXCEPTION) makes a pre-1582 value fail loudly for that
# table instead of shifting silently. Acceptance check 12 (acceptance_checks.py) is the
# hard gate that reports a rejected setting before go-live.
PARQUET_REBASE_CONFS = ("spark.sql.parquet.datetimeRebaseModeInRead",
                        "spark.sql.parquet.int96RebaseModeInRead",
                        "spark.sql.parquet.datetimeRebaseModeInWrite",
                        "spark.sql.parquet.int96RebaseModeInWrite")
REJECTED_CONFS = []
for _conf in PARQUET_REBASE_CONFS:
    try:
        spark.conf.set(_conf, "CORRECTED")
    except Exception as _exc:  # noqa: BLE001 - serverless raises a non-specific config error
        REJECTED_CONFS.append(_conf)
        print(f"WARNING: this compute rejected {_conf}: {str(_exc)[:150]}. "
              "Run the acceptance job (check 12) and see START_HERE section 10, step 3a.")
