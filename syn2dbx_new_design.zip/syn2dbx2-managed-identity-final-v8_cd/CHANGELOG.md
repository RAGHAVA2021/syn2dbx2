## 2.6.12 (v8_cd: separate Databricks and Synapse/storage subscriptions)

* No change to the nightly job's behaviour. Setup scripts now support the Databricks access connector being in a different
  Azure subscription from the Synapse workspace and staging storage account.
* New variable `BRIDGE_DATA_SUBSCRIPTION_ID` (Synapse + storage subscription). `BRIDGE_SUBSCRIPTION_ID` now means the
  Databricks access-connector subscription only. Use the same GUID for both if there is a single subscription.
* `01_azure_setup.sh`: no global `az account set`; every `az` call passes `--subscription` explicitly, and the storage
  container role scope uses `BRIDGE_DATA_SUBSCRIPTION_ID`. `02_databricks_cli_setup.sh` passes `BRIDGE_SUBSCRIPTION_ID`.
* Each `01_azure_setup.sh` step requires only the subscription variable(s) it uses (`create-connector` needs only
  `BRIDGE_SUBSCRIPTION_ID`; container/role/lifecycle steps need only `BRIDGE_DATA_SUBSCRIPTION_ID`).
* Lifecycle-policy examples in `infra/README.md`, `SETUP_CHECKLIST.md` and `FIRST_RUN.md` pass `--subscription`.
* Docs: START_HERE and UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP updated.

## 2.6.11 (v7 verification and fix pass)

* No change to the nightly job's behaviour. Version tag in `databricks.yml` now follows `src/bridge/__init__.py`.
* Scripts: `_lib.sh` and `env.example.sh` gain a shebang / shell directive (shellcheck clean);
  `01_azure_setup.sh grant-synapse-storage-role` reports "could not resolve the Synapse workspace managed identity"
  instead of exiting on the raw `az` error; `02_databricks_cli_setup.sh create-secret-scope` matches the scope name
  literally (dots in a name no longer act as regex); `render_sql.py` error text no longer lists "semicolon" for the
  JDBC URL, which allows it.
* Docs: `REVIEW_FINDINGS.md` item 1 (check 12 "can never print") and item 5 (version tag) corrected; test count and
  version updated in `RELEASE_VALIDATION.md`; `AGENTS.md` and `DESIGN.md` say "legacy v6" for the old system so it is
  not confused with package review rounds v5/v6/v7.
* New tests: `tests/test_v7_fixes.py`.

## 2.6.10 (v6 verification and fix pass)

* **New `scripts/` folder**: dry-run-by-default scripts for every setup command that START_HERE previously only
  described (tool check, Azure RBAC/connector/container/lifecycle, Databricks credential/secret scope/ACL,
  GitHub environments/variables/federated credential), a rendered UC admin SQL template, and the Synapse JDBC
  reader and master-key SQL. `scripts/render_sql.py` rejects unset values, placeholders and unsafe characters.
  `infra/summary_webhook_schema.json` added for the Logic App trigger.
* `src/notebooks/_bootstrap.py`: the four Parquet rebase confs are set one at a time; a compute that rejects one
  prints a warning and records it instead of failing every task at import. (Serverless allows only a short list of
  Spark confs; confirm with the DEV smoke test.)
* `tools/databricks_admin_setup.py` / `src/setup/00_admin_setup.py`: `source_schemas` with several schemas now
  renders a `GRANT SELECT` for every schema (previously only the first).
* `src/notebooks/acceptance_checks.py`: check 15 reads the webhook secret and validates the URL shape. It never
  posted anything, and the docs no longer say it does.
* `tests/conftest.py` pins `TZ=UTC` (three tests failed on machines in other timezones).
* Docs: START_HERE gains Java 17, Azure CLI extensions, privileges per person, exact storage/secret/Logic App
  commands, master-key check, unpause procedure, acceptance-runner rules. `JDBC_CONNECTION_SETUP.md` gains
  `CREATE SCHEMA`; `DATABRICKS_FIRST_SETUP.md` order corrected; stale master-key/workload-group statements in
  supplemental docs removed; every supplemental doc now points to START_HERE.
* START_HERE second review pass: roadmap table, clearer section 6 and 9 layout, corrected smoke-test guidance, `gh variable set --env`, Java note and more troubleshooting rows.
* **One config, numbered steps.** `scripts/steps.py` lists, shows and runs 31 setup steps in order (phases A platform,
  B feature branch, C release); `docs/STEP_BY_STEP.md` is generated from it. `scripts/render_settings.py` writes
  `config/settings.json` from the same `scripts/env.<env>.sh` file. `scripts/uc_check_privileges.sql.template` checks
  Unity Catalog rights up front, and `src/setup/01_permission_check.py` (step 19) checks, as you, every Databricks-side
  permission: catalogs, create schema/table, Synapse token and pool rights, staging/manifest storage, JDBC connection, secret.
* **Feature-branch testing.** New bundle target `feature` (development mode, `run_as` your user; not used by CI),
  `tools/prepare_deploy.py --environment feature`, and `tools/make_feature_inventory.py` which writes a personal
  inventory (schemas `feature_<you>_*`, own staging folder) and a guarded reset SQL. START_HERE section 10a.
* New tests: `tests/test_v6_fixes.py`. See `docs/REVIEW_FINDINGS.md`.
* **Second review pass (docs/config sync):** every variable now has a purpose comment (`scripts/env.example.sh`,
  `databricks.yml` variables and job parameters, `settings.example.json` leaf keys, new `_comments` block in
  `inventory.example.json`, module-level constants in `src/bridge`, `tools`, `scripts`). New `DATA_DICTIONARY.md`
  section 8 documents the mapping fields. `render_settings.py` now rejects env values that disagree
  (staging URL vs container/account, manifest URL vs template, JDBC URL vs Synapse server/database).
  `05_github_setup.sh variables` no longer resets the PAUSED flags on re-run; `01_azure_setup.sh lifecycle`
  removes its temp file. `RELEASE_VALIDATION.md` test count corrected; `PACKAGE_GUIDE.md` lists the missing docs,
  schema and tests. Unused import removed from `src/setup/00_admin_setup.py`. New tests: `tests/test_review_pass2.py`.

## 2.6.9 (v4 review fixes)

* `databricks.yml`: `sync.include: config/inventory.json`. The generated inventory is git-ignored, and the
  bundle CLI skips git-ignored files, so a deploy would have shipped without it (every nightly task reads it).
* `tools/databricks_admin_setup.py`: `apply_uc_sql` no longer sends comment-only chunks to Spark, which
  failed `uc_setup` apply at statement 10 of 18 before any target table was created.
* `.gitignore`: `config/settings.json` / `config/settings.*.json` (docs say never commit it).
* Docs: START_HERE gains tool install, Entra-admin and login-name rules, admin `ACCESS` grant, JDBC SQL-user
  creation, notebook dependency install, Git-folder steps, serverless config smoke test, acceptance
  parameters and scratch schema, DEV time rules, test manifest creation and a way to force the fallback.
  RUNBOOK/PACKAGE_GUIDE no longer say a merge deploys to prod.
* New tests: `tests/test_review_fixes.py`. See `docs/REVIEW_FINDINGS.md`.

# Changelog — 4A — serverless CETAS + serverless JDBC fallback

## 2.6.9 (documentation addendum)
## 2026-10-18 examples, settings comments and installation guides

No code change.

- `config/row_counts.example.csv` and `config/success_marker.example.json` now show the
  once-a-day layout: no `upstream_sequence` column, `upstream_run_id` equal to the business date.
  The marker still carries `upstream_sequence` (`yyyymmdd00`); the code requires it.
- `docs/UPSTREAM_MANIFEST_SPEC.md` matches that layout and marks `upstream_sequence` optional.
- `config/settings.example.json` has a `_comments` block explaining every setting; the job ignores it.
- New `docs/FIRST_RUN.md` (complete installation and first-run steps) and
  `docs/SETUP_CHECKLIST.md` (tick-list and script map).

## 2.6.9
## 2026-10-12 fresh-install cleanup: one fallback route, manifest-only completion

Nothing has been installed yet, so upgrade paths and unused alternatives were removed.

- **One JDBC fallback route.** The in-task Spark-JDBC fallback is removed. A CETAS-specific
  failure or a pre-1900 timestamp always ends `FALLBACK_REQUIRED` and is staged by the serverless
  UC-JDBC task (`20_serverless_jdbc_fallback`). Removed: `execution.defer_jdbc_fallback` (an old
  inventory that still sets it is accepted; the key is ignored), `loader.jdbc_export`,
  `contract.jdbc_query`, `synapse.partition_bounds`, `synapse.DRIVER`. The Parquet staging of
  `loader.uc_jdbc_export` is now `loader.stage_jdbc_query`, which the Derby tests exercise directly.
- **Manifest completion only.** `contract.variant_4a_problems` (deploy, UC setup, acceptance) refuses
  any `upstream.completion_source` other than `"manifest"`, including an unset one (the code default
  is `synapse_table`). `synapse.upstream_control_schema` is required only in `synapse_table` mode and
  is removed from the example configs. The shared `synapse_table` code path remains but is unreachable.
- **Removed files:** `sql/synapse/02_upstream_control.sql` (and the `bridge_upstream` schema and grant in
  `01_export_setup.sql`), `sql/unity_catalog/upgrade_*.sql`, `src/notebooks/10_process_batch.py`,
  `FIRST_READ_ME.md`, `docs/V22_REVIEW_RESOLUTION.md`, `docs/COMPUTE_DESIGN.md` (its unique content
  moved to DESIGN 3.4). `render_uc_setup.py` no longer prints upgrade-script hints.
- **New:** `docs/UPSTREAM_MANIFEST_SPEC.md` (file contract for the upstream team) and
  `config/success_marker.example.json`; a test proves the two examples certify each other.
- **Documentation:** all docs describe the 4A task chain (extract → UC-JDBC fallback → publish);
  PACKAGE_GUIDE lists who uses each file, when, and in what order; README and PACKAGE_GUIDE give the
  reading order. Stale cluster/JVM wording removed.

**Inventory actions:** set `upstream.completion_source = "manifest"` and the `upstream_wait_minutes`
you want (the code default is 0, no wait). `execution.defer_jdbc_fallback` can be deleted.

## 2.6.8
## 2026-09-27 deploy workflow and documentation fixes

No runtime change: the notebooks, `src/bridge` and the job definitions behave exactly as in 2.6.7
(only the bundle's version tag changes).

- **Deploy workflow:** `bundle-deploy.yml` pins `databricks/setup-cli` to the v1.18.0 commit instead
  of `@main`, so a change to the action cannot alter a prod deploy, and runs Python 3.12 like CI and
  serverless environment version 3 (was 3.11).
- **RUNBOOK step 13 pointed at a section that did not exist** ("Additional for v2.6.5" in
  `RELEASE_VALIDATION.md`). `RELEASE_VALIDATION.md` now has an "Environment checks" section listing the
  DEV/PROD gates, and the RUNBOOK refers to it.
- `RELEASE_VALIDATION.md` drops the stale 4A/4B title and "serverless/dedicated boundaries" wording.
- `tests/test_v268_regressions.py` guards all of the above.

## 2.6.7
## 2026-09-27 independent review fixes

- **Bundle:** removed the duplicate `environment_key` on the fallback task (strict YAML
  loaders, including the Databricks CLI's, reject duplicate keys); a strict-YAML test guards it.
  Removed the unused `max_workers` variable. CI tests on Python 3.12 like serverless environment 3.
- **CETAS-error fallbacks were counted as timestamp reroutes.** mssql-python keeps the SQLSTATE but
  not the error number, so most CETAS failures reached the deferred fallback with `error_code` NULL,
  and `fallback_alert_threshold` could never fire. Such a failure is now logged with `error_code = 0`
  (`process.CETAS_ERROR_WITHOUT_NUMBER`); NULL still means a historical-timestamp reroute. The detail
  names the SQLSTATE instead of "error None".
- **Data errors went to the JDBC fallback.** A server error with SQLSTATE class 22 (data exception)
  and no recognized number is now `DATA` (`FAILED_SOURCE_DATA`), per invariant 10. *Owner review:*
  this is a SQLSTATE-class rule, not a new error code; confirm it on the trial night.
- **Fallback outcomes use the real statuses.** A failed UC-JDBC attempt logs `FAILED_EXPORT`,
  `FAILED_COUNT_MISMATCH` or `FAILED_UNKNOWN` with `method = JDBC` (was the in-flight
  `FALLBACK_REQUIRED`), so when both routes fail the summary shows `FAILED_EXPORT` as AGENTS.md
  requires. The task retry and a Repair run still re-attempt it (`control.failed_fallbacks`).
- **UC-JDBC fallback read contract.** Every read is bounded by the publication deadline
  (`queryTimeout`), so one slow fallback no longer holds every table's publication past the cutoff.
  It now honours `jdbc_partition_column`/`jdbc_num_partitions`, `jdbc_fetch_size` and
  `preferTimestampNTZ` like the classic route. `bounds_sql` names its columns (T-SQL 8155 through a
  JDBC `query`). The UC connection must allow these options; the acceptance job proves it.
- **4A settings enforced before deploy:** `tools/prepare_deploy.py` and `tools/render_uc_setup.py`
  refuse an inventory without `execution.defer_jdbc_fallback = true` and `synapse.uc_jdbc_connection`
  (`contract.variant_4a_problems`); the example inventory sets both.
- **Acceptance job** fails instead of skipping when the UC connection is missing; it runs the
  production `loader.uc_jdbc_export` (plain and partitioned) and proves the serverless CETAS command
  path: `mssql-python` installed, login, staging-object check and a one-row CETAS read back by Spark.
- Publishing from a stage reused from an earlier phase removes every attempt folder of that
  release/mapping (the CETAS folder preceding a JDBC fallback was left for the lifecycle rule).
- Publish reports a VALIDATED stage that no longer exists as such, instead of "CETAS failed (UNKNOWN)".
- A missing `mssql-python` raises a clear error naming the job environment.

**Open design decision (not changed):** the phases are barriers: no table publishes until every
extract batch and every fallback batch has finished. The deadline-bounded fallback limits the damage,
but a slow extraction tail still delays every publication. Publishing per batch would need a reviewed
job-graph change (see DESIGN 3.4).

## 2.6.6
## 2026-09-27 review fixes

- **Publish could never publish.** `30_publish_batch` passed `already={}`, so every table tried to run
  CETAS (forbidden there) and ended `FAILED_EXPORT`; its retry then skipped every table because the
  failed attempt was the latest event. It now reuses the VALIDATED stage and re-selects every mapping
  with a VALIDATED stage that has not reached a terminal status.
- **Serverless Synapse errors were all "CAPACITY".** mssql-python exceptions carry neither SQLSTATE nor
  native error. `sql_error_info` now recovers the SQLSTATE from the driver's own table and the SQL Server
  error number from its message text; a server SQLSTATE without a number classifies as `CETAS`. The
  plan's transient retry now recognizes dropped connections (08S01) on serverless.
- **Fallback moved to `bridge/fallback.py` (unit-tested).** It always proves the row count (UC-JDBC
  COUNT_BIG when the manifest has none, so such tables can publish), logs deterministic failures with
  their real status, retries a mapping left in `FALLBACK_STARTED`, and skips past the publish deadline.
- `count_sql` names its column (`AS row_count`): T-SQL rejects unnamed derived-table columns (8155).
- `control.fallback_counts` counts per mapping across `FALLBACK_REQUIRED`/`FALLBACK_STARTED`; the CETAS
  fallback alert could never fire in the deferred design.
- Extraction retries no longer re-run CETAS for a table already handed to the deferred fallback;
  `FALLBACK_REQUIRED` is logged once.
- Acceptance job runs on serverless and now proves every Spark conf the nightly sets, that the
  governance preflight detects a row filter and a column mask, and the UC-JDBC route (grant,
  datetime2 wall clock incl. pre-1900, COUNT query).
- **Second review:** the serverless publish could not verify a commit whose acknowledgement was lost
  (worker died after the Delta commit): it tried a forbidden Synapse recount and looped `FAILED_UNKNOWN`,
  never restoring a wrong-count commit. Counts from a VALIDATED stage are now marked proven and are never
  recounted, so such a commit verifies (`ALREADY_CURRENT`) or is rolled back automatically.
- Fallback batch isolates per-table platform failures and reports planned mappings missing from the
  inventory; CI installs `mssql-python` so the real-driver tests run; the acceptance conf probe names the
  rejected setting even when reading it fails.
- UC setup grants `USE CONNECTION`; every nightly task declares the serverless environment; the SQL
  password is brace-quoted in the ODBC connection string; publish keeps the proven count's label.

## 2.6.5
## 2026-09-27 compute correction

- Corrected the package so CETAS command/control actually runs from a **serverless Databricks task**.
- Added serverless command SQL support through `mssql-python==1.15.0`; no Spark JVM gateway is required for CETAS.
- Kept per-table deferred fallback and independent publication (`ALL_DONE`).
- Updated tests, package names and compute documentation to match the executable bundle.
- No dedicated cluster is defined in the nightly job. A UC JDBC connection is required for fallback reads.
## v8_cd review fixes (setup and documentation only)

* `scripts/00_check_tools.sh` now checks each required command's actual exit status instead of accepting the success of `head`, and treats GitHub CLI (`gh`) as optional.
* `docs/START_HERE_COMPLETE_SETUP.md` now points to the correct feature steps 22–26 and release steps 27–31.
* `scripts/steps.py` provides a clearer explanation when feature cleanup SQL has not been generated.
* `docs/SETUP_CHECKLIST.md` correctly states that weekly maintenance remains paused until explicitly enabled.
* No change to extraction, JDBC fallback, publication, scheduling defaults or access permissions.

