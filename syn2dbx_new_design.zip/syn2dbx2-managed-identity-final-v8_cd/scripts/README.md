# Setup scripts

**Start with `python3 scripts/steps.py list`:** the numbered steps (1-31) in run order, driven by one config file per environment (`scripts/env.dev.sh`). The table below is the same material by script.

These run the **command** parts of `docs/START_HERE_COMPLETE_SETUP.md`. The document is still the
runbook (who, why, approvals, verification); each section names the script for its commands.
Every mutating step is a **dry run** until you add `CONFIRM=yes`, so you can review what it will do first.

```bash
cp scripts/env.example.sh scripts/env.dev.sh     # edit EVERY value (git-ignored); use env.prod.sh for PROD
source scripts/env.dev.sh
bash scripts/00_check_tools.sh
```

| Order | File | Who runs it | START_HERE section |
|---|---|---|---|
| 0 | `00_check_tools.sh` | developer | 1a |
| 1 | `01_azure_setup.sh inspect` then `create-connector`, `create-container`, `grant-synapse-storage-role`, `lifecycle` | Azure identity / storage admin | 4, 5 |
| 2 | `02_databricks_cli_setup.sh create-credential` | UC credential admin | 4 |
| 2b | `render_sql.py uc_check_privileges.sql.template` -> run in a SQL editor (read-only privilege check) | whoever runs the UC steps | 2 |
| 3 | `render_sql.py uc_admin_setup.sql.template` -> run sections A-D, F in a SQL editor | UC admin | 4, 5, 7 |
| 4 | `synapse_00_check_master_key.sql`, then `sql/synapse/03_...`, `01_...` (not in this folder) | Synapse admin | 6 |
| 5 | `synapse_10_...`, `synapse_11_...` (SQL login for the JDBC connection) | Synapse admin | 7 |
| 6 | `uc_admin_setup.sql` section E (connection), `02_databricks_cli_setup.sh create-secret-scope`, `put-webhook-secret`, `grant-secret-read` | UC admin / secrets admin | 7, 8 |
| 7 | `05_github_setup.sh environment`, `variables`, `federated-credential` | release engineer | 10 |
| 8 | `uc_admin_setup.sql` section G (acceptance scratch schema) | UC admin | 10 |

What is **not** scripted, on purpose: creating the Entra job service principal, Synapse DDL by the notebook
(administrators run `sql/synapse/01_export_setup.sql`), unpausing schedules (a reviewed redeploy), and anything
that needs a password (the CLI prompts, or use the UI). Scripts never print or store secrets.

Not yet exercised against a live tenant: run each step in DEV first and compare with the verification line in START_HERE.

The full file-by-file order, including the documents and SQL outside this folder, is the table "File flow" near the top of `docs/START_HERE_COMPLETE_SETUP.md`.
