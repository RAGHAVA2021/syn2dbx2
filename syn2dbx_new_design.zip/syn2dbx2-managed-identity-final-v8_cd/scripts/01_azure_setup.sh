#!/usr/bin/env bash
# Azure-side setup for START_HERE sections 4 and 5. Run one step at a time as the right administrator.
#   source scripts/env.dev.sh
#   bash scripts/01_azure_setup.sh inspect              # read-only; start here
#   CONFIRM=yes bash scripts/01_azure_setup.sh create-connector   # Azure identity admin, only if absent
#   CONFIRM=yes bash scripts/01_azure_setup.sh create-container   # storage admin, only if absent
#   CONFIRM=yes bash scripts/01_azure_setup.sh grant-synapse-storage-role  # storage admin
#   CONFIRM=yes bash scripts/01_azure_setup.sh lifecycle          # storage admin
# Mutating steps print what they would do and stop unless CONFIRM=yes.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_lib.sh
. "$HERE/_lib.sh"
need_cmd az
# Two subscriptions are supported:
#   BRIDGE_SUBSCRIPTION_ID       = subscription of the Databricks access connector (BRIDGE_RESOURCE_GROUP)
#   BRIDGE_DATA_SUBSCRIPTION_ID  = subscription of the Synapse workspace and the staging storage account
#                                  (set it to the same GUID as BRIDGE_SUBSCRIPTION_ID if everything is in one subscription)
# Every az call below names its subscription explicitly; the global "az account set" is not used.
# Each step requires only the subscription(s) it uses.
case "${1:-inspect}" in
  inspect)          need BRIDGE_SUBSCRIPTION_ID BRIDGE_DATA_SUBSCRIPTION_ID BRIDGE_RESOURCE_GROUP BRIDGE_ACCESS_CONNECTOR ;;
  create-connector) need BRIDGE_SUBSCRIPTION_ID BRIDGE_RESOURCE_GROUP BRIDGE_ACCESS_CONNECTOR ;;
  *)                need BRIDGE_DATA_SUBSCRIPTION_ID ;;
esac

container_scope() {
  need BRIDGE_STORAGE_ACCOUNT BRIDGE_STORAGE_RG BRIDGE_STAGING_CONTAINER
  echo "/subscriptions/$BRIDGE_DATA_SUBSCRIPTION_ID/resourceGroups/$BRIDGE_STORAGE_RG/providers/Microsoft.Storage/storageAccounts/$BRIDGE_STORAGE_ACCOUNT/blobServices/default/containers/$BRIDGE_STAGING_CONTAINER"
}
synapse_mi() {
  need BRIDGE_SYNAPSE_WORKSPACE BRIDGE_SYNAPSE_RG
  az synapse workspace show --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --name "$BRIDGE_SYNAPSE_WORKSPACE" --resource-group "$BRIDGE_SYNAPSE_RG" \
    --query identity.principalId -o tsv
}

case "${1:-inspect}" in
  inspect)
    echo "--- Databricks (access connector) subscription"
    az account show --subscription "$BRIDGE_SUBSCRIPTION_ID" --query '{subscription:id,tenant:tenantId,name:name}' -o table
    echo "--- Synapse + storage subscription"
    az account show --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --query '{subscription:id,tenant:tenantId,name:name}' -o table
    echo "--- access connector (the identity Databricks uses to log in to Synapse SQL)"
    az databricks access-connector show --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" \
      --query '{id:id,principalId:identity.principalId,location:location}' -o json \
      || echo "NOT FOUND: ask the Azure identity administrator to approve 'create-connector'"
    if [ -n "${BRIDGE_SYNAPSE_WORKSPACE:-}" ] && [ -n "${BRIDGE_SYNAPSE_RG:-}" ]; then
      echo "--- Synapse WORKSPACE managed identity (the one that needs the storage role)"
      synapse_mi || echo "could not read the Synapse identity (az extension 'synapse' missing, or no access)"
    fi
    if [ -n "${BRIDGE_STORAGE_ACCOUNT:-}" ] && [ -n "${BRIDGE_STAGING_CONTAINER:-}" ]; then
      echo "--- staging container"
      az storage container exists --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --account-name "$BRIDGE_STORAGE_ACCOUNT" --name "$BRIDGE_STAGING_CONTAINER" --auth-mode login -o json || true
      echo "--- existing lifecycle policy on the storage account (the lifecycle step REPLACES it)"
      az storage account management-policy show --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --account-name "$BRIDGE_STORAGE_ACCOUNT" --resource-group "$BRIDGE_STORAGE_RG" -o json 2>/dev/null \
        || echo "none"
    fi
    ;;
  create-connector)
    need BRIDGE_AZURE_REGION
    confirm "create system-assigned access connector '$BRIDGE_ACCESS_CONNECTOR' in $BRIDGE_RESOURCE_GROUP ($BRIDGE_AZURE_REGION)" || exit 0
    az databricks access-connector show --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" >/dev/null 2>&1 \
      && die "access connector already exists; do not recreate it"
    az databricks access-connector create --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" \
      --location "$BRIDGE_AZURE_REGION" --identity-type SystemAssigned -o json
    ;;
  create-container)
    need BRIDGE_STORAGE_ACCOUNT BRIDGE_STAGING_CONTAINER
    confirm "create container '$BRIDGE_STAGING_CONTAINER' in $BRIDGE_STORAGE_ACCOUNT" || exit 0
    az storage container create --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --account-name "$BRIDGE_STORAGE_ACCOUNT" --name "$BRIDGE_STAGING_CONTAINER" --auth-mode login
    ;;
  grant-synapse-storage-role)
    # CETAS writes Parquet with the Synapse WORKSPACE managed identity - NOT the access connector.
    scope="$(container_scope)"
    mi="$(synapse_mi)" || true; [ -n "$mi" ] || die "could not resolve the Synapse workspace managed identity"
    confirm "assign 'Storage Blob Data Contributor' to Synapse workspace identity $mi on $scope" || exit 0
    existing=$(az role assignment list --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --assignee "$mi" --scope "$scope" --role "Storage Blob Data Contributor" --query 'length(@)' -o tsv)
    if [ "$existing" != "0" ]; then echo "already assigned"; exit 0; fi
    az role assignment create --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --assignee-object-id "$mi" --assignee-principal-type ServicePrincipal \
      --role "Storage Blob Data Contributor" --scope "$scope"
    echo "Role assignments can take a few minutes to take effect."
    ;;
  lifecycle)
    need BRIDGE_STORAGE_ACCOUNT BRIDGE_STORAGE_RG BRIDGE_STAGING_CONTAINER BRIDGE_STAGING_PREFIX
    need_cmd python3
    policy="$(mktemp)"; trap 'rm -f "$policy"' EXIT
    python3 - "$HERE/../infra/adls_lifecycle_policy.json" "$policy" "$BRIDGE_STAGING_CONTAINER" "$BRIDGE_STAGING_PREFIX" <<'PY'
import json, sys
src, dst, container, prefix = sys.argv[1:5]
doc = json.load(open(src))
for rule in doc["rules"]:
    rule["definition"]["filters"]["prefixMatch"] = [f"{container}/{prefix}/"]
json.dump(doc, open(dst, "w"), indent=2)
PY
    echo "Policy to apply (deletes staging blobs 3 days after modification):"; cat "$policy"
    if az storage account management-policy show --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --account-name "$BRIDGE_STORAGE_ACCOUNT" --resource-group "$BRIDGE_STORAGE_RG" >/dev/null 2>&1 \
       && [ "${REPLACE_EXISTING_POLICY:-}" != "yes" ]; then
      die "the storage account already has a lifecycle policy; 'create' would REPLACE it. Merge this rule into it by hand, or re-run with REPLACE_EXISTING_POLICY=yes if the storage administrator approves."
    fi
    confirm "apply lifecycle policy to $BRIDGE_STORAGE_ACCOUNT (prefix $BRIDGE_STAGING_CONTAINER/$BRIDGE_STAGING_PREFIX/)" || exit 0
    az storage account management-policy create --subscription "$BRIDGE_DATA_SUBSCRIPTION_ID" --account-name "$BRIDGE_STORAGE_ACCOUNT" \
      --resource-group "$BRIDGE_STORAGE_RG" --policy "@$policy"
    ;;
  *) die "unknown step '$1' (inspect | create-connector | create-container | grant-synapse-storage-role | lifecycle)" ;;
esac
