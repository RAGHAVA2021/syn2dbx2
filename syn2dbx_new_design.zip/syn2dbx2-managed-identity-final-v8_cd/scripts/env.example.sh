#!/usr/bin/env bash
# shellcheck shell=bash disable=SC2034  # sourced file: variables are exported for the other scripts
# Copy to scripts/env.dev.sh (git-ignored), edit EVERY value, then:  source scripts/env.dev.sh
# One file per environment: keep env.dev.sh and env.prod.sh and source the one you mean.
# steps.py loads scripts/env.dev.sh by default; pick this file with BRIDGE_ENV_FILE=scripts/env.prod.sh python3 scripts/steps.py run N
# Names only - never put passwords, tokens, client secrets or webhook URLs in this file.
#
# Every variable below has a "purpose" comment: WHAT it is, WHO/WHAT uses it, and (->) which setting it fills.
# Scripts refuse to run while a value is empty or still contains a <placeholder>.

# --- Azure ---------------------------------------------------------------------------
# Subscription of the DATABRICKS side: it holds the Databricks access connector (BRIDGE_RESOURCE_GROUP below).
# scripts/01_azure_setup.sh and 02_databricks_cli_setup.sh pass it as --subscription to the access-connector commands.
export BRIDGE_SUBSCRIPTION_ID="<databricks-subscription-guid>"
# Subscription of the SYNAPSE + STORAGE side: it holds the Synapse workspace (BRIDGE_SYNAPSE_RG) and the staging
# storage account (BRIDGE_STORAGE_RG). Use the same GUID as BRIDGE_SUBSCRIPTION_ID if everything is in one subscription.
export BRIDGE_DATA_SUBSCRIPTION_ID="<synapse-and-storage-subscription-guid>"
# Resource group of the Databricks access connector, in the BRIDGE_SUBSCRIPTION_ID subscription (01_azure_setup.sh, 02_databricks_cli_setup.sh).
export BRIDGE_RESOURCE_GROUP="<resource-group-of-the-access-connector>"
# Region used ONLY when `create-connector` creates a new access connector.
export BRIDGE_AZURE_REGION="<azure-region, e.g. australiaeast>"
# Name of the access connector whose managed identity Databricks uses to log in to Synapse (the UC service credential points at it).
export BRIDGE_ACCESS_CONNECTOR="<access-connector-name>"        # also the Entra display name of its managed identity
# Synapse workspace name (not the SQL endpoint); used to look up the workspace managed identity that CETAS writes with.
export BRIDGE_SYNAPSE_WORKSPACE="<synapse-workspace-name>"
# Resource group of that Synapse workspace, in the BRIDGE_DATA_SUBSCRIPTION_ID subscription.
export BRIDGE_SYNAPSE_RG="<synapse-resource-group>"
# Storage account (ADLS Gen2) that holds the CETAS staging container.
export BRIDGE_STORAGE_ACCOUNT="<staging-storage-account>"
# Resource group of that storage account, in the BRIDGE_DATA_SUBSCRIPTION_ID subscription.
export BRIDGE_STORAGE_RG="<staging-storage-resource-group>"
# Staging container: CETAS writes Parquet here, the job reads it back; scopes the Storage Blob Data Contributor role and the lifecycle rule.
export BRIDGE_STAGING_CONTAINER="<staging-container>"
# Folder inside the staging container for this job's files; the lifecycle rule only cleans this prefix.
export BRIDGE_STAGING_PREFIX="bridge-stage"                      # must equal staging.prefix in settings.json

# SQL endpoint of the Synapse workspace (what Databricks connects to).
export BRIDGE_SYNAPSE_SERVER="<workspace>.sql.azuresynapse.net"   # -> settings synapse.server
# Dedicated SQL pool (database) name.
export BRIDGE_SYNAPSE_DATABASE="<dedicated-pool-name>"           # -> settings synapse.database
# Name of the Synapse external data source that points at the staging container (created by sql/synapse/01_export_setup.sql).
export BRIDGE_EXTERNAL_DATA_SOURCE="bridge_stage"                # -> settings staging.external_data_source (name in Synapse)
# Name of the Synapse external file format (must be PARQUET; created by 01_export_setup.sql).
export BRIDGE_FILE_FORMAT="bridge_parquet"                       # -> settings staging.file_format (name in Synapse)

# --- Databricks ----------------------------------------------------------------------
# Workspace URL for this environment. Not read by any script: use it when you sign in once,
#   databricks auth login --host "$BRIDGE_DATABRICKS_HOST" --profile "$BRIDGE_DATABRICKS_PROFILE"
# and put the same URL under targets.<env>.workspace.host in databricks.yml (prepare_deploy.py rejects a placeholder).
export BRIDGE_DATABRICKS_HOST="https://<workspace>.azuredatabricks.net"
# Databricks CLI profile every script passes as --profile.
export BRIDGE_DATABRICKS_PROFILE="bridge-dev"                    # bridge-prod for PROD
# Unity Catalog service credential name (wraps the access connector) that the job uses to get a Synapse token.
export BRIDGE_SERVICE_CREDENTIAL="<uc-service-credential-name>"  # = synapse.auth.credential_name
# Application (client) ID of the service principal the nightly jobs run as; receives all grants below.
export BRIDGE_JOB_PRINCIPAL="<job-service-principal-application-id>"
# Databricks secret scope that holds the summary-webhook URL.
export BRIDGE_SECRET_SCOPE="<databricks-secret-scope>"          # = notifications.summary_webhook.secret_scope
# Key (inside that scope) of the secret that holds the HTTPS webhook URL; the URL itself is never stored here.
export BRIDGE_WEBHOOK_SECRET_KEY="nightly-summary-webhook-url"   # = notifications.summary_webhook.url_secret_key

# --- Unity Catalog names (used by render_sql.py) --------------------------------------
# Schema for the job's own log tables (plan, table_log, run_log).
export BRIDGE_CONTROL_SCHEMA="bridge_control"                    # -> settings control.schema
# Catalog that holds that control schema (not business data).
export BRIDGE_CONTROL_CATALOG="<control-catalog>"
# Catalog that holds the target Delta tables (also where the acceptance scratch schema is created).
export BRIDGE_TARGET_CATALOG="<target-catalog>"
# E-mail of the administrator who runs src/setup/00_admin_setup.py; gets ACCESS on the credential and schema-creation rights.
export BRIDGE_SETUP_ADMIN="<admin-user-email-that-runs-00_admin_setup>"
# Name of the UC external location that covers the staging container (reused if it exists; job gets READ + WRITE FILES).
export BRIDGE_STAGING_LOCATION="<existing-or-new-external-location-for-staging>"
# Name of the UC external location that covers the upstream manifest container (job gets READ FILES only).
export BRIDGE_MANIFEST_LOCATION="<existing-or-new-external-location-for-upstream-manifest>"
# UC storage credential used only if an external location above has to be CREATED.
export BRIDGE_STORAGE_CREDENTIAL="<uc-storage-credential-for-those-locations>"
# Full abfss:// path of the daily row-count CSV; must contain exactly one {business_date} or {business_date_compact}.
export BRIDGE_MANIFEST_PATH_TEMPLATE="abfss://<upstream-container>@<upstream-account>.dfs.core.windows.net/upstream-manifests/{business_date}/row_counts.csv"   # -> settings manifest.path_template
# Root URL of the staging container (container only, no folder); must be the same container as BRIDGE_STAGING_CONTAINER.
export BRIDGE_STAGING_URL="abfss://<staging-container>@<staging-account>.dfs.core.windows.net/"   # -> settings staging.root
# Root URL of the upstream manifest container; must match the container in BRIDGE_MANIFEST_PATH_TEMPLATE.
export BRIDGE_MANIFEST_URL="abfss://<upstream-container>@<upstream-account>.dfs.core.windows.net/"
# Catalog of the Unity Catalog volume that stores the Microsoft JDBC driver JAR.
export BRIDGE_DRIVER_CATALOG="<catalog-for-the-jdbc-driver-volume>"
# Schema of that volume.
export BRIDGE_DRIVER_SCHEMA="bridge_admin"
# Volume name that stores the JAR.
export BRIDGE_DRIVER_VOLUME="jdbc_drivers"
# File name of the JDBC driver JAR you upload to the volume.
export BRIDGE_DRIVER_JAR="mssql-jdbc-<version>.jar"
# Name of the UC JDBC connection the fallback reads Synapse through (created by hand, never by the package).
export BRIDGE_JDBC_CONNECTION="<uc-jdbc-connection-name>"        # = synapse.uc_jdbc_connection
# JDBC URL stored inside that connection; server and database must match BRIDGE_SYNAPSE_SERVER / BRIDGE_SYNAPSE_DATABASE.
export BRIDGE_JDBC_URL="jdbc:sqlserver://<workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.sql.azuresynapse.net;loginTimeout=30"
# Read-only SQL login the JDBC connection uses (the password is typed in the UI, never here).
export BRIDGE_JDBC_USER="bridge_jdbc_reader"                 # must equal the login name in synapse_10_*.sql and synapse_11_*.sql (edit all three together)
# Schema (in BRIDGE_TARGET_CATALOG) where the acceptance job creates and drops its scratch table.
export BRIDGE_SCRATCH_SCHEMA="bridge_acceptance_scratch"

# --- GitHub (05_github_setup.sh) -------------------------------------------------------
# Repository that runs the deploy workflows, as owner/name.
export BRIDGE_GITHUB_REPO="<owner>/<repo>"
# GitHub Environment this file configures; the workflow environment name equals the bundle target.
export BRIDGE_GITHUB_ENV="dev"                                   # dev or prod
# Environment variable EXPORT_CONCURRENCY: tables exported at the same time = concurrent CETAS statements on the pool.
export BRIDGE_EXPORT_CONCURRENCY="4"                               # GitHub variable EXPORT_CONCURRENCY; start small
# Client ID of the Entra application the workflow signs in as (GitHub OIDC); gets the federated credential.
export BRIDGE_DEPLOY_APP_ID="<entra-deploy-application-client-id>"
# Entra tenant ID used by azure/login in the workflow.
export BRIDGE_TENANT_ID="<entra-tenant-id>"
# Address that receives Databricks job-failure e-mails (bundle variable notification_email).
export BRIDGE_NOTIFICATION_EMAIL="<alert-email>"
# Group allowed to rerun the nightly job (bundle variable operations_group).
export BRIDGE_OPERATIONS_GROUP="<operations-group>"
# Separate group allowed to run the privileged rollback and acceptance jobs (bundle variable rollback_approvers_group).
export BRIDGE_ROLLBACK_APPROVERS_GROUP="<rollback-approvers-group>"

# --- Feature-branch testing (phase B) --------------------------------------------------
# Your Databricks user e-mail: personal schemas feature_<you>_* are derived from it, and the feature bundle runs as you.
export BRIDGE_FEATURE_USER="<your-databricks-user-email>"        # personal schemas feature_<you>_* are made from this
