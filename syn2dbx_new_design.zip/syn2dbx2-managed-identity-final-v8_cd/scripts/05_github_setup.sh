#!/usr/bin/env bash
# GitHub Environments, variables and Entra federated credential (START_HERE section 10 / GITHUB_OIDC_SETUP.md).
#   source scripts/env.dev.sh          # set BRIDGE_GITHUB_ENV=dev, later prod
#   bash scripts/05_github_setup.sh inspect
#   CONFIRM=yes bash scripts/05_github_setup.sh environment
#   CONFIRM=yes bash scripts/05_github_setup.sh variables
#   OIDC_SUBJECT='<exact subject>' CONFIRM=yes bash scripts/05_github_setup.sh federated-credential
# PROD reviewers (required): export PROD_REVIEWER_USER_IDS="123,456" (numeric GitHub user ids) before 'environment'.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_lib.sh
. "$HERE/_lib.sh"
need BRIDGE_GITHUB_REPO BRIDGE_GITHUB_ENV
case "$BRIDGE_GITHUB_ENV" in dev|prod) ;; *) die "BRIDGE_GITHUB_ENV must be dev or prod" ;; esac

case "${1:-inspect}" in
  inspect)
    need_cmd gh
    gh api "repos/$BRIDGE_GITHUB_REPO/environments" --jq '.environments[] | {name, protection_rules: [.protection_rules[].type]}'
    gh variable list --repo "$BRIDGE_GITHUB_REPO" --env "$BRIDGE_GITHUB_ENV" 2>/dev/null || true
    ;;
  environment)
    need_cmd gh
    if [ "$BRIDGE_GITHUB_ENV" = "prod" ]; then
      : "${PROD_REVIEWER_USER_IDS:?set PROD_REVIEWER_USER_IDS (comma-separated numeric GitHub user ids): PROD must require reviewers}"
      reviewers=$(printf '%s' "$PROD_REVIEWER_USER_IDS" | awk -F, '{for(i=1;i<=NF;i++){printf "%s{\"type\":\"User\",\"id\":%d}", (i>1?",":""), $i}}')
      body="{\"reviewers\":[${reviewers}],\"deployment_branch_policy\":{\"protected_branches\":true,\"custom_branch_policies\":false}}"
    else
      body='{}'
    fi
    confirm "create/update GitHub environment '$BRIDGE_GITHUB_ENV' in $BRIDGE_GITHUB_REPO" || exit 0
    printf '%s' "$body" | gh api -X PUT "repos/$BRIDGE_GITHUB_REPO/environments/$BRIDGE_GITHUB_ENV" --input -
    ;;
  variables)
    need_cmd gh
    need BRIDGE_DEPLOY_APP_ID BRIDGE_TENANT_ID BRIDGE_JOB_PRINCIPAL BRIDGE_NOTIFICATION_EMAIL \
         BRIDGE_OPERATIONS_GROUP BRIDGE_ROLLBACK_APPROVERS_GROUP
    confirm "set the environment variables of '$BRIDGE_GITHUB_ENV' (schedules stay PAUSED)" || exit 0
    setv() { gh variable set "$1" --env "$BRIDGE_GITHUB_ENV" --repo "$BRIDGE_GITHUB_REPO" --body "$2"; }
    setv AZURE_CLIENT_ID "$BRIDGE_DEPLOY_APP_ID"
    setv AZURE_TENANT_ID "$BRIDGE_TENANT_ID"
    # Optional. The deploy identity only needs a subscription if it holds an Azure role; use the subscription it was granted in.
    [ -z "${BRIDGE_SUBSCRIPTION_ID:-}" ] || setv AZURE_SUBSCRIPTION_ID "$BRIDGE_SUBSCRIPTION_ID"
    setv DATABRICKS_JOB_IDENTITY "$BRIDGE_JOB_PRINCIPAL"
    setv NOTIFICATION_EMAIL "$BRIDGE_NOTIFICATION_EMAIL"
    setv OPERATIONS_GROUP "$BRIDGE_OPERATIONS_GROUP"
    setv ROLLBACK_APPROVERS_GROUP "$BRIDGE_ROLLBACK_APPROVERS_GROUP"
    setv EXPORT_CONCURRENCY "${BRIDGE_EXPORT_CONCURRENCY:-4}"
    # Pause flags are set to PAUSED only when they do not exist yet. Re-running this step after go-live must NOT
    # silently re-pause (or un-pause) a schedule that the release approver changed on purpose.
    for flag in NIGHTLY_PAUSE_STATUS MAINTENANCE_PAUSE_STATUS; do
      if gh variable get "$flag" --env "$BRIDGE_GITHUB_ENV" --repo "$BRIDGE_GITHUB_REPO" >/dev/null 2>&1; then
        echo "keeping existing $flag"
      else
        setv "$flag" PAUSED
      fi
    done
    ;;
  federated-credential)
    need_cmd az
    need BRIDGE_DEPLOY_APP_ID
    : "${OIDC_SUBJECT:?set OIDC_SUBJECT to the EXACT subject your repository emits (see docs/GITHUB_OIDC_SETUP.md section 2); it is never guessed here}"
    name="github-${BRIDGE_GITHUB_ENV}"
    confirm "create federated credential '$name' on app $BRIDGE_DEPLOY_APP_ID for subject $OIDC_SUBJECT" || exit 0
    body=$(printf '{"name":"%s","issuer":"https://token.actions.githubusercontent.com","subject":"%s","audiences":["api://AzureADTokenExchange"]}' "$name" "$OIDC_SUBJECT")
    az ad app federated-credential create --id "$BRIDGE_DEPLOY_APP_ID" --parameters "$body"
    ;;
  *) die "unknown step '$1' (inspect | environment | variables | federated-credential)" ;;
esac
