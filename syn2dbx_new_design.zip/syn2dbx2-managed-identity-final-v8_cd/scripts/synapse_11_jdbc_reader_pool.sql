-- Synapse administrator. Connect to the DEDICATED POOL database (not master). Run AFTER synapse_10.
CREATE USER bridge_jdbc_reader FOR LOGIN bridge_jdbc_reader;
GRANT SELECT ON SCHEMA::[dbo] TO bridge_jdbc_reader;   -- repeat for EVERY source schema
-- Verify:
SELECT dp.name, dp.type_desc FROM sys.database_principals dp WHERE dp.name = 'bridge_jdbc_reader';
