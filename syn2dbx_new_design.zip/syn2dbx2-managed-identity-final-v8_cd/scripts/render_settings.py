#!/usr/bin/env python3
"""Write config/settings.json from config/settings.example.json and the BRIDGE_* values in your env file.

    source scripts/env.dev.sh
    python3 scripts/render_settings.py [--output config/settings.json] [--force]

Fills the environment-specific values (Synapse endpoint and pool, credential and connection names, storage,
control schema, manifest path, webhook secret names) so each value is typed once, in the env file. Everything
else (cutoffs, batch sizes, column names ...) keeps the example's value: review it. Refuses to overwrite an
existing file without --force, and fails if any <placeholder> is left. No secret is read or written.
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

# Package root folder.
ROOT = Path(__file__).resolve().parents[1]

# (path in settings, environment variable, transform)
MAPPING = [
    (("synapse", "server"), "BRIDGE_SYNAPSE_SERVER", None),
    (("synapse", "database"), "BRIDGE_SYNAPSE_DATABASE", None),
    (("synapse", "auth", "credential_name"), "BRIDGE_SERVICE_CREDENTIAL", None),
    (("synapse", "uc_jdbc_connection"), "BRIDGE_JDBC_CONNECTION", None),
    (("manifest", "path_template"), "BRIDGE_MANIFEST_PATH_TEMPLATE", None),
    (("staging", "root"), "BRIDGE_STAGING_URL", lambda v: v.rstrip("/")),
    (("staging", "prefix"), "BRIDGE_STAGING_PREFIX", None),
    (("staging", "external_data_source"), "BRIDGE_EXTERNAL_DATA_SOURCE", None),
    (("staging", "file_format"), "BRIDGE_FILE_FORMAT", None),
    (("control", "catalog"), "BRIDGE_CONTROL_CATALOG", None),
    (("control", "schema"), "BRIDGE_CONTROL_SCHEMA", None),
    (("notifications", "summary_webhook", "secret_scope"), "BRIDGE_SECRET_SCOPE", None),
    (("notifications", "summary_webhook", "url_secret_key"), "BRIDGE_WEBHOOK_SECRET_KEY", None),
]


def consistency_problems(env):
    """Values that appear twice in the env file must agree (each is typed once per purpose, so they can drift).

    Only pairs where both variables are set are compared.
    """
    problems = []
    get = lambda k: env.get(k, "")
    root = re.fullmatch(r"abfss://([^@/]+)@([^./]+)\.dfs\.core\.windows\.net/?", get("BRIDGE_STAGING_URL"))
    if root:
        if get("BRIDGE_STAGING_CONTAINER") and root.group(1) != get("BRIDGE_STAGING_CONTAINER"):
            problems.append("BRIDGE_STAGING_URL container differs from BRIDGE_STAGING_CONTAINER")
        if get("BRIDGE_STORAGE_ACCOUNT") and root.group(2) != get("BRIDGE_STORAGE_ACCOUNT"):
            problems.append("BRIDGE_STAGING_URL storage account differs from BRIDGE_STORAGE_ACCOUNT")
    manifest_url, template = get("BRIDGE_MANIFEST_URL"), get("BRIDGE_MANIFEST_PATH_TEMPLATE")
    if manifest_url and template and not template.startswith(manifest_url.rstrip("/") + "/"):
        problems.append("BRIDGE_MANIFEST_PATH_TEMPLATE is not under BRIDGE_MANIFEST_URL")
    jdbc = get("BRIDGE_JDBC_URL")
    if jdbc:
        host = re.search(r"jdbc:sqlserver://([^:;/]+)", jdbc)
        db = re.search(r"database(?:Name)?=([^;]+)", jdbc, re.I)
        if host and get("BRIDGE_SYNAPSE_SERVER") and host.group(1) != get("BRIDGE_SYNAPSE_SERVER"):
            problems.append("BRIDGE_JDBC_URL host differs from BRIDGE_SYNAPSE_SERVER")
        if db and get("BRIDGE_SYNAPSE_DATABASE") and db.group(1) != get("BRIDGE_SYNAPSE_DATABASE"):
            problems.append("BRIDGE_JDBC_URL database differs from BRIDGE_SYNAPSE_DATABASE")
    return problems


def render(example, env):
    doc = json.loads(json.dumps(example))
    missing = []
    for path, var, transform in MAPPING:
        value = env.get(var, "")
        if not value:
            missing.append(var)
            continue
        if re.search(r"<[^>]*>", value):
            missing.append(f"{var} (still a <placeholder>)")
            continue
        node = doc
        for key in path[:-1]:
            node = node[key]
        node[path[-1]] = transform(value) if transform else value
    if missing:
        raise ValueError("Cannot render settings; set in your env file: " + ", ".join(missing))
    drift = consistency_problems(env)
    if drift:
        raise ValueError("Cannot render settings; these env values disagree: " + "; ".join(drift))
    left = [m for m in re.findall(r"<[^>]*>", json.dumps({k: v for k, v in doc.items() if k != "_comments"}))]
    if left:
        raise ValueError("placeholders still present in the settings: " + ", ".join(sorted(set(left))))
    return doc


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--example", default=str(ROOT / "config" / "settings.example.json"))
    ap.add_argument("--output", default=str(ROOT / "config" / "settings.json"))
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args(argv)
    out = Path(a.output)
    if out.exists() and not a.force:
        print(f"{out} already exists; not overwriting (use --force).", file=sys.stderr)
        return 1
    try:
        doc = render(json.loads(Path(a.example).read_text(encoding="utf-8")), os.environ)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    out.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {out}. Review inventory_version, source_set_id, cutoffs and manifest column names before use.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
