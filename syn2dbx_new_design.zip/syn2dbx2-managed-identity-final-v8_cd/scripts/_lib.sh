#!/usr/bin/env bash
# Shared helpers, sourced by the other scripts. Not run directly.
set -euo pipefail

die() { echo "ERROR: $*" >&2; exit 1; }
need() { # need VAR [VAR...] : fail if unset or still a <placeholder>
  local v
  for v in "$@"; do
    [ -n "${!v:-}" ] || die "$v is not set. Copy scripts/env.example.sh to scripts/env.dev.sh, edit it and 'source' it."
    case "${!v}" in *"<"*">"*) die "$v still contains a <placeholder>: ${!v}" ;; esac
  done
}
need_cmd() { command -v "$1" >/dev/null 2>&1 || die "'$1' is not installed or not on PATH (see docs/START_HERE_COMPLETE_SETUP.md section 1a)"; }
confirm() { # confirm "what will happen" : mutating steps need CONFIRM=yes
  if [ "${CONFIRM:-}" != "yes" ]; then
    echo "DRY RUN: $1"
    echo "         Re-run with CONFIRM=yes after the change is approved."
    return 1
  fi
  echo "APPLYING: $1"
}
