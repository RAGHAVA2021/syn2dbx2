-- Synapse administrator, connected to the DEDICATED POOL database. Read-only.
-- If this returns no row, create the key (once; password from your password manager, never saved):
--     CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<administrator-supplied-strong-secret>';
-- If it returns a row, do NOT replace the key.
SELECT name, create_date FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##';
-- Also confirms where you are connected (must be the dedicated pool, not master / Built-in):
SELECT DB_NAME() AS database_name, SUSER_SNAME() AS login_name;
