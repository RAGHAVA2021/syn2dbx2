#!/usr/bin/env python3
"""Render a ${VAR} SQL template from the BRIDGE_* environment variables (scripts/env.dev.sh).

    source scripts/env.dev.sh
    python3 scripts/render_sql.py scripts/uc_admin_setup.sql.template > build/uc_admin_setup.sql

Fails on any unset variable or leftover <placeholder>, and rejects values that could break out of a
`quoted` identifier or '...' literal. Passwords are deliberately NOT read from the environment.
"""
import os
import re
import string
import sys

# Characters rejected in a substituted value: backtick, quote, semicolon, backslash, newline (would break out of quotes).
BAD = re.compile(r"[`';\n\r\\]")
# Same, but a semicolon is allowed (a JDBC URL legitimately contains ";" and is used inside '...').
BAD_URL = re.compile(r"[`'\n\r\\]")
# Variables checked with BAD_URL instead of BAD.
SEMICOLON_OK = {"BRIDGE_JDBC_URL"}


def render(text, env):
    names = set()
    for m in string.Template.pattern.finditer(text):
        if m.group("invalid") is not None:
            raise ValueError("Cannot render: a stray '$' in the template")
        name = m.group("named") or m.group("braced")
        if name:
            names.add(name)
    problems = []
    values = {}
    for name in sorted(names):
        value = env.get(name, "")
        if not value:
            problems.append(f"{name} is not set")
        elif re.search(r"<[^>]*>", value):
            problems.append(f"{name} still contains a <placeholder>: {value}")
        elif (BAD_URL if name in SEMICOLON_OK else BAD).search(value):
            allowed = "a quote, backtick, backslash or newline" if name in SEMICOLON_OK else "a quote, backtick, semicolon, backslash or newline"
            problems.append(f"{name} contains {allowed}")
        values[name] = value
    if problems:
        raise ValueError("Cannot render:\n  " + "\n  ".join(problems))
    return string.Template(text).substitute(values)


def main(argv):
    if len(argv) != 2:
        print(__doc__, file=sys.stderr)
        return 2
    try:
        sys.stdout.write(render(open(argv[1], encoding="utf-8").read(), os.environ))
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
