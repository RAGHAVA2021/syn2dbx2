-- Synapse administrator. Connect to database  master  on the Synapse workspace endpoint
-- (<workspace>.sql.azuresynapse.net). SQL authentication must be enabled on the workspace.
-- Generate the password in a password manager. NEVER save it here, in Git or in a ticket.
-- Skip the whole file if the organisation allows Entra only: use an OAuth M2M service principal instead.
CREATE LOGIN bridge_jdbc_reader WITH PASSWORD = '<generated-strong-password>';
