#!/usr/bin/env python3
"""The numbered setup steps, in run order. One list, one config file.

    python3 scripts/steps.py list              # all steps, [x] = marked done
    python3 scripts/steps.py show 7            # who, where, what, and how to check it
    python3 scripts/steps.py run 7             # do (or prepare) step 7
    python3 scripts/steps.py done 7            # tick it off (also: undo 7)
    python3 scripts/steps.py markdown          # prints docs/STEP_BY_STEP.md

Config: ONE file per environment, scripts/env.dev.sh (copy scripts/env.example.sh) or scripts/env.prod.sh.
Pick it with  BRIDGE_ENV_FILE=scripts/env.prod.sh python3 scripts/steps.py run 7  (default env.dev.sh).
`run` loads it for you; you do not need to `source` it.

Kinds:  cmd      shell commands run here (the scripts they call are dry-run until CONFIRM=yes)
        sql      SQL rendered to build/stepNN.sql for you to paste into the tool named under "where"
        manual   nothing to run; follow the document section
Nothing here stores or prints a secret; passwords and URLs are typed at a prompt.
"""
import os
import re
import subprocess
import sys
from pathlib import Path

# Package root folder.
ROOT = Path(__file__).resolve().parents[1]
# Folder for rendered SQL and the done-markers (git-ignored).
BUILD = ROOT / "build"
sys.path.insert(0, str(ROOT / "scripts"))

A, B, C = ("A. Platform setup (once per environment, DEV first)",
           "B. Feature branch (your own Databricks user and schemas)",
           "C. Release (GitHub runner and service principal)")
# Template holding the sectioned UC administrator SQL.
UC = "scripts/uc_admin_setup.sql.template"
# BUNDLE_VAR_* values prefixed to databricks bundle commands for the personal feature target.
BV = ('BUNDLE_VAR_job_identity="$BRIDGE_FEATURE_USER" BUNDLE_VAR_notification_email="$BRIDGE_NOTIFICATION_EMAIL" '
      'BUNDLE_VAR_operations_group="$BRIDGE_OPERATIONS_GROUP" BUNDLE_VAR_rollback_approvers_group="$BRIDGE_ROLLBACK_APPROVERS_GROUP"')
# Databricks CLI profile argument taken from the env file.
PROFILE = '--profile "$BRIDGE_DATABRICKS_PROFILE"'

# The ordered setup steps (n, phase, who, where, kind, commands/files, note, check). docs/STEP_BY_STEP.md is generated from this list.
STEPS = [
 dict(n=1, phase=A, title="Fill the config file and check your tools", who="Developer", where="Terminal", kind="cmd",
      cmds=["bash scripts/00_check_tools.sh"], doc="1, 1a",
      note="First: cp scripts/env.example.sh scripts/env.dev.sh and edit EVERY value. Then az login and databricks auth login.",
      check="Every required tool prints a version."),
 dict(n=2, phase=A, title="Check your Unity Catalog privileges", who="Whoever runs the UC steps", where="Databricks SQL editor",
      kind="sql", template="scripts/uc_check_privileges.sql.template", doc="2",
      check="You hold CREATE SERVICE CREDENTIAL, CREATE CONNECTION, USE CATALOG, CREATE SCHEMA, and own or manage what you must grant on."),
 dict(n=3, phase=A, title="Register the job service principal", who="Entra and Databricks admins", where="Azure Portal and Databricks account console",
      kind="manual", doc="3", check="The principal exists in the workspace; you know its application ID (BRIDGE_JOB_PRINCIPAL)."),
 dict(n=4, phase=A, title="Inspect Azure (connector, Synapse identity, storage, lifecycle)", who="Azure admin", where="Terminal", kind="cmd",
      cmds=["bash scripts/01_azure_setup.sh inspect"], doc="4, 5", check="Shows the access connector, Synapse workspace identity and any existing lifecycle policy."),
 dict(n=5, phase=A, title="Create the access connector (only if step 4 said NOT FOUND)", who="Azure admin", where="Terminal", kind="cmd",
      cmds=["bash scripts/01_azure_setup.sh create-connector"], doc="4", note="Dry run until you add CONFIRM=yes.",
      check="az databricks access-connector show returns an id and principalId."),
 dict(n=6, phase=A, title="Create the UC service credential", who="UC credential owner", where="Terminal", kind="cmd",
      cmds=["bash scripts/02_databricks_cli_setup.sh create-credential"], doc="4", note="Dry run until you add CONFIRM=yes.",
      check="databricks credentials get-credential shows it."),
 dict(n=7, phase=A, title="Grant ACCESS on the credential (job principal and setup admin)", who="Credential owner", where="Databricks SQL editor",
      kind="sql", template=UC, section="B", doc="4", check="SHOW GRANTS ON SERVICE CREDENTIAL lists both."),
 dict(n=8, phase=A, title="Staging container and the Synapse storage role", who="Storage admin", where="Terminal", kind="cmd",
      cmds=["bash scripts/01_azure_setup.sh create-container", "bash scripts/01_azure_setup.sh grant-synapse-storage-role"], doc="5",
      note="Skip create-container if it exists. Dry run until CONFIRM=yes. The role can take minutes to apply.",
      check="The Synapse workspace identity holds Storage Blob Data Contributor on the staging container."),
 dict(n=9, phase=A, title="Staging cleanup (lifecycle) rule", who="Storage admin", where="Terminal", kind="cmd",
      cmds=["bash scripts/01_azure_setup.sh lifecycle"], doc="5", note="Stops if the account already has a policy (create would replace it).",
      check="The rule exists for <container>/<prefix>/ only."),
 dict(n=10, phase=A, title="External-location grants (staging and manifest)", who="Location owner", where="Databricks SQL editor",
      kind="sql", template=UC, section="C", doc="5", check="Job principal: READ+WRITE FILES on staging, READ FILES only on manifest."),
 dict(n=11, phase=A, title="Synapse: check the master key and review credential scope", who="Synapse admin (Entra admin of the workspace)", where="Synapse Studio, dedicated pool",
      kind="manual", files=["scripts/synapse_00_check_master_key.sql", "sql/synapse/03_review_credential_scope.sql"], doc="6",
      check="A master key exists (create it with a vaulted password if not); the credential scope is approved."),
 dict(n=12, phase=A, title="Synapse: export objects and grants", who="Synapse admin", where="Synapse Studio, dedicated pool",
      kind="manual", files=["sql/synapse/01_export_setup.sql"], doc="6", note="Edit the four values at the top first.",
      check="bridge_stage, bridge_parquet, bridge_msi, bridge_meta exist; a tiny CETAS export works."),
 dict(n=13, phase=A, title="Synapse: read-only login for the JDBC fallback", who="Synapse admin", where="Synapse Studio (master, then the pool)",
      kind="manual", files=["scripts/synapse_10_jdbc_reader_master.sql", "scripts/synapse_11_jdbc_reader_pool.sql"], doc="7",
      note="Replace the password at a prompt or in the editor only; never save it.", check="The user exists in the pool with SELECT on every source schema."),
 dict(n=14, phase=A, title="JDBC driver volume (then upload the JAR)", who="UC admin", where="Databricks SQL editor and Catalog Explorer",
      kind="sql", template=UC, section="D", doc="7", note="Upload the Microsoft JDBC JAR to the volume after running it.",
      check="LIST on the volume shows the JAR."),
 dict(n=15, phase=A, title="Create the UC JDBC connection and grant USE CONNECTION", who="Connection admin", where="Catalog Explorer (preferred) or SQL editor",
      kind="sql", template=UC, section="E", doc="7", check="DESCRIBE CONNECTION works; the job principal has USE CONNECTION."),
 dict(n=16, phase=A, title="Notification receiver and its secret", who="Logic Apps and secrets admins", where="Azure Portal, then terminal", kind="cmd",
      cmds=["bash scripts/02_databricks_cli_setup.sh create-secret-scope", "bash scripts/02_databricks_cli_setup.sh put-webhook-secret",
            "bash scripts/02_databricks_cli_setup.sh grant-secret-read"], doc="8",
      note="First create the Logic App with infra/summary_webhook_schema.json (Portal). put-webhook-secret needs an interactive terminal.",
      check="The job principal can read the secret (the acceptance job proves it)."),
 dict(n=17, phase=A, title="Privileges for the person running the setup notebook", who="UC admin", where="Databricks SQL editor",
      kind="sql", template=UC, section="F", doc="9", check="You can create schemas in the control and target catalogs."),
 dict(n=18, phase=A, title="Generate config/settings.json from your config file", who="Developer", where="Terminal", kind="cmd",
      cmds=["python3 scripts/render_settings.py"], doc="9", note="Review inventory_version, source_set_id, cutoffs and manifest columns afterwards.",
      check="config/settings.json exists with no <placeholder>."),
 dict(n=19, phase=A, title="Databricks-side permission test (run as yourself)", who="Whoever will set up and test", where="Databricks notebook (Git folder)",
      kind="manual", files=["src/setup/01_permission_check.py"], doc="2, 9",
      note="Needs config/settings.json (step 18). Proves YOUR user can use the catalogs, create schemas, get the Synapse token, log in to the pool, read/write staging, read the manifest, run the JDBC connection and read the webhook secret. Re-run after fixing any FAIL line.",
      check="ALL PERMISSION CHECKS PASSED."),
 dict(n=20, phase=A, title="Setup notebook: preflight, synapse_setup, inventory, uc_setup", who="Developer and UC admin", where="Databricks notebook (Git folder)",
      kind="manual", files=["src/setup/00_admin_setup.py"], doc="9, Appendix A5",
      note="Produces and reviews config/inventory.dev.json. Commit the reviewed inventory.", check="Dry run first, then apply; tables exist."),
 dict(n=21, phase=A, title="GitHub: environments, variables, Entra federated credential", who="Release engineer", where="Terminal", kind="cmd",
      cmds=["bash scripts/05_github_setup.sh environment", "bash scripts/05_github_setup.sh variables", "bash scripts/05_github_setup.sh federated-credential"],
      doc="10, Appendix A6", note="PROD needs PROD_REVIEWER_USER_IDS. federated-credential needs OIDC_SUBJECT (the exact subject your repo emits). Dry run until CONFIRM=yes.",
      check="Environments dev and prod exist; azure/login succeeds in the workflow."),
 dict(n=22, phase=B, title="Make your personal inventory and reset SQL", who="You", where="Terminal", kind="cmd",
      cmds=['python3 tools/make_feature_inventory.py --user "$BRIDGE_FEATURE_USER"'], doc="10 (feature branch)",
      note="Writes config/inventory.feature.json (schemas feature_<you>_*) and build/feature_reset.sql. Add --webhook-secret-scope/--webhook-secret-key for a TEST webhook.",
      check="It lists your personal schemas; none equals a DEV schema."),
 dict(n=23, phase=B, title="Create your personal schemas and tables", who="You", where="Databricks notebook (Git folder, feature branch)",
      kind="manual", files=["src/setup/00_admin_setup.py"], doc="9, 10",
      note="action=uc_setup with inventory_file=config/inventory.feature.json and job_principal=your own e-mail.", check="Tables exist under feature_<you>_*."),
 dict(n=24, phase=B, title="Deploy your personal bundle (target feature)", who="You", where="Terminal", kind="cmd",
      cmds=["python3 tools/prepare_deploy.py --environment feature", f"{BV} databricks bundle validate -t feature {PROFILE}",
            f"{BV} databricks bundle deploy -t feature {PROFILE}"], doc="10",
      note="Set the dev workspace host under targets.feature in databricks.yml first. Jobs run as you; schedules stay paused.",
      check="Jobs named [dev you] ... appear, Run as = you."),
 dict(n=25, phase=B, title="Run acceptance and a trial on your feature branch", who="You", where="Databricks Jobs UI or CLI", kind="manual", doc="10 steps 6-7",
      note="databricks bundle run acceptance -t feature --params scratch_schema=<catalog>.feature_<you>_acceptance,grant_principal=<test-group>; then the nightly job with business_date=<today> and only_mappings=<2-3 ids>.",
      check="ALL ACCEPTANCE CHECKS PASSED; trial tables are PUBLISHED."),
 dict(n=26, phase=B, title="Clean up after testing (DESTRUCTIVE)", who="You", where="Databricks SQL editor", kind="sql", sql_file="build/feature_reset.sql", doc="10",
      note="Drops only feature_<you>_* schemas through Unity Catalog. Delete bridge-stage-feature-<you> in storage by hand. Never delete table files directly.",
      check="SHOW SCHEMAS no longer lists your personal schemas."),
 dict(n=27, phase=C, title="Open the pull request and merge to main", who="You and reviewers", where="GitHub", kind="manual", doc="10, 11",
      check="CI tests pass; the merge deploys DEV (only DEV)."),
 dict(n=28, phase=C, title="DEV: acceptance schema, acceptance job, trial run", who="Release engineer", where="Databricks SQL editor and Jobs UI",
      kind="sql", template=UC, section="G", doc="10 steps 6-7",
      note="Then run the acceptance job and the 2-3 table trial as in section 10.", check="ALL ACCEPTANCE CHECKS PASSED on the deployed DEV job."),
 dict(n=29, phase=C, title="PROD platform setup", who="Same admins, PROD names", where="As steps 2-21", kind="manual", doc="11",
      note="Repeat steps 2-21 with BRIDGE_ENV_FILE=scripts/env.prod.sh. Never reuse DEV credentials or storage prefixes.", check="Every step 2-21 passed for PROD."),
 dict(n=30, phase=C, title="Promote the tested commit to PROD", who="Release engineer and approver", where="GitHub Actions", kind="manual", doc="11",
      note="ci-cd > Run workflow on main > prod > dev_acceptance_evidence. Keep schedules paused; run PROD acceptance and a small trial.",
      check="PROD acceptance passes with the same commit SHA as DEV."),
 dict(n=31, phase=C, title="Go-live: unpause and sign off", who="Approver", where="GitHub and Databricks", kind="manual", doc="11, go-live checklist",
      note="Set NIGHTLY_PAUSE_STATUS=UNPAUSED on the prod Environment, then redeploy the same commit.", check="Checklist signed; first scheduled night reviewed."),
]


def section_text(text, letter):
    parts = re.split(r"(?m)^(?=-- ===== [A-Z]\. )", text)
    for part in parts:
        if part.startswith(f"-- ===== {letter}. "):
            return part
    raise KeyError(f"section {letter} not found")


def env_file():
    return Path(os.environ.get("BRIDGE_ENV_FILE", ROOT / "scripts" / "env.dev.sh"))


def load_env():
    """Variables exported by the env file, merged over the current environment."""
    f = env_file()
    if not f.exists():
        raise SystemExit(f"{f} not found. Copy scripts/env.example.sh to {f.name} and edit every value.")
    out = subprocess.run(["bash", "-c", 'set -a; . "$1"; set +a; env -0', "x", str(f)], capture_output=True, check=True).stdout
    env = dict(os.environ)
    for item in out.split(b"\0"):
        if b"=" in item:
            k, v = item.decode().split("=", 1)
            env[k] = v
    return env


def done_set():
    f = BUILD / f".steps_done_{env_file().stem}"
    return {int(x) for x in f.read_text().split()} if f.exists() else set()


def mark(n, on):
    BUILD.mkdir(exist_ok=True)
    s = done_set()
    (s.add if on else s.discard)(n)
    (BUILD / f".steps_done_{env_file().stem}").write_text(" ".join(str(x) for x in sorted(s)))


def get(n):
    for s in STEPS:
        if s["n"] == n:
            return s
    raise SystemExit(f"no step {n}; valid steps are 1-{len(STEPS)}")


def show(s):
    print(f"Step {s['n']}: {s['title']}\n  phase: {s['phase']}\n  who:   {s['who']}\n  where: {s['where']}\n  kind:  {s['kind']}\n  doc:   docs/START_HERE_COMPLETE_SETUP.md section {s['doc']}")
    for c in s.get("cmds", []):
        print(f"  cmd:   {c}")
    for f in s.get("files", []):
        print(f"  file:  {f}")
    if s.get("template"):
        print(f"  sql:   {s['template']}" + (f" (section {s['section']})" if s.get("section") else ""))
    if s.get("sql_file"):
        print(f"  sql:   {s['sql_file']}")
    if s.get("note"):
        print(f"  note:  {s['note']}")
    print(f"  check: {s['check']}")


def run(s):
    show(s)
    print()
    if s["kind"] == "cmd":
        env = load_env()
        for c in s["cmds"]:
            print(f"$ {c}")
            if subprocess.run(["bash", "-c", c], cwd=ROOT, env=env).returncode != 0:
                raise SystemExit(f"step {s['n']} stopped: the command above failed (see its message)")
        if any("bash scripts/0" in c or "bash scripts/05" in c for c in s["cmds"]):
            print("\nIf a command only printed DRY RUN, review it and re-run it with CONFIRM=yes in front.")
    elif s["kind"] == "sql":
        BUILD.mkdir(exist_ok=True)
        out = BUILD / f"step{s['n']:02d}.sql"
        if s.get("sql_file"):
            if not (ROOT / s["sql_file"]).exists():
                raise SystemExit("run step 22 (make your feature inventory) first: it generates "
                                 + s["sql_file"] + "; review it before executing this cleanup step")
            text = (ROOT / s["sql_file"]).read_text()
        else:
            import render_sql
            raw = (ROOT / s["template"]).read_text()
            if s.get("section"):
                raw = section_text(raw, s["section"])
            try:
                text = render_sql.render(raw, load_env())
            except ValueError as exc:
                raise SystemExit(str(exc))
        out.write_text(text)
        print(f"Wrote {out.relative_to(ROOT)}. Open it and run it in: {s['where']}.")
    else:
        print("Nothing to run. Follow the document section above, then check the result.")
    print(f"\nWhen the check passes:  python3 scripts/steps.py done {s['n']}")


def markdown():
    lines = ["# Step by step (generated from scripts/steps.py; do not edit by hand)", "",
             "One config file per environment (`scripts/env.dev.sh`, `scripts/env.prod.sh`). Run `python3 scripts/steps.py show N` or `run N`.", ""]
    phase = None
    for s in STEPS:
        if s["phase"] != phase:
            phase = s["phase"]
            lines += [f"## {phase}", "", "| # | Step | Who | Where | Do this | Check |", "|---|---|---|---|---|---|"]
        what = "; ".join(f"`{c}`" for c in s.get("cmds", []))
        if s.get("files"):
            what = (what + "; " if what else "") + "; ".join(f"`{f}`" for f in s["files"])
        if s.get("template"):
            what = f"`{s['template']}`" + (f" section {s['section']}" if s.get("section") else "")
        if s.get("sql_file"):
            what = f"`{s['sql_file']}`"
        if not what:
            what = "manual: see the document section"
        lines.append(f"| {s['n']} | {s['title']} | {s['who']} | {s['where']} | {what} | {s['check']} |")
        if STEPS[-1] is s or STEPS[STEPS.index(s) + 1]["phase"] != phase:
            lines.append("")
    return "\n".join(lines) + "\n"


def main(argv):
    if len(argv) < 2 or argv[1] not in {"list", "show", "run", "done", "undo", "markdown"}:
        print(__doc__)
        return 2
    cmd = argv[1]
    if cmd == "markdown":
        sys.stdout.write(markdown())
    elif cmd == "list":
        d, phase = done_set(), None
        for s in STEPS:
            if s["phase"] != phase:
                phase = s["phase"]
                print(f"\n{phase}")
            print(f"  [{'x' if s['n'] in d else ' '}] {s['n']:>2}  {s['title']}  ({s['who']}; {s['where']})")
        nxt = next((s["n"] for s in STEPS if s["n"] not in d), None)
        print(f"\nNext: step {nxt}" if nxt else "\nAll steps are marked done.")
    else:
        if len(argv) != 3 or not argv[2].isdigit():
            print("usage: steps.py", cmd, "N")
            return 2
        s = get(int(argv[2]))
        {"show": show, "run": run, "done": lambda x: mark(x["n"], True), "undo": lambda x: mark(x["n"], False)}[cmd](s)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
