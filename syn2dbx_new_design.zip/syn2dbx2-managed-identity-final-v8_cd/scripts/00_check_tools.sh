#!/usr/bin/env bash
# Checks the tools START_HERE section 1a needs. Read-only, except it adds the az extensions.
#   bash scripts/00_check_tools.sh
set -uo pipefail
ok=0
check() { # check "label" command...
  local label=$1; shift
  local out
  if out=$("$@" 2>&1); then
    printf '  ok   %-18s %s\n' "$label" "${out%%$'\n'*}"
  else
    printf '  MISSING %-15s %s\n' "$label" "${out%%$'\n'*}"
    ok=1
  fi
}
echo "Required tools:"
check git git --version
check python3 python3 --version
python3 - <<'PY' || { echo "  WARN python3 is older than 3.12 (serverless environment version 3 uses 3.12)"; }
import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)
PY
check java bash -c 'java -version 2>&1 | grep -m1 version'
check az az version --query '"azure-cli"' -o tsv
check databricks databricks --version
echo "Optional: gh (only for scripts/05_github_setup.sh)"
if command -v gh >/dev/null 2>&1; then
  gh --version | head -n1
else
  echo "  optional gh not installed; install it only if you will run 05_github_setup.sh"
fi
if command -v az >/dev/null 2>&1; then
  echo "Azure CLI extensions:"
  for ext in databricks synapse; do
    az extension show --name "$ext" >/dev/null 2>&1 || az extension add --name "$ext" --only-show-errors >/dev/null 2>&1 \
      || echo "  note: could not add az extension '$ext' (it may be built in; ignore if 'az $ext ...' works)"
    echo "  checked az extension: $ext"
  done
fi
java -version 2>&1 | grep -Eq 'version "(1[7-9]|2[0-9])' || { echo "  WARN Java 17+ is needed by the PySpark tests (python -m pytest tests -q)"; }
[ $ok -eq 0 ] && echo "All required tools found." || echo "Install the MISSING tools (links in START_HERE section 1a), then re-run."
exit $ok
