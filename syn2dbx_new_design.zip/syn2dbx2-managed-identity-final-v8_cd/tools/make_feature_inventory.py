"""Make a personal feature-branch inventory from the reviewed DEV inventory, and the matching reset SQL.

  python tools/make_feature_inventory.py --user you@company.com \
      [--from config/inventory.dev.json] [--output config/inventory.feature.json] \
      [--webhook-secret-scope SCOPE --webhook-secret-key KEY] [--reset-sql build/feature_reset.sql]

Why: a feature-branch run must never write the shared DEV tables. Each target table remembers (in its Delta
log) the newest night it accepted, so a test run on the shared table can make the later DEV run skip or fail.
The copy changes only where things are written, never what is exported:

  * every target_schema        -> feature_<you>_<original>   (same catalog, so your CREATE SCHEMA right is enough)
  * control.schema            -> feature_<you>_<original>
  * staging.prefix            -> bridge-stage-feature-<you> (not covered by the DEV lifecycle rule; delete by hand)
  * inventory_version         -> <original>_feature_<you>
  * notifications.summary_webhook -> only if you pass a TEST secret scope/key (otherwise the DEV one is kept:
    then run with notifications you can tolerate, or pass your own)

Reset SQL: DROP SCHEMA ... CASCADE for exactly those personal schemas. It refuses any schema not named
feature_<you>_*, so it can never touch DEV or PROD data. Dropping is done through Unity Catalog; never delete a
managed table's files in storage (that corrupts the table). A dropped managed table can be restored with UNDROP for
a limited time; that also restores the write guard, so wait for the drop to age out or recreate under another name.
"""
import argparse
import copy
import json
import re
import sys
from pathlib import Path

# Package root folder.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bridge import contract  # noqa: E402


def feature_slug(user):
    slug = re.sub(r"[^a-z0-9]+", "_", str(user).split("@")[0].lower()).strip("_")[:20]
    if not slug:
        raise ValueError(f"cannot derive a name from user {user!r}")
    return slug


def make_feature_inventory(doc, user, webhook_scope=None, webhook_key=None):
    slug = feature_slug(user)
    pre = f"feature_{slug}_"
    out = copy.deepcopy(doc)
    out["inventory_version"] = f"{doc['inventory_version']}_feature_{slug}"
    out["control"]["schema"] = pre + doc["control"]["schema"]
    out["staging"]["prefix"] = f"bridge-stage-feature-{slug}"
    for m in out["mappings"]:
        m["target_schema"] = pre + m["target_schema"]
    if webhook_scope or webhook_key:
        if not (webhook_scope and webhook_key):
            raise ValueError("pass both --webhook-secret-scope and --webhook-secret-key")
        out["notifications"]["summary_webhook"] = {"secret_scope": webhook_scope, "url_secret_key": webhook_key}
    contract.validate_inventory(out)
    problems = contract.variant_4a_problems(out)
    if problems:
        raise ValueError("; ".join(problems))
    return out


def reset_sql(doc, user):
    """DROP SCHEMA statements for the personal schemas of this feature inventory (and nothing else)."""
    pre = f"feature_{feature_slug(user)}_"
    pairs = {(doc["control"]["catalog"], doc["control"]["schema"])}
    pairs |= {(m["target_catalog"], m["target_schema"]) for m in doc["mappings"]}
    lines = ["-- Feature-branch reset for " + str(user) + ". DESTRUCTIVE: drops the personal schemas below and every table in them.",
             "-- Run in a Databricks SQL editor as yourself. Never run it against DEV or PROD schemas.",
             "-- After it: re-run uc_setup (src/setup/00_admin_setup.py) with this feature inventory to recreate the tables."]
    for cat, sch in sorted(pairs):
        contract.ident(cat, "catalog")
        contract.ident(sch, "schema")
        if not sch.startswith(pre):
            raise ValueError(f"refusing to drop schema {cat}.{sch}: it is not a personal feature schema ({pre}*)")
        lines.append(f"DROP SCHEMA IF EXISTS `{cat}`.`{sch}` CASCADE;")
    return "\n".join(lines) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--user", required=True, help="your Databricks user e-mail (only the part before @ is used)")
    ap.add_argument("--from", dest="source", default=str(ROOT / "config" / "inventory.dev.json"))
    ap.add_argument("--output", default=str(ROOT / "config" / "inventory.feature.json"))
    ap.add_argument("--reset-sql", default=str(ROOT / "build" / "feature_reset.sql"))
    ap.add_argument("--webhook-secret-scope")
    ap.add_argument("--webhook-secret-key")
    a = ap.parse_args(argv)
    doc = contract.load_inventory(a.source)
    out = make_feature_inventory(doc, a.user, a.webhook_secret_scope, a.webhook_secret_key)
    Path(a.output).write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    Path(a.reset_sql).parent.mkdir(parents=True, exist_ok=True)
    Path(a.reset_sql).write_text(reset_sql(out, a.user), encoding="utf-8")
    schemas = sorted({m["target_schema"] for m in out["mappings"]} | {out["control"]["schema"]})
    print(f"Wrote {a.output} ({len(out['mappings'])} mappings) and {a.reset_sql}")
    print("Personal schemas:", ", ".join(schemas))
    print("Staging prefix:", out["staging"]["prefix"])
    print("Webhook:", out["notifications"]["summary_webhook"])


if __name__ == "__main__":
    main()
