"""Helpers for src/setup/01_permission_check.py: run each Databricks-side permission check, report PASS/FAIL.

Pure Python (no Spark), so the reporting and the path/identifier rules are unit-tested. The notebook supplies the
checks that talk to Databricks, Unity Catalog, storage and Synapse. Nothing here prints a token, a secret or a URL.
"""
import re

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
# Pattern for the container root of an abfss:// URL or path template.
ABFSS = re.compile(r"abfss://([a-z0-9][a-z0-9-]{1,62})@([a-z0-9]{3,24})\.dfs\.core\.windows\.net")
# Patterns scrubbed from any error text before it is printed (tokens, passwords, bearer values).
SECRET_LIKE = re.compile(r"((access_?token|token|password|pwd|secret|sig)\s*[=:]\s*\S+|Bearer\s+\S+|eyJ[A-Za-z0-9_-]{20,})", re.I)


def abfss_root(url):
    """Container root of an abfss:// URL or path template (no path, no trailing slash)."""
    m = ABFSS.match(str(url))
    if not m:
        raise ValueError(f"not an abfss://container@account.dfs.core.windows.net URL: {url!r}")
    return m.group(0)


def scratch_schema(user, suffix):
    """Name of the throw-away schema used to prove CREATE SCHEMA/TABLE. Always starts with perm_check_."""
    slug = re.sub(r"[^a-z0-9]+", "_", str(user).split("@")[0].lower()).strip("_")[:20] or "user"
    suffix = re.sub(r"[^a-z0-9]", "", str(suffix).lower())[:8] or "0"
    return f"perm_check_{slug}_{suffix}"


def scrub(text, limit=300):
    """Error text safe to print: shortened, and anything token- or password-like removed."""
    return SECRET_LIKE.sub("<removed>", " ".join(str(text).split()))[:limit]


class Report:
    def __init__(self):
        self.rows = []

    def check(self, name, fn, hint=""):
        """Run fn(); PASS if it returns without error (its return value is the detail), FAIL with a hint otherwise."""
        try:
            detail = fn()
            self.rows.append((PASS, name, scrub(detail) if detail is not None else "", ""))
        except Exception as exc:  # noqa: BLE001 - every failure is a finding, not a crash
            self.rows.append((FAIL, name, scrub(f"{type(exc).__name__}: {exc}"), hint))

    def skip(self, name, why):
        self.rows.append((SKIP, name, why, ""))

    @property
    def failed(self):
        return [r for r in self.rows if r[0] == FAIL]

    def render(self):
        width = max([len(r[1]) for r in self.rows] + [10])
        lines = []
        for status, name, detail, hint in self.rows:
            lines.append(f"[{status}] {name.ljust(width)}  {detail}")
            if hint:
                lines.append(f"       -> {hint}")
        counts = {s: sum(1 for r in self.rows if r[0] == s) for s in (PASS, FAIL, SKIP)}
        lines.append("")
        lines.append(f"{counts[PASS]} passed, {counts[FAIL]} failed, {counts[SKIP]} skipped.")
        lines.append("ALL PERMISSION CHECKS PASSED" if not counts[FAIL] else
                     "SOME CHECKS FAILED: send the lines above marked FAIL to the person who owns that object.")
        return "\n".join(lines)
