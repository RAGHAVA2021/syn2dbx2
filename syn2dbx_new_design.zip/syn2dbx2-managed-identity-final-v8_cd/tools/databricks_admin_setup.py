"""One-time administrator setup helpers for Databricks Git-folder notebooks.

No Azure resources or UC credentials are created here. Cloud identity provisioning
is an approved infrastructure action. All mutating operations require apply=True.
"""
import importlib.util
import json
import re
import sys
from pathlib import Path

# Package root folder; config paths are confined to ROOT/config.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bridge import contract, synapse  # noqa: E402


def config_path(relative):
    candidate = (ROOT / relative).resolve()
    config = (ROOT / "config").resolve()
    if candidate.parent != config or candidate.suffix != ".json":
        raise ValueError("Use a JSON file directly under the repository config/ folder")
    return candidate


def settings_file(relative):
    path = config_path(relative)
    doc = json.loads(path.read_text())
    if doc["synapse"]["auth"]["mode"] != "service_credential":
        raise ValueError("This setup workflow requires service_credential auth")
    return doc


def connection(spark, dbutils, doc):
    return synapse.connect(spark, doc, synapse.credentials_provider(doc, dbutils))


def preflight(spark, dbutils, doc):
    auth = doc["synapse"]["auth"]
    provider = dbutils.credentials.getServiceCredentialsProvider(auth["credential_name"])
    token = provider.get_token(synapse.SQL_SCOPE)
    if not token.token:
        raise RuntimeError("Service credential did not return a Synapse SQL token")
    with connection(spark, dbutils, doc) as conn:
        row = conn.query("SELECT DB_NAME(), SUSER_SNAME(), USER_NAME()")
    return {"database": row[0][0], "login": row[0][1], "user": row[0][2]}


def synapse_setup_sql(doc, login_identity, source_schema, extra_schemas=()):
    """Render the reviewed SQL template, with all substitution values validated.

    The template grants SELECT on ``source_schema``. ``extra_schemas`` appends one validated
    GRANT SELECT per additional source schema, so the administrator reviews them together.
    """
    if not login_identity or len(login_identity) > 128 or any(
        c in login_identity for c in ("'", ";", "\n", "\r", "<", ">")
    ):
        raise ValueError("Provide the approved Entra Synapse principal display name")
    contract.ident(source_schema, "source schema")
    root = doc["staging"]["root"].rstrip("/")
    match = re.fullmatch(
        r"abfss://([a-z0-9][a-z0-9-]*)@([a-z0-9]{3,24})\.dfs\.core\.windows\.net",
        root,
    )
    if not match:
        raise ValueError("staging.root must be an ADLS container root")
    template = (ROOT / "sql" / "synapse" / "01_export_setup.sql").read_text()
    replacements = {
        "<staging-container>": match[1],
        "<storage-account>": match[2],
        "<synapse-login-identity>": login_identity,
        "<source-schema>": source_schema,
    }
    for marker, value in replacements.items():
        template = template.replace(marker, value)
    extra = []
    for schema in extra_schemas:
        contract.ident(schema, "source schema")
        if schema.lower() != source_schema.lower() and schema.lower() not in {e.lower() for e in extra}:
            extra.append(schema)
    if extra:
        grants = "\n".join(
            f"IF SCHEMA_ID(N'{s}') IS NULL THROW 50006, 'Source schema {s} does not exist.', 1;\n"
            f"SET @Sql = N'GRANT SELECT ON SCHEMA::' + QUOTENAME(N'{s}') + N' TO ' + QUOTENAME(@SynapseLoginIdentity);\n"
            "EXEC (@Sql);" for s in extra)
        marker = "SELECT @SynapseLoginIdentity AS synapse_login_identity,"
        if marker not in template:
            raise ValueError("01_export_setup.sql no longer has the final SELECT; update the renderer")
        template = template.replace(marker, "-- Additional source schemas (rendered from the notebook's source_schemas)\n"
                                    + grants + "\n" + marker, 1)
    return template


def apply_synapse_sql(spark, dbutils, doc, sql, apply=False):
    if not apply:
        return "DRY RUN: SQL rendered; no Synapse changes performed"
    raise PermissionError(
        "Synapse DDL must be run by an approved Synapse administrator using an "
        "administrator connection, not the nightly managed-identity service credential. "
        "Copy the reviewed dry-run SQL into Synapse Studio or an approved SQL client."
    )


def generate_inventory(spark, dbutils, doc, source_schemas, target_catalog,
                       target_schema, output_relative, apply=False,
                       exclude_objects="", profile_tables=False):
    """Build inventory with the exact mapping logic used by the existing CLI."""
    spec = importlib.util.spec_from_file_location(
        "bridge_generate_inventory", ROOT / "tools" / "generate_inventory.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    contract.ident(target_catalog, "target catalog")
    contract.ident(target_schema, "target schema")
    path = config_path(output_relative)
    if path.exists():
        raise FileExistsError(f"Will not replace a reviewed inventory: {path}")
    schemas = [s.strip() for s in source_schemas.split(",") if s.strip()]
    if not schemas:
        raise ValueError("At least one source schema is required")
    for schema in schemas:
        contract.ident(schema, "source schema")
    excluded = {s.strip().lower() for s in exclude_objects.split(",") if s.strip()}
    for item in excluded:
        parts = item.split(".")
        if len(parts) != 2:
            raise ValueError("Excluded objects must be schema.object, comma separated")
        for part in parts:
            contract.ident(part, "excluded object identifier")
    mappings, errors = [], []
    with connection(spark, dbutils, doc) as conn:
        for schema in schemas:
            for name, kind in conn.query(module.LIST_OBJECTS_SQL, schema):
                if f"{schema}.{name}".lower() in excluded:
                    continue
                try:
                    contract.ident(name, "source object")
                    columns = conn.query(contract.SYS_COLUMNS_SQL, f"[{schema}].[{name}]")
                    size = 0
                    if profile_tables and kind.strip() == "U":
                        try:
                            size_rows = conn.query(module.PROFILE_SQL, schema, name)
                        except Exception as exc:
                            raise RuntimeError(
                                f"Profiling {schema}.{name} failed. Ask the Synapse DBA to "
                                "verify dedicated-pool DMV permissions, or rerun with "
                                "profile_tables=false and manually review estimated_bytes."
                            ) from exc
                        size = int(size_rows[0][0] or 0) if size_rows else 0
                    mappings.append(module.build_mapping(
                        schema, name, columns, target_catalog, target_schema, size
                    ))
                except (contract.UnsupportedType, ValueError) as exc:
                    errors.append(str(exc))
    if errors:
        raise ValueError("No inventory written; review unsupported objects:\n" + "\n".join(errors))
    inventory = {**doc, "mappings": mappings}
    contract.validate_inventory(inventory)
    if contract.variant_4a_problems(inventory):
        raise ValueError("; ".join(contract.variant_4a_problems(inventory)))
    if apply:
        path.write_text(json.dumps(inventory, indent=2) + "\n")
    return {"mappings": len(mappings), "output": str(path), "saved": apply,
            "note": "Views have estimated_bytes=0; review sizes, mandatory and allow_empty flags"}


def uc_setup_sql(inventory_relative, job_principal, consumer_group=""):
    doc = contract.load_inventory(config_path(inventory_relative))
    spec = importlib.util.spec_from_file_location(
        "bridge_render_uc_setup", ROOT / "tools" / "render_uc_setup.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.render(doc, job_principal, consumer_group or None)


def split_statements(sql):
    """Split rendered SQL on ';' + newline, dropping comment-only chunks.

    The rendered script contains '--' comment blocks (e.g. the commented
    external-location template). A chunk holding only comments is an empty
    statement for Spark and fails apply at that point.
    """
    statements = []
    for item in sql.split(";\n"):
        lines = [l for l in item.splitlines() if l.strip() and not l.strip().startswith("--")]
        if lines:
            statements.append("\n".join(lines).strip())
    return statements


def apply_uc_sql(spark, sql, apply=False):
    statements = split_statements(sql)
    if not apply:
        return {"statements": len(statements), "executed": 0}
    for number, statement in enumerate(statements, 1):
        try:
            spark.sql(statement).collect()
        except Exception as exc:
            raise RuntimeError(f"UC statement {number}/{len(statements)} failed; "
                               "inspect partial changes before retry") from exc
    return {"statements": len(statements), "executed": len(statements)}
