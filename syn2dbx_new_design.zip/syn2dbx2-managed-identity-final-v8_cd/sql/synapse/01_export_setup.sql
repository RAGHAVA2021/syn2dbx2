/* Run once in the Synapse dedicated SQL pool as administrator.
   First review 03_review_credential_scope.sql and obtain security approval.
   Change values only in this section. Do not insert GO batch separators.
   SynapseLoginIdentity is the identity connecting to Synapse, which may be
   different from the Databricks job's run-as service principal.
*/
SET NOCOUNT ON;
DECLARE @StagingContainer sysname = N'<staging-container>';
DECLARE @StorageAccount sysname = N'<storage-account>';
DECLARE @SynapseLoginIdentity sysname = N'<synapse-login-identity>';
DECLARE @SourceSchema sysname = N'<source-schema>';
DECLARE @MetadataSchema sysname = N'bridge_meta';
DECLARE @CredentialName sysname = N'bridge_msi';
DECLARE @DataSourceName sysname = N'bridge_stage';
DECLARE @FileFormatName sysname = N'bridge_parquet';

IF @StagingContainer LIKE N'%<%' OR @StorageAccount LIKE N'%<%'
   OR @SynapseLoginIdentity LIKE N'%<%' OR @SourceSchema LIKE N'%<%'
    THROW 50000, 'Set the four environment values above before executing.', 1;
IF @StagingContainer LIKE N'%[^a-z0-9-]%'
   OR @StorageAccount LIKE N'%[^a-z0-9]%'
   OR LEN(@StorageAccount) NOT BETWEEN 3 AND 24
    THROW 50001, 'Invalid Azure storage account or container name.', 1;
IF SCHEMA_ID(@SourceSchema) IS NULL
    THROW 50002, 'Source schema does not exist.', 1;

DECLARE @Location nvarchar(500) = N'abfss://' + @StagingContainer
    + N'@' + @StorageAccount + N'.dfs.core.windows.net';
DECLARE @Sql nvarchar(max);

IF EXISTS (SELECT 1 FROM sys.external_data_sources
           WHERE name = @DataSourceName AND location <> @Location)
    THROW 50003, 'Existing external data source points to another location.', 1;
IF EXISTS (SELECT 1 FROM sys.external_file_formats
           WHERE name = @FileFormatName AND format_type <> 'PARQUET')
    THROW 50004, 'Existing external file format is not PARQUET.', 1;

IF SCHEMA_ID(@MetadataSchema) IS NULL
BEGIN
    SET @Sql = N'CREATE SCHEMA ' + QUOTENAME(@MetadataSchema);
    EXEC (@Sql);
END;
-- Provision the database master key separately under an approved Synapse
-- administrator. Its encryption password must never be embedded in source code.
IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys
               WHERE name = '##MS_DatabaseMasterKey##')
    THROW 50005, 'Database master key missing. Administrator must create it first with CREATE MASTER KEY ENCRYPTION BY PASSWORD, using an approved secret.', 1;
IF NOT EXISTS (SELECT 1 FROM sys.database_scoped_credentials
               WHERE name = @CredentialName)
BEGIN
    SET @Sql = N'CREATE DATABASE SCOPED CREDENTIAL '
        + QUOTENAME(@CredentialName) + N' WITH IDENTITY = ''Managed Service Identity''';
    EXEC (@Sql);
END;
IF NOT EXISTS (SELECT 1 FROM sys.external_data_sources WHERE name = @DataSourceName)
BEGIN
    SET @Sql = N'CREATE EXTERNAL DATA SOURCE ' + QUOTENAME(@DataSourceName)
        + N' WITH (TYPE = HADOOP, LOCATION = ''' + @Location
        + N''', CREDENTIAL = ' + QUOTENAME(@CredentialName) + N')';
    EXEC (@Sql);
END;
IF NOT EXISTS (SELECT 1 FROM sys.external_file_formats WHERE name = @FileFormatName)
BEGIN
    SET @Sql = N'CREATE EXTERNAL FILE FORMAT ' + QUOTENAME(@FileFormatName)
        + N' WITH (FORMAT_TYPE = PARQUET, '
        + N'DATA_COMPRESSION = ''org.apache.hadoop.io.compress.SnappyCodec'')';
    EXEC (@Sql);
END;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = @SynapseLoginIdentity)
BEGIN
    SET @Sql = N'CREATE USER ' + QUOTENAME(@SynapseLoginIdentity)
        + N' FROM EXTERNAL PROVIDER';
    EXEC (@Sql);
END;
SET @Sql = N'GRANT SELECT ON SCHEMA::' + QUOTENAME(@SourceSchema)
    + N' TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
SET @Sql = N'GRANT CREATE TABLE TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
SET @Sql = N'GRANT ALTER ON SCHEMA::' + QUOTENAME(@MetadataSchema)
    + N' TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
-- Broad permissions: security approval is mandatory.
SET @Sql = N'GRANT ALTER ANY EXTERNAL DATA SOURCE TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
SET @Sql = N'GRANT ALTER ANY EXTERNAL FILE FORMAT TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
SET @Sql = N'GRANT ADMINISTER DATABASE BULK OPERATIONS TO ' + QUOTENAME(@SynapseLoginIdentity);
EXEC (@Sql);
SELECT @SynapseLoginIdentity AS synapse_login_identity,
       @Location AS staging_location,
       @DataSourceName AS external_data_source;
