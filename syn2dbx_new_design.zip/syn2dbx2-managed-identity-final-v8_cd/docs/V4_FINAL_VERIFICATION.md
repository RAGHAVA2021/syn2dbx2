# V4 final verification — 2026-10-23

## What changed since the supplied V3 ZIP

1. GitHub `ci-cd.yml` no longer automatically initiates PROD following DEV deployment. PROD requires an explicit `workflow_dispatch` from `main`, non-empty `dev_acceptance_evidence`, and the protected PROD Environment approval. The field is a human attestation; a reviewer must compare it with the tested commit and acceptance run.
2. The single `START_HERE_COMPLETE_SETUP.md` now contains executable administrator commands, setup boundaries, Databricks notebook widget order, GitHub variables, manual deployment variable setup, a promotion gate, and per-step verification. The remaining guides are supplementary.
3. `GITHUB_OIDC_SETUP.md`, `RUNBOOK.md`, and `README.md` are consistent with the new PROD gate.
4. Added regression tests for the gate, protected Environment, and primary runbook. Updated the earlier test that expected automatic PROD promotion.

## Exact local verification

- `python -m pytest -q`: **417 passed, 20 skipped**.
- The skipped tests require additional Spark/Derby/driver integration support; they are not a successful Azure runtime test.
- Python syntax/JSON/YAML and final archive contents are separately validated during packaging.
- No cloud credentials or deployments were available. There was no live Synapse SQL DDL, Azure RBAC, Unity Catalog credential, JDBC, ADLS, webhook, or Databricks bundle execution.

## Before calling this production-ready

Run the primary guide in DEV, including service-credential login, tiny CETAS, staged Parquet read, forced UC JDBC fallback, Delta overwrite/history proof, original-data retention after a failed table, control logs, summary webhook, cutoff repair, and GitHub release authorization. Then test the identical approved commit in PROD with schedules paused.

If any platform API or UI differs from the documented examples, stop and reconcile against official Azure/Databricks documentation and the actual tenant before granting permissions or deploying.
