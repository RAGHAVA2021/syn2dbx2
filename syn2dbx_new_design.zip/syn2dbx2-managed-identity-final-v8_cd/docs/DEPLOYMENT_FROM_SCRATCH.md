# Deployment from scratch — managed identity (4A)

> **Authoritative beginner order:** [START_HERE_COMPLETE_SETUP.md](START_HERE_COMPLETE_SETUP.md).
> This file remains a supplemental deployment reference. Synapse DDL must
> be executed by a separate administrator; the notebook renders it only.

This is a supplemental reference for the default `service_credential` configuration;
`START_HERE_COMPLETE_SETUP.md` is the only authoritative setup order. Complete **DEV** and verify before doing **PROD**. Do not run
individual nightly notebooks manually. Do not create new resources when the
organisation has approved existing equivalents.

For execution mainly **inside Databricks**, follow
[DATABRICKS_FIRST_SETUP.md](DATABRICKS_FIRST_SETUP.md) after the required
Azure prerequisites. It describes the administrator-only notebook and its
manual approval/dry-run controls.

**Script-first setup:** Complete
[UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md](UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md)
for the full Azure CLI + Databricks CLI + SQL commands needed for the managed
identity, service credential and privileges. This document provides the whole
deployment order; that document provides the executable credential details.

## Identity map — read before creating anything

| Identity | Created/managed in | Used for | Configuration |
|---|---|---|---|
| Databricks job service principal (Entra app) | Microsoft Entra ID; added to Databricks | Run-as for jobs; UC grants | `databricks.yml` `var.job_identity` |
| Azure access connector managed identity | Azure access connector + UC service credential | Authenticates command/control Synapse SQL | `synapse.auth.credential_name` |
| Synapse workspace managed identity | Existing Synapse workspace | CETAS writes files to ADLS | `bridge_msi` scoped credential |
| Storage identity for UC external locations | Existing Unity Catalog storage credential | Databricks reads CETAS/manifest, writes fallback stages | UC external locations |
| GitHub deployment principal | Entra app with GitHub OIDC federation | Deploys Databricks bundle | GitHub Environment variables |

An *Entra application registration* is not automatically required for each
managed identity. The job service principal may be reused if already approved.
The GitHub deploy identity can also be an existing approved principal; keep its
permissions separate. A UC **service credential** is not the same object as a
UC **storage credential**. A UC **JDBC connection** is a third object.

## 0. Decisions and inventory (developer + administrators)

Collect and approve DEV and PROD values independently:

- Synapse SQL endpoint, dedicated pool, source schemas/views and approver.
- Job service principal application ID; managed identity name/object ID used
  by the access connector; Synapse workspace identity.
- ADLS staging account/container, separate upstream manifest container, and
  their existing UC storage credentials/external locations.
- UC service credential name, UC JDBC connection name, target and control
  catalog/schema, groups and notification webhook secret reference.
- DEV and PROD Databricks workspace hosts, GitHub repository/environments.

**Never place tokens, client secrets or webhook URLs in the JSON inventory.**
Do not use Synapse serverless SQL endpoint: this bridge requires the dedicated pool.

## 1. Identity setup (Entra/Databricks administrator)

1. Locate the approved job application in Entra ID and register/assign it
   in the Databricks workspace using your organisation's identity automation.
   Record its application ID, and grant the deploy identity the required
   permission to configure a job to run as it.
2. Use the script-first guide's **Sections 1–4** to find/create the access
   connector managed identity and UC service credential.
3. Follow that guide's **Section 5** to grant and verify `ACCESS` for the
   Databricks job principal with SQL commands.
4. Follow its **Section 6** for the Synapse login and reviewed CETAS grants.
5. Verify that the dedicated Synapse pool accepts an Entra login by the access
   connector identity. If identity/token support differs in your environment,
   stop: use the documented `client_secret` alternative only after approval.

**Do not confuse** step 1's job principal with step 3's Synapse login. They
may be different. The Synapse SQL grants must go to the login in step 3.

## 2. ADLS setup (Azure storage administrator)

1. Prepare or identify the CETAS staging container and separate upstream
   manifest container (read-only to the job).
2. Give the **Synapse workspace managed identity** Storage Blob Data Contributor
   on the staging container so the Synapse engine can write CETAS Parquet.
3. Verify Databricks external locations: job principal needs READ FILES and
   WRITE FILES on staging, READ FILES on the manifest location.
4. Check storage firewall/private networking from serverless Databricks and
   Synapse; check lifecycle rules in `infra/README.md`. Never point a lifecycle
   deletion rule at Delta target storage or the upstream manifest container.

## 3. Synapse setup (dedicated SQL pool administrator)

1. Connect in Synapse Studio or SSMS to the **dedicated pool database**.
2. Run `sql/synapse/03_review_credential_scope.sql` (read-only).
   Obtain written approval before granting broad external-data-source
   permissions; they can reach other scoped credentials in the pool.
3. Open `sql/synapse/01_export_setup.sql`. Change the four values **only at
   the top**: staging container, storage account, Synapse login identity,
   source schema. Review optional object names alongside them.
4. Run the SQL once in the dedicated pool. It creates missing bridge objects
   and grants the *Synapse login identity* the required rights.
5. For additional approved source schemas, separately grant schema-level
   SELECT to the same login. Verify a read query and a tiny CETAS test on
   an approved source before proceeding.
6. A pre-existing `bridge_stage` pointing to a different account will now
   cause a setup error. Review/reconcile it; do not overwrite it blindly.

The Synapse **database scoped credential** `bridge_msi` uses the **Synapse
workspace managed identity** for storage writes. It is not the UC service
credential which authenticates the Databricks process to Synapse SQL.

## 4. Unity Catalog and JDBC fallback (Databricks administrator)

1. Check required catalogs/schemas and grants for the job principal.
   See the exact service-credential grant in
   `UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md`, Section 5.
2. Locate or create a **UC JDBC connection** to the dedicated pool, using an
   approved authentication design. The fallback uses this connection separately
   from the command SQL connection. Test it with an allowed source table.
3. Verify external-location grants for staging and manifest.
4. Put the HTTPS summary webhook URL into a Databricks secret scope and grant
   only needed readers. Configure a destination such as Logic Apps separately.
5. Confirm the job principal can access its UC service credential, the JDBC
   connection, the needed schemas and secret.

## 5. Local configuration (developer)

Install Python 3.12, Java 17 (for the tests) and the Databricks CLI, authenticate to the DEV workspace.
From the repository root:

```bash
cp config/settings.example.json config/settings.json
```

Edit `settings.json`:

```json
"synapse": {
  "server": "<workspace>.sql.azuresynapse.net",
  "database": "<dedicated-pool>",
  "auth": {
    "mode": "service_credential",
    "credential_name": "<existing-uc-service-credential>"
  },
  "uc_jdbc_connection": "<existing-uc-jdbc-connection>"
}
```

This is an **excerpt**, not a replacement for the full settings JSON. Also
set staging, control, manifest, notification and business cutoffs. Keep
`manifest.success_marker` as **`_SUCCESS`**. The upstream team must upload
JSON content to that exact filename **last**, after `row_counts.csv`.
See `docs/UPSTREAM_MANIFEST_SPEC.md`.

Set the DEV/PROD workspace hosts in `databricks.yml`. Keep both scheduled
jobs PAUSED until acceptance is complete. In GitHub Environment variables,
configure the approved deploy OIDC identity and
`DATABRICKS_JOB_IDENTITY` (application ID of the job run-as principal).
Do not put a Synapse client secret into the job unless using the separate
approved client-secret authentication mode.

## 6. Generate inventory and UC setup (developer + SQL administrator)

Use `tools/generate_inventory.py --help` to select the source schema/tables,
destination and output file. Generate `config/inventory.dev.json` from the
configured DEV settings; review every mapping, including mandatory/allow_empty,
source and target columns and estimated sizes. Do **not** treat examples as
production inventories.

```bash
python tools/render_uc_setup.py --help
python tools/render_uc_setup.py --inventory config/inventory.dev.json --help
```

Render `build/uc_setup.sql` with real target catalog/schema and approved group
parameters (see `docs/RUNBOOK.md`). Have the Databricks SQL administrator review
and execute it in a SQL warehouse. It creates control/target tables and grants;
pre-existing UC privileges/external locations are separate administrator steps.

## 7. Test and deploy DEV (developer / release engineer)

```bash
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
python tools/prepare_deploy.py --environment dev
databricks bundle validate --target dev
databricks bundle deploy --target dev
```

In the Databricks UI run the **acceptance** job first. It must prove serverless
command SQL, UC service credential token, Synapse CETAS, UC JDBC fallback,
Delta publishing and permissions. Then run the nightly job manually for
2–3 approved mappings after the upstream manifest is present. Check row
counts, Delta history, failure logging and notification. Run the full DEV
inventory only when this passes.

## 8. Promote the tested commit to PROD (release engineer)

Configure PROD identities, SQL grants, UC objects, secrets and inventory
separately. Merge through the repository workflow; verify DEV. Approve the
**same tested commit** for PROD in the protected GitHub Environment. Run PROD
acceptance and a small trial with scheduling still PAUSED. Only then set the
PROD nightly/maintenance pause variables to UNPAUSED and redeploy.

## 9. Daily operation and recovery (operator)

The Databricks workflow executes `00_plan` → `10_extract_validate_batch`
→ `20_serverless_jdbc_fallback` (when needed) → `30_publish_batch` →
`90_finalize`. It sends the configured summary after processing. Failed
tables retain their previous data. Investigate `table_log` and `run_log`;
manual repair is permitted only inside the configured same-day recovery
window (default 11:00 Australia/Sydney). Follow `docs/RUNBOOK.md`; never
rerun the previous night after cutoff.

## Go-live gates

- [ ] Identity-to-resource grants reviewed and recorded
- [ ] Service credential authenticates to the **dedicated** Synapse pool
- [ ] UC JDBC fallback connection tested separately
- [ ] CETAS staging isolated, lifecycle configured and verified
- [ ] Exact `row_counts.csv` + `_SUCCESS` contract tested
- [ ] All local tests pass
- [ ] DEV acceptance plus small and full runs pass
- [ ] Notification, per-table failure and recovery tested
- [ ] Same commit promoted; PROD acceptance passes
- [ ] Human explicitly approves production schedules

**Limit:** local tests cannot prove cloud identity, Synapse T-SQL compatibility,
serverless JDBC or Delta runtime behaviour. Those require actual DEV acceptance.
