# Unity Catalog JDBC fallback connection — step by step

This is a **separate** connection from the Unity Catalog service credential used for CETAS command SQL. The JDBC connection is used only after CETAS requires fallback. Perform all steps in DEV first. The connection credentials are managed by the approved UC administrator; never place a username/password or token in the project JSON or Git.

**Reference:** [Databricks JDBC connection documentation](https://docs.databricks.com/aws/en/connect/jdbc-connection). The documented Unity Catalog JDBC feature supports serverless Spark. Check availability in your Azure workspace before applying changes.

## 1. Requirements and decisions

1. Confirm the DEV workspace uses Unity Catalog and supports JDBC UC connections on **serverless** compute. Verify the Azure Synapse dedicated-pool hostname, port 1433, pool database and network/DNS routes from serverless.
2. Choose a JDBC login independently from the CETAS command service credential. Current documented JDBC connection authentication supports **static credentials** or **OAuth M2M**, not attaching a UC service credential directly. Use the organization's approved identity/credential design. The fallback's read-only database user needs `SELECT` on allowed source views.
3. The JDBC administrator needs `CREATE CONNECTION` on the UC metastore and rights to a Unity Catalog volume for the driver JAR. The nightly job principal needs `USE CONNECTION` and `READ VOLUME`; grant no broad group by default.
4. Obtain the vendor-approved Microsoft JDBC Driver for SQL Server JAR (`mssql-jdbc-*.jar`) from the official Microsoft distribution. Verify its version/license/Java compatibility with the selected compute. Do **not** confuse this Java driver with the Python package `mssql-python` used by CETAS.

## 2. Store the driver in a Unity Catalog volume

As a UC administrator in Databricks SQL, substitute your actual catalog and schema (the catalog must already
exist; `scripts/uc_admin_setup.sql.template` section D renders this block from your `scripts/env.dev.sh`):

```sql
CREATE SCHEMA IF NOT EXISTS `operations_dev`.`bridge_admin`;
CREATE VOLUME IF NOT EXISTS `operations_dev`.`bridge_admin`.`jdbc_drivers`;
GRANT USE CATALOG ON CATALOG `operations_dev` TO `<registered-job-principal>`;
GRANT USE SCHEMA ON SCHEMA `operations_dev`.`bridge_admin` TO `<registered-job-principal>`;
GRANT READ VOLUME ON VOLUME `operations_dev`.`bridge_admin`.`jdbc_drivers` TO `<registered-job-principal>`;
```

Upload the approved driver JAR through Catalog Explorer > Volumes > `jdbc_drivers` > Upload. Record the **real** absolute `/Volumes/operations_dev/bridge_admin/jdbc_drivers/mssql-jdbc-<version>.jar` path. The connection creator also needs the appropriate volume privileges. Verify the job principal can read the JAR path; otherwise the JDBC connection may exist but fail at query time.

## 3. Create the connection in Catalog Explorer

As the authorised connection administrator:

1. Catalog Explorer > Connect > Connections > **Create connection**.
2. Name: `bridge_synapse_jdbc_dev` (example; choose your approved name). Connection type: **JDBC**.
3. URL example (replace values):

   `jdbc:sqlserver://<synapse-workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.sql.azuresynapse.net;loginTimeout=30`

4. Java dependencies: add the exact `/Volumes/.../mssql-jdbc-<version>.jar` path from step 2.
5. Authentication: enter approved credentials in **connection-specific credential fields**, not the URL. For SQL authentication, use approved read-only source user/password (secrets managed by the connection owner). For OAuth M2M, configure only if your Azure SQL Server JDBC driver and tenant flow are confirmed compatible; validate token parameter and endpoint first.
6. **Critical:** Set `externalOptionsAllowList` to include every query-time option the package uses:

   `dbtable,query,partitionColumn,lowerBound,upperBound,numPartitions,queryTimeout,fetchsize,preferTimestampNTZ`

   The first six are the documented default. The last three are used in `src/bridge/loader.py` for query timeout, JDBC batch size and historical timestamp handling. If the feature refuses one of these options, **stop** and validate/adjust the connection or code before release. Do not silently omit one and assume fallback works.
7. Create the connection. Review its properties without printing credentials.

Equivalent SQL can be used for an approved static-credential design, but **do not embed actual passwords in saved SQL**. The syntax is below (also in `scripts/uc_admin_setup.sql.template`, section E); use the protected UI for credential entry whenever possible.

```sql
CREATE CONNECTION `bridge_synapse_jdbc_dev` TYPE JDBC
ENVIRONMENT (java_dependencies '["/Volumes/operations_dev/bridge_admin/jdbc_drivers/mssql-jdbc-<version>.jar"]')
OPTIONS (
  url 'jdbc:sqlserver://<synapse-workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.sql.azuresynapse.net;loginTimeout=30',
  user 'bridge_jdbc_reader',
  password '<password: type it in the editor only, never save it>',
  externalOptionsAllowList 'dbtable,query,partitionColumn,lowerBound,upperBound,numPartitions,queryTimeout,fetchsize,preferTimestampNTZ'
);
```

## 4. Grant access and inspect

```sql
SHOW CONNECTIONS;
DESCRIBE CONNECTION `bridge_synapse_jdbc_dev`;
GRANT USE CONNECTION ON CONNECTION `bridge_synapse_jdbc_dev` TO `<registered-job-principal>`;
SHOW GRANTS ON CONNECTION `bridge_synapse_jdbc_dev`;
```

Check that `config/inventory.dev.json` contains:

```json
"synapse": {
  "uc_jdbc_connection": "bridge_synapse_jdbc_dev"
}
```

This is a fragment: keep other `synapse` fields in the full JSON. Do not create a second `synapse` object.

## 5. Test under the **actual job principal** on serverless

In an approved serverless notebook/job running as the job principal, substitute a small approved source view:

```python
connection_name = "bridge_synapse_jdbc_dev"
reader = (spark.read.format("jdbc")
    .option("databricks.connection", connection_name)
    .option("preferTimestampNTZ", "true")
    .option("queryTimeout", "60")
    .option("fetchsize", "1000"))

reader.option("query", "SELECT TOP 1 * FROM [dbo].[ApprovedSmallView]").load().show()
```

Then separately test source `COUNT_BIG`, a real table with enough rows to exercise partitioned JDBC reading (`dbtable`, `partitionColumn`, `lowerBound`, `upperBound`, `numPartitions`), and a forced CETAS fallback through the packaged acceptance job. A one-row query alone does not prove stage write or parallel options.

## 6. Failure diagnosis

| Failure | Most likely check |
|---|---|
| Driver class/JAR missing | JAR in UC volume, exact `java_dependencies`, `READ VOLUME` grant |
| Query option disallowed | `externalOptionsAllowList` includes `queryTimeout`, `fetchsize`, `preferTimestampNTZ` and needed partition options |
| Login denied | JDBC connection's *separate* authentication and Synapse read-only database principal |
| Port or timeout | Serverless egress/private connectivity and Synapse dedicated endpoint port 1433 |
| Permission denied in Databricks | Job principal `USE CONNECTION`, catalog/schema/volume access |
| Single query works but fallback fails | Test `COUNT_BIG`, Parquet stage `WRITE FILES`, partition options, `_SUCCESS`, source schema and row-count validation |

For the final release gate, use `acceptance_checks.py` and a DEV-only forced-fallback mapping. Keep nightly scheduling paused until the test succeeds.
