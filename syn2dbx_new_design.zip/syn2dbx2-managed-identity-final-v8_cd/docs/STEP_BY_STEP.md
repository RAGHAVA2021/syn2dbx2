# Step by step (generated from scripts/steps.py; do not edit by hand)

One config file per environment (`scripts/env.dev.sh`, `scripts/env.prod.sh`). Run `python3 scripts/steps.py show N` or `run N`.

## A. Platform setup (once per environment, DEV first)

| # | Step | Who | Where | Do this | Check |
|---|---|---|---|---|---|
| 1 | Fill the config file and check your tools | Developer | Terminal | `bash scripts/00_check_tools.sh` | Every required tool prints a version. |
| 2 | Check your Unity Catalog privileges | Whoever runs the UC steps | Databricks SQL editor | `scripts/uc_check_privileges.sql.template` | You hold CREATE SERVICE CREDENTIAL, CREATE CONNECTION, USE CATALOG, CREATE SCHEMA, and own or manage what you must grant on. |
| 3 | Register the job service principal | Entra and Databricks admins | Azure Portal and Databricks account console | manual: see the document section | The principal exists in the workspace; you know its application ID (BRIDGE_JOB_PRINCIPAL). |
| 4 | Inspect Azure (connector, Synapse identity, storage, lifecycle) | Azure admin | Terminal | `bash scripts/01_azure_setup.sh inspect` | Shows the access connector, Synapse workspace identity and any existing lifecycle policy. |
| 5 | Create the access connector (only if step 4 said NOT FOUND) | Azure admin | Terminal | `bash scripts/01_azure_setup.sh create-connector` | az databricks access-connector show returns an id and principalId. |
| 6 | Create the UC service credential | UC credential owner | Terminal | `bash scripts/02_databricks_cli_setup.sh create-credential` | databricks credentials get-credential shows it. |
| 7 | Grant ACCESS on the credential (job principal and setup admin) | Credential owner | Databricks SQL editor | `scripts/uc_admin_setup.sql.template` section B | SHOW GRANTS ON SERVICE CREDENTIAL lists both. |
| 8 | Staging container and the Synapse storage role | Storage admin | Terminal | `bash scripts/01_azure_setup.sh create-container`; `bash scripts/01_azure_setup.sh grant-synapse-storage-role` | The Synapse workspace identity holds Storage Blob Data Contributor on the staging container. |
| 9 | Staging cleanup (lifecycle) rule | Storage admin | Terminal | `bash scripts/01_azure_setup.sh lifecycle` | The rule exists for <container>/<prefix>/ only. |
| 10 | External-location grants (staging and manifest) | Location owner | Databricks SQL editor | `scripts/uc_admin_setup.sql.template` section C | Job principal: READ+WRITE FILES on staging, READ FILES only on manifest. |
| 11 | Synapse: check the master key and review credential scope | Synapse admin (Entra admin of the workspace) | Synapse Studio, dedicated pool | `scripts/synapse_00_check_master_key.sql`; `sql/synapse/03_review_credential_scope.sql` | A master key exists (create it with a vaulted password if not); the credential scope is approved. |
| 12 | Synapse: export objects and grants | Synapse admin | Synapse Studio, dedicated pool | `sql/synapse/01_export_setup.sql` | bridge_stage, bridge_parquet, bridge_msi, bridge_meta exist; a tiny CETAS export works. |
| 13 | Synapse: read-only login for the JDBC fallback | Synapse admin | Synapse Studio (master, then the pool) | `scripts/synapse_10_jdbc_reader_master.sql`; `scripts/synapse_11_jdbc_reader_pool.sql` | The user exists in the pool with SELECT on every source schema. |
| 14 | JDBC driver volume (then upload the JAR) | UC admin | Databricks SQL editor and Catalog Explorer | `scripts/uc_admin_setup.sql.template` section D | LIST on the volume shows the JAR. |
| 15 | Create the UC JDBC connection and grant USE CONNECTION | Connection admin | Catalog Explorer (preferred) or SQL editor | `scripts/uc_admin_setup.sql.template` section E | DESCRIBE CONNECTION works; the job principal has USE CONNECTION. |
| 16 | Notification receiver and its secret | Logic Apps and secrets admins | Azure Portal, then terminal | `bash scripts/02_databricks_cli_setup.sh create-secret-scope`; `bash scripts/02_databricks_cli_setup.sh put-webhook-secret`; `bash scripts/02_databricks_cli_setup.sh grant-secret-read` | The job principal can read the secret (the acceptance job proves it). |
| 17 | Privileges for the person running the setup notebook | UC admin | Databricks SQL editor | `scripts/uc_admin_setup.sql.template` section F | You can create schemas in the control and target catalogs. |
| 18 | Generate config/settings.json from your config file | Developer | Terminal | `python3 scripts/render_settings.py` | config/settings.json exists with no <placeholder>. |
| 19 | Databricks-side permission test (run as yourself) | Whoever will set up and test | Databricks notebook (Git folder) | `src/setup/01_permission_check.py` | ALL PERMISSION CHECKS PASSED. |
| 20 | Setup notebook: preflight, synapse_setup, inventory, uc_setup | Developer and UC admin | Databricks notebook (Git folder) | `src/setup/00_admin_setup.py` | Dry run first, then apply; tables exist. |
| 21 | GitHub: environments, variables, Entra federated credential | Release engineer | Terminal | `bash scripts/05_github_setup.sh environment`; `bash scripts/05_github_setup.sh variables`; `bash scripts/05_github_setup.sh federated-credential` | Environments dev and prod exist; azure/login succeeds in the workflow. |

## B. Feature branch (your own Databricks user and schemas)

| # | Step | Who | Where | Do this | Check |
|---|---|---|---|---|---|
| 22 | Make your personal inventory and reset SQL | You | Terminal | `python3 tools/make_feature_inventory.py --user "$BRIDGE_FEATURE_USER"` | It lists your personal schemas; none equals a DEV schema. |
| 23 | Create your personal schemas and tables | You | Databricks notebook (Git folder, feature branch) | `src/setup/00_admin_setup.py` | Tables exist under feature_<you>_*. |
| 24 | Deploy your personal bundle (target feature) | You | Terminal | `python3 tools/prepare_deploy.py --environment feature`; `BUNDLE_VAR_job_identity="$BRIDGE_FEATURE_USER" BUNDLE_VAR_notification_email="$BRIDGE_NOTIFICATION_EMAIL" BUNDLE_VAR_operations_group="$BRIDGE_OPERATIONS_GROUP" BUNDLE_VAR_rollback_approvers_group="$BRIDGE_ROLLBACK_APPROVERS_GROUP" databricks bundle validate -t feature --profile "$BRIDGE_DATABRICKS_PROFILE"`; `BUNDLE_VAR_job_identity="$BRIDGE_FEATURE_USER" BUNDLE_VAR_notification_email="$BRIDGE_NOTIFICATION_EMAIL" BUNDLE_VAR_operations_group="$BRIDGE_OPERATIONS_GROUP" BUNDLE_VAR_rollback_approvers_group="$BRIDGE_ROLLBACK_APPROVERS_GROUP" databricks bundle deploy -t feature --profile "$BRIDGE_DATABRICKS_PROFILE"` | Jobs named [dev you] ... appear, Run as = you. |
| 25 | Run acceptance and a trial on your feature branch | You | Databricks Jobs UI or CLI | manual: see the document section | ALL ACCEPTANCE CHECKS PASSED; trial tables are PUBLISHED. |
| 26 | Clean up after testing (DESTRUCTIVE) | You | Databricks SQL editor | `build/feature_reset.sql` | SHOW SCHEMAS no longer lists your personal schemas. |

## C. Release (GitHub runner and service principal)

| # | Step | Who | Where | Do this | Check |
|---|---|---|---|---|---|
| 27 | Open the pull request and merge to main | You and reviewers | GitHub | manual: see the document section | CI tests pass; the merge deploys DEV (only DEV). |
| 28 | DEV: acceptance schema, acceptance job, trial run | Release engineer | Databricks SQL editor and Jobs UI | `scripts/uc_admin_setup.sql.template` section G | ALL ACCEPTANCE CHECKS PASSED on the deployed DEV job. |
| 29 | PROD platform setup | Same admins, PROD names | As steps 2-21 | manual: see the document section | Every step 2-21 passed for PROD. |
| 30 | Promote the tested commit to PROD | Release engineer and approver | GitHub Actions | manual: see the document section | PROD acceptance passes with the same commit SHA as DEV. |
| 31 | Go-live: unpause and sign off | Approver | GitHub and Databricks | manual: see the document section | Checklist signed; first scheduled night reviewed. |

