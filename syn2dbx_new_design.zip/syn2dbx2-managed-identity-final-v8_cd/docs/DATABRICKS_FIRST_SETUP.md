# Databricks-first installation and operations

> **Supplemental.** The only authoritative, ordered installation is `START_HERE_COMPLETE_SETUP.md`; this file
> explains the setup notebook's widgets. Where they differ, START_HERE wins.

This package can run the *bulk of
setup* directly from Azure Databricks after Azure identities, RBAC, networking,
GitHub and Unity Catalog service credential have been approved/provisioned.
Do DEV first. Do not run setup under the nightly service principal.

## Responsibility boundaries

| Task | Platform | Operator |
|---|---|---|
| Entra job service principal, Azure access connector, managed identity | Azure CLI / platform IaC | Azure identity administrator |
| Create UC service credential and grant ACCESS | Databricks CLI/API + Databricks SQL | UC credential administrator |
| Source CETAS permission review | Synapse dedicated pool, via Databricks notebook read-only and admin review | Synapse administrator |
| Synapse setup objects | Notebook only **renders** the SQL; the Synapse administrator runs it in Synapse Studio | Synapse administrator |
| Generate reviewed inventory | Databricks notebook in Git folder | Data engineer |
| Generate/control/target UC tables and grants | Databricks administrator notebook | UC/schema administrator |
| DEV/PROD job deployment | GitHub Actions, from reviewed commit | Release engineer |
| Acceptance, nightly processing, maintenance | Databricks Jobs | Operator |

Why not *everything* in one notebook? Azure RBAC and UC credential creation
have higher privileges than the nightly job. A single principal with those
permissions would violate least privilege. GitHub CI/CD remains the source of
truth for PROD promotion.

## Prerequisites — first time only

1. Complete **Sections 1–5** of
   [UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md](UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md).
   It provides Azure CLI and Databricks CLI commands and SQL grants.
2. Provision/verify staging and upstream ADLS external locations, separate
   credentials, network routes and summary webhook secret.
3. Arrange Synapse administrative approval for
   `sql/synapse/03_review_credential_scope.sql`. The notebook does not
   waive this security gate.
4. Connect the repo as a **Databricks Git folder**; open the package root.
   Keep `config/settings.json` and inventory files controlled. Never commit
   live secret values. Use separate DEV/PROD values.
5. Use an **interactive administrator-controlled serverless notebook session**
   with `mssql-python==1.15.0`, `azure-identity` and the required identity/
   UC permissions. These are already referenced for the nightly job in
   `databricks.yml`, but interactive notebooks require their own environment
   dependencies. A SQL warehouse cannot directly run the Python credential
   provider.

For the separate fallback JDBC connection, follow
[JDBC_CONNECTION_SETUP.md](JDBC_CONNECTION_SETUP.md), including its driver-volume
grants and option allowlist. For GitHub federation and release identities,
follow [GITHUB_OIDC_SETUP.md](GITHUB_OIDC_SETUP.md).

## Open the setup notebook

Open `src/setup/00_admin_setup.py` in Databricks and attach an approved
serverless notebook compute session. This notebook is **not automatically
scheduled** and is **not** included as a job resource in `databricks.yml`.
Its privilege is the identity of the administrator who runs it.

Widget meanings:

| Widget | Example | Purpose |
|---|---|---|
| `action` | `preflight` | `preflight`, `synapse_setup`, `inventory`, `uc_setup` |
| `settings_file` | `config/settings.json` | Approved JSON in repository config folder |
| `inventory_file` | `config/inventory.dev.json` | Reviewed output/input; never auto-overwritten |
| `source_schemas` | `dbo,sales` | Source schema(s) for inventory |
| `target_catalog` | `analytics_dev` | Inventory generation |
| `target_schema` | `gold` | Inventory generation |
| `synapse_login_identity` | `mi-bridge-dev` | Actual Entra managed-identity display name |
| `job_principal` | `<approved-job-app-id>` | Recipient of UC grants |
| `consumer_group` | `analysts_dev` | Optional table-reader group |
| `apply_changes` | `false` | Remains dry-run unless `true` |
| `confirmation` | `APPLY_DEV_SETUP` | Required with `apply_changes=true` |

> For PROD, use the same manually approved process in the PROD workspace
> with PROD-specific settings. The confirmation text is an explicit check,
> **not an authentication mechanism**.

## Exact order

### 1. Preflight — read-only

**Only after the Synapse administrator has run `sql/synapse/01_export_setup.sql` (step 2 below, or
START_HERE section 6).** Until the connector's database user exists, the login in this step is rejected.

Set `action=preflight`, `settings_file=config/settings.json`,
`apply_changes=false`. Run the notebook.

Expected: the serverless job context obtains a token through the UC service
credential and connects to the correct Synapse dedicated pool. Inspect the
reported database/login; stop if either is unexpected. A token alone does not
prove permission to CETAS or UC JDBC fallback.

### 2. Synapse SQL — render, approve, administrator applies

Before running, the Synapse administrator reviews the output of
`sql/synapse/03_review_credential_scope.sql` against the pool's existing
database-scoped credentials. Run it using the authorised Synapse connection.

Set `action=synapse_setup`, `source_schemas=dbo`,
`synapse_login_identity=<approved-managed-identity-display-name>`, and
`apply_changes=false`. The notebook prints the full SQL.

Review the external data source location and broad CETAS privileges.
Once approved, send the exact rendered SQL to the Synapse administrator for
execution in Synapse Studio or an approved SQL client. **Do not set
`apply_changes=true` for `synapse_setup`: the notebook deliberately refuses
that operation.** The administrator must provision the database master key
first if it does not already exist; see `START_HERE_COMPLETE_SETUP.md` §6.

**Important:** The notebook uses the service-credential identity for
read-only checks. The administrator applies Synapse DDL with a separate
approved admin connection; never grant database-owner rights to the nightly
job or its service credential for installation.

For multiple source schemas, give them comma-separated in `source_schemas` (for example `dbo,sales`): the
rendered SQL contains one reviewed `GRANT SELECT` per schema. Each schema still needs the same approval.

### 3. Generate inventory — review before saving

Set `action=inventory`, `source_schemas=dbo,sales`,
`target_catalog`, `target_schema` and an **unused**
`inventory_file=config/inventory.dev.json`. With `apply_changes=false`,
the notebook reports how many mappings it would generate.

Optional: `exclude_objects=dbo.InternalTable,sales.ObsoleteView` excludes
specific source objects. `profile_tables=true` estimates base-table storage
from dedicated-pool metadata (which may require DMV permissions). Views are
always zero-estimated and require manual size review.

Review selected tables. This notebook uses the package's existing column
contract and schema-hash functions. Base-table sizes are profiled only with `profile_tables=true`; views
are always 0, so set `estimated_bytes` thoughtfully for large tables/views afterward.
For the approved output run with `apply_changes=true` and confirmation.
The notebook **refuses to overwrite** an existing inventory file.

Review mandatory flags, allow_empty, target names, source view contracts,
data types and sizes. Commit reviewed inventory to Git.

### 4. UC setup — render, approve, apply

Set `action=uc_setup`, `inventory_file=config/inventory.dev.json`,
`job_principal=<approved-job-app-id>`, optional
`consumer_group=analysts_dev`, `apply_changes=false`.
The notebook prints all SQL including table schemas and grants.

After UC/schema-owner review, run with `apply_changes=true` and confirmation.
The commands are executed serially. **If an intermediate statement fails,
earlier statements may already be committed.** Inspect partial state,
correct the cause, then use the idempotent setup carefully. Never assume
the setup is one atomic transaction.

### 5. DEV deployment and acceptance

Leave scheduled jobs PAUSED. Commit reviewed code and inventories to GitHub.
Use the existing GitHub Actions workflow to deploy the selected commit to DEV.
Run the Databricks acceptance job, then 2–3 source mappings, and finally the
approved full DEV inventory. Confirm CETAS success, fallback, row counts,
Delta overwrite/idempotency, per-table failures and final webhook summary.
This setup notebook never replaces the acceptance job.

### 6. PROD release

Configure and validate separate PROD identities, external locations,
credentials and grants, using approved PROD administrators. Promote **the same
tested commit** through the protected GitHub Environment. Run PROD acceptance
with schedules PAUSED. Only unpause after authorised go-live approval.

## Safety and recovery

- `preflight` reads metadata and obtains a short-lived token.
- All mutating notebook actions default to `apply_changes=false`.
- The notebook does not create Azure identities, grant Azure RBAC, delete
  resources, overwrite reviewed inventories or publish business data.
- Neither SQL setup nor UC setup is transactionally all-or-nothing. Inspect
  existing objects and approvals before rerunning a failed setup.
- The notebook requires the full repo available as Databricks workspace files
  in a Git folder; it will not work when opened without the `tools/` folder.
- PROD setup should use an approval-controlled admin session. Never attach
  these actions to the nightly service-principal job.

See [DEPLOYMENT_FROM_SCRATCH.md](DEPLOYMENT_FROM_SCRATCH.md) for the full
provisioning sequence and [RUNBOOK.md](RUNBOOK.md) for recovery operations.
