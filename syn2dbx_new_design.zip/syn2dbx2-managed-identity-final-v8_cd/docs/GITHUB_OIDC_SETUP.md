# GitHub Actions → Azure Databricks deployment (DEV then PROD)

The package uses `.github/workflows/ci-cd.yml` and the reusable `bundle-deploy.yml`. Deployment logs in through **GitHub OIDC → Microsoft Entra application → Azure CLI → Databricks**. This is not the same identity as the nightly Databricks job run-as service principal. Do not deploy from a personal credential to PROD.

## 1. Create GitHub Environments

1. GitHub repository > Settings > Environments > New environment: `dev`; repeat for `prod`.
2. Set PROD required reviewers and deployment branch restrictions (normally protected `main`). Have an authorised repository administrator enable branch protection and required CI checks.
3. In GitHub Settings > Actions > General, ensure approved workflows can run and their token permissions comply with repository policy. The YAML already requests `id-token: write` and `contents: read`.
4. The workflows select the GitHub Environment, so the OIDC token is scoped to that environment. DEV and PROD should preferably have **different deployment principals**.

## 2. Entra deployment application and federated credentials

Azure administrator: Microsoft Entra ID > App registrations > select an approved deployment application or create one under company policy. Record client ID, tenant ID and (if relevant) subscription ID.

For each GitHub Environment, navigate to App registration > Certificates & secrets > Federated credentials > Add credential > **GitHub Actions deploying Azure resources**. Choose the correct owner/repository and the *Environment* entity, `dev` or `prod`.

Issuer is `https://token.actions.githubusercontent.com`; audience is `api://AzureADTokenExchange`. The `subject` must match **the real token emitted by this repository/environment**. GitHub/Entra introduced immutable subject formats in 2026; new, renamed and transferred repositories may produce a different subject from the legacy `repo:owner/repo:environment:dev` format. Use the GitHub OIDC subject preview or your security team's current policy; **do not invent or blindly hardcode a legacy subject**. If using CLI, create the credential only after reviewing the exact issuer, audience and subject; never overwrite an existing federation without approval.

Microsoft references: [Azure Login with OIDC](https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect) and [immutable GitHub subjects](https://learn.microsoft.com/en-us/entra/workload-id/workload-identities-github-immutable-subjects).

## 3. Databricks deployment permission

1. Register the deployment Entra service principal in the Databricks account/workspace under your organisation's identity automation.
2. Grant only the target workspace deployment rights needed to create/update the package's Jobs, workspace files and resource permissions. A deployment principal with no ability to manage existing Jobs will fail on an update.
3. Grant that **deployment** principal the Databricks permission to configure Jobs using the **nightly job** service principal as `run_as` (the identity administrator must verify the exact service-principal `CAN_USE` / Service Principal User entitlement in the current workspace UI).
4. Do **not** give the deployment principal the Synapse managed identity's SQL privileges, and do not make the nightly job principal workspace admin solely to make deployment work.
5. Validate the actual deployment identity with `databricks auth describe` in the approved release runner before deploying, and inspect the deployed Job **Run as** value afterward.

## 4. Set exact GitHub Environment variables

Repository > Settings > Environments > `dev` (then `prod`) > Environment variables:

| Name | Value |
|---|---|
| `AZURE_CLIENT_ID` | Approved deployment application's client ID (different by environment if used) |
| `AZURE_TENANT_ID` | Entra tenant ID |
| `AZURE_SUBSCRIPTION_ID` | Subscription ID if applicable; the workflow allows no subscription role |
| `DATABRICKS_JOB_IDENTITY` | **Nightly job** service principal application/client ID, not the deploy principal |
| `NOTIFICATION_EMAIL` | Approved Databricks job failure notification recipient |
| `OPERATIONS_GROUP` | Existing Databricks operations group |
| `ROLLBACK_APPROVERS_GROUP` | Separate, more restricted rollback approver group |
| `EXPORT_CONCURRENCY` | DEV-approved concurrency, initially 4 or lower based on Synapse capacity |
| `NIGHTLY_PAUSE_STATUS` | `PAUSED` before sign-off |
| `MAINTENANCE_PAUSE_STATUS` | `PAUSED` before sign-off |

Although these IDs are not client secrets, use GitHub Environment **secrets** where your organisation classifies them as sensitive. If you move them from variables to secrets, update `bundle-deploy.yml` expressions accordingly. **Never add client secrets, Synapse passwords, or webhook URLs as plaintext repository variables.**

## 5. Configure and validate targets

In `databricks.yml`, replace `https://<dev-workspace>.azuredatabricks.net` and its PROD counterpart. The job uses `${var.job_identity}` as `run_as`, and the deployment chooses the `dev` or `prod` bundle target.

The checked-in, reviewed `config/inventory.dev.json` and `config/inventory.prod.json` are separate. `tools/prepare_deploy.py` copies the chosen inventory to `config/inventory.json` for the bundle. It does **not** provision UC grants, secrets, Azure RBAC or Synapse SQL.

## 6. CI/CD order and acceptance

1. Open a PR to `main`; `.github/workflows/ci-cd.yml` runs the test job (with Spark/JDBC dependencies).
2. Merge reviewed code/inventory. On push to `main`, tests pass before **DEV deployment only**. PROD is never started automatically by a merge or a successful DEV deployment.
3. Start with both schedules PAUSED. Run the Databricks acceptance Job after deployment, followed by a small DEV mapping trial and full DEV rehearsal.
4. Once DEV acceptance has passed, record the Git commit SHA, Databricks acceptance run ID, representative CETAS/fallback results, and the operations sign-off in an approved change ticket. Confirm `main` still points to that exact tested SHA. If code has changed, repeat DEV validation.
5. For PROD, open GitHub Actions > `ci-cd` > Run workflow **on `main`**, select `prod` and enter the approved DEV acceptance ticket or run ID in `dev_acceptance_evidence`. The workflow will not schedule PROD without nonempty evidence. This is an attestation field, not an automated verification of the ticket; the PROD Environment reviewer must independently check the evidence and commit SHA.
6. After the PROD environment reviewer approves, inspect the GitHub workflow logs, job Run-as, job tasks and target workspace URL before declaring deployment complete. Keep schedules paused until business/operations sign-off.

## 7. Common failures

| Symptom | Check |
|---|---|
| `azure/login` says no matching federated identity | Actual GitHub OIDC `sub`, owner/repo/environment, 2026 immutable subject mode, issuer and audience |
| `azure/login` succeeds, Databricks auth fails | Workspace principal assignment, `DATABRICKS_AUTH_TYPE=azure-cli`, target workspace permissions |
| Cannot set Job Run-as | Deployment principal's permission on the nightly job service principal |
| Bundle target points to placeholder | Replace workspace hosts in `databricks.yml` |
| Job accesses wrong catalog or source | Confirm selected `inventory.<environment>.json` and deployed `config/inventory.json` |
| PROD unexpectedly unpauses | Restore `NIGHTLY_PAUSE_STATUS=PAUSED` and redeploy after incident review |

Official setup guidance: [Azure Login with OIDC](https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect), [Databricks GitHub federation](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/auth/provider-github).
