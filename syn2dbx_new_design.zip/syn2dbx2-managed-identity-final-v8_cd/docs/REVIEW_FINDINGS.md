# Review findings (v4 package, with the v6 and v7 fix passes at the top)

## v7 fix pass (2.6.11)

Verified v5 and v6 side by side: runtime code identical (comments aside); v6 adds the scripts, numbered steps,
settings renderer, permission check and feature-branch target. v7 is v6 plus: stale statements corrected
(item 1 and item 5 below, the version tag, the test count, the "v6" naming in `AGENTS.md`), shell scripts made
`shellcheck`-clean (shebang on sourced files, resolved Synapse identity failure now reports the intended message,
literal matching of the secret-scope name), `render_sql.py` error text and comments corrected, and tests that
keep these true. No behavioural change to the nightly job. The open items below still need a real workspace.

## v6 fix pass (2.6.10)

Fixed: serverless Parquet-rebase conf risk (tolerant bootstrap; still needs the DEV smoke test), timezone-dependent
tests, false "acceptance validates notifications" claims, missing `CREATE SCHEMA` in the JDBC guide, multi-schema
Synapse grants, wrong order in `DATABRICKS_FIRST_SETUP.md`, stale supplemental docs, missing Java 17 / `az`
extensions / per-person privileges / storage, secret, Logic App and unpause steps, and no runnable scripts for most
setup commands (`scripts/` added). **Not verifiable offline:** Azure, Synapse and Databricks runtime behaviour, the
pinned `setup-cli` SHA, DBR version availability and which Spark confs serverless accepts.

# Review findings (v4 package)

Method: unpacked the zip; ran the 417 existing tests (all passed; 435 with the real `mssql-python` driver); validated `databricks.yml` against the Databricks CLI v0.280 bundle JSON schema (valid); executed the admin-setup helpers with a fake Synapse connection; rendered the UC setup SQL and simulated how the notebook applies it; read every notebook, the SQL, both workflows and all setup documents.

## Fixed in this package

| # | Severity | Finding | Fix |
|---|---|---|---|
| 1 | High | `config/inventory.json` is git-ignored; `databricks bundle deploy` skips git-ignored files, so the deployed jobs would have no inventory and every task would fail at `load_settings()`. | `sync.include` in `databricks.yml` + test |
| 2 | High | `00_admin_setup.py action=uc_setup apply_changes=true` split the SQL on `;\n`, leaving two comment-only chunks. Spark rejects an empty statement, so apply stopped at 10/18, after the control tables and before any target table. | `split_statements()` drops comment-only chunks + tests |
| 3 | Medium | START_HERE tells the reader not to commit `config/settings.json`, but `.gitignore` did not exclude it. | `.gitignore` |
| 4 | Medium | RUNBOOK and PACKAGE_GUIDE said a merge deploys to prod after approval; the workflow deploys DEV only. | Text corrected |
| 5 | Medium (docs) | START_HERE (declared self-sufficient) omitted: acceptance job parameters and scratch schema (the job fails immediately without them), DEV time/cutoff rules, how to create the test manifest, how to force a fallback, admin `ACCESS` grant for preflight, Entra-admin requirement for `CREATE USER FROM EXTERNAL PROVIDER`, which name to use for the login, how to create the JDBC SQL user, how to install the notebook libraries, Git-folder steps, tool installation. | Added to START_HERE |

## Open items you must verify on a real workspace (could not be tested here)

1. **Serverless Spark settings.** `_bootstrap.py` sets four `spark.sql.parquet.*RebaseMode*` settings in every notebook. Databricks' serverless page lists only six changeable settings and none of these. If serverless rejects one, `_bootstrap.py` now prints a warning and carries on (the Spark default then fails a pre-1582 value loudly for that table), and acceptance check 12 reports the rejected setting. START_HERE 10.3a now has a 10-line smoke test. If it prints REJECTED, the code needs a design change (not a doc change).
2. `spark_version: 18.x-scala2.13` for the maintenance/rollback classic clusters: confirm it exists in your workspace.
3. Real-pool behaviour: the CETAS grants, `HADOOP` external data source with managed-identity credential, access-token login through `mssql-python` and the UC JDBC option allow-list are exercised only by the acceptance job, not by the unit tests.
4. The two Spark/Derby test files were skipped here (PySpark would not build in the sandbox); CI runs them.
5. ~~`databricks.yml` job tag still says `version: 2.6.9`~~ fixed in v7: the tag follows `__version__` (tested).
