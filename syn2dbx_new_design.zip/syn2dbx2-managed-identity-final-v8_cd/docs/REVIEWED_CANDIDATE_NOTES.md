# Reviewed candidate notes — 2026-10-23

## v3 follow-up corrections

- Made `START_HERE_COMPLETE_SETUP.md` the sole primary onboarding path in README.
- Added `JDBC_CONNECTION_SETUP.md`: explicit driver-volume access, UC JDBC
  configuration, **query-time options allowlist**, and serverless checks.
- Added `GITHUB_OIDC_SETUP.md`: protected environments, Azure federation,
  current immutable subject consideration, deployment/run-as grants and tests.
- Inventory profiling now emits a targeted diagnostic when dedicated-pool DMV
  access is missing; operators may profile by hand instead.
- These are changes for DEV verification, not proof of cloud runtime behavior.

## Complete setup correction (2026-10-23)

- New primary first-time developer guide: `START_HERE_COMPLETE_SETUP.md`, with
  identities, Azure RBAC, Unity Catalog grants, staging/manifest permissions,
  setup order, verification, GitHub deployment and DEV go-live gates.
- Synapse setup now **requires an administrator-provisioned database master
  key** and raises an explicit error if missing. Passwords are not embedded.
- Databricks administrator notebook renders Synapse setup SQL but refuses to
  execute Synapse DDL through the nightly managed-identity service credential.
- Databricks inventory action now supports comma-separated `exclude_objects`
  and optional base-table size estimates with `profile_tables=true`.
- Added focused regression tests. Offline pytest run: **411 passed, 20 skipped**
  (environment-specific tests remain unavailable here). This does not prove
  Azure connectivity, Synapse T-SQL execution, UC grants, JDBC or live Delta.

The `START_HERE_COMPLETE_SETUP.md` guide supersedes conflicting historical
onboarding sequences in older supplemental documents.

## Databricks-first setup update

- Added `src/setup/00_admin_setup.py`: unscheduled notebook with preflight,
  approved Synapse SQL setup, inventory generation and UC table/grant setup.
- Added `tools/databricks_admin_setup.py`: shared routines, constrained
  repository config paths, no-overwrite inventory, explicit dry-run behavior.
- Added `docs/DATABRICKS_FIRST_SETUP.md` with workflow order and a clear
  separation between Azure admin, Databricks admin and nightly job identities.
- Added basic offline regression tests for setup rendering and dry-run safety.
- This is a **candidate requiring DEV validation**; the full suite and cloud
  admin setup actions were not executed in this environment.

## Script-first onboarding update

- Added `UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md` with Azure CLI access
  connector inspection/creation, Databricks CLI service credential setup,
  SQL ACCESS grants, Synapse identity permissions and DEV token/login checks.
- Linked the detailed guide into the deployment sequence and README.
- Commands are examples requiring administrator approval and real DEV
  execution; no cloud resources were provisioned while producing the package.

This is a configuration, Synapse setup and onboarding documentation correction
of the supplied 4A package. It is **not a production-certified release**.

## Changes

- Centralised the four environment-specific values at the beginning of
  `01_export_setup.sql`; removed repeated literal placeholder checks and GO
  batches. Granted the **actual Synapse login identity** rather than implicitly
  assuming it is the Databricks job's run-as identity. Added early checks
  for a pre-existing external data source at a different location and
  incompatible file format.
- Added the authoritative managed-identity provisioning, DEV validation
  and PROD promotion guide `DEPLOYMENT_FROM_SCRATCH.md`.
- Marked earlier `FIRST_RUN.md`, `SETUP_CHECKLIST.md` and `sp_bridge.md`
  instructions as client-secret/historical examples where applicable.
- Standardised first-run/short-checklist manifest marker references to
  `_SUCCESS`, matching the code configuration and upstream manifest specification.
- Linked the new guide from the README and package guide.

## Verification and limitations

- Source Python syntax compilation completed successfully.
- The JSON settings template parses.
- Full pytest suite **not run** because pytest and additional dependencies
  are not installed in this execution environment.
- The Synapse SQL has **not been executed** against a dedicated pool.
- UC service credential token acquisition, Synapse identity resolution,
  serverless JDBC, Azure Storage access, Delta writes and Databricks Asset
  Bundle deployment **must be proved in DEV** before release.
- No change was made to nightly business logic, fallback logic, publication
  mechanics or recovery controls. An independent full code/security review
  remains advisable if the package has not already passed one.

## Required release gate

Install `requirements-dev.txt`, run `python -m pytest tests -q`, review
the Synapse script with a dedicated-pool administrator, and complete every
DEV acceptance test in `DEPLOYMENT_FROM_SCRATCH.md` before enabling PROD.
