# Start here: complete DEV-to-PROD installation

This is the **single authoritative installation runbook** for this 4A package. Use it in order. It assumes the developer is new to Azure Synapse, Azure Databricks, Unity Catalog and GitHub Actions. The procedure creates no production resources automatically. Obtain approval for each security-sensitive operation. First finish DEV; PROD repeats the steps with separate identities and names. The linked documents are optional deeper references; the required execution sequence and decision gates are here.

**Command scripts:** every command block in this guide also exists as a runnable, dry-run-by-default script in `scripts/` (see `scripts/README.md`), and the whole setup is numbered in [STEP_BY_STEP.md](STEP_BY_STEP.md). Copy `scripts/env.example.sh` to `scripts/env.dev.sh`, fill in your section-1 worksheet values once, and the scripts, the SQL templates and `config/settings.json` (step 18) all use those same names.

**Execution key:** `MANUAL` means a named administrator performs the Portal/SQL action; `SCRIPT` means run the exact package file; `AUTO` means the approved deployment/job performs the action. Do not use the nightly job service principal for administrator setup. Each section has an explicit verification step. Record names, job/run IDs and approval evidence, never raw credentials.

## Roadmap: who does what, in order

| Section | What you finish | Who | Scripts |
|---|---|---|---|
| 1 | Worksheet of names and IDs; tools installed | Developer | `env.example.sh`, `00_check_tools.sh` |
| 2 | Know which person or identity needs which permission | Everyone | none |
| 3 | Job service principal registered | Entra + Databricks admins | none (manual) |
| 4 | Access connector and UC service credential | Azure + UC admins | `01_azure_setup.sh`, `02_databricks_cli_setup.sh`, UC SQL |
| 5 | Staging and manifest storage, external locations, cleanup rule | Storage + UC admins | `01_azure_setup.sh`, UC SQL |
| 6 | Synapse pool objects and permissions | Synapse admin | `synapse_00_*.sql`, `sql/synapse/` |
| 7 | UC JDBC fallback connection | Synapse + UC admins | `synapse_10/11_*.sql`, UC SQL |
| 8 | Notification webhook and upstream manifest | Logic Apps + secrets admins, upstream team | `02_databricks_cli_setup.sh` |
| 9 | Settings, inventory, control and target tables | Developer + UC admin | setup notebook |
| 10 | GitHub deployment, DEV acceptance, DEV trial | Release engineer | `05_github_setup.sh` |
| 11 | PROD promotion and go-live | Release engineer + approvers | `05_github_setup.sh` |

Section 4 must come first (section 6 needs the connector's name), and section 6 before the acceptance job. Sections 5, 7 and 8 can be done in parallel by different administrators once 4 is finished. Do all of DEV before starting PROD.

## File flow: which file, in which order

**One config file, numbered steps.** Everything you decide (names, IDs, endpoints) is typed once, in `scripts/env.dev.sh` (copy `scripts/env.example.sh`; use `scripts/env.prod.sh` for PROD). The steps run in a fixed order, 1 to 31, listed in [STEP_BY_STEP.md](STEP_BY_STEP.md):

```bash
cp scripts/env.example.sh scripts/env.dev.sh      # edit EVERY value, once
python3 scripts/steps.py list                     # all 31 steps, [x] = done, and which is next
python3 scripts/steps.py show 7                   # who does it, where, what, how to check it
python3 scripts/steps.py run 7                    # run it (cmd steps) or write build/step07.sql (sql steps)
python3 scripts/steps.py done 7                   # tick it off
```

Three phases:

| Phase | Steps | Who and where |
|---|---|---|
| A. Platform setup, once per environment (DEV first, then PROD) | 1-21, PROD repeats 2-21 | Admins; terminal, Databricks SQL editor, Synapse Studio, portal |
| B. Feature branch | 22-26 | You, in your own Databricks user and your own `feature_<you>_*` schemas (section 10a) |
| C. Release | 27-31 | GitHub runner with the service principal deploys DEV, then PROD by approved dispatch |

Steps that call a script in `scripts/` are dry runs until you add `CONFIRM=yes`. Steps 11-13 (Synapse SQL), 3 and 16 (Entra, Logic App) and the notebook steps are done by hand in the tool named in the step; `show N` names the exact file. Steps 7, 9, 10, 14 and 15 can overlap once step 6 is done; step 12 needs the connector name from step 4.

## 0. What the bridge does

Each day, an upstream process finishes refreshing Synapse dedicated-pool tables or views, then writes `row_counts.csv` and finally `_SUCCESS` to a separate upstream ADLS container. A Databricks serverless Job plans mappings, asks Synapse to export each view via CETAS into staging ADLS, validates Parquet and row counts, and publishes UC managed Delta tables. Eligible CETAS failures take a separate governed UC JDBC fallback. Every table keeps its previous data if publication fails. The final task records a summary and invokes an approved HTTPS webhook. See `DESIGN.md`, `UPSTREAM_MANIFEST_SPEC.md`, and `RUNBOOK.md` for the exact contract and repair procedure.

**Never manually run the nightly component notebooks out of order.** Jobs and dependencies are in `databricks.yml`. The one-time manual Databricks setup notebook is `src/setup/00_admin_setup.py`.

## 1. Collect the environment worksheet (developer; read-only)

Before any changes, fill this table for DEV, then separately for PROD. Record references and resource names, not passwords:

| Value | Where to find it |
|---|---|
| Azure tenant, subscription, resource group and region | Azure Portal > Subscriptions / Resource groups |
| Azure Databricks workspace URL and metastore | Azure Portal > Databricks workspace; Databricks Catalog Explorer |
| Synapse workspace endpoint and **dedicated SQL pool database name** | Synapse Studio > Manage > SQL pools |
| Synapse workspace managed identity principal ID | Azure Portal > Synapse workspace > Identity |
| Access connector name, resource ID and managed identity principal ID | Azure Portal > Access connectors for Azure Databricks |
| Databricks job service principal application ID | Entra ID > App registrations / Enterprise applications, then Databricks admin console |
| Staging ADLS container root `abfss://container@account.dfs.core.windows.net` | Azure Portal > Storage account > Containers |
| Upstream manifest container and completion contract | Upstream owner; `UPSTREAM_MANIFEST_SPEC.md` |
| UC control catalog/schema and target catalog/schema | Databricks Catalog Explorer |
| UC service credential, JDBC connection and ADLS external locations | Catalog Explorer > External data |
| Notification Logic App HTTPS endpoint secret scope/key | Databricks Secrets / approved secrets administrator |
| GitHub repo, `dev`/`prod` Environments and deploy identity | GitHub repository settings / Entra |

**Prerequisite:** Azure networking must permit serverless Databricks SQL connections to Synapse dedicated pool and the required ADLS accounts. Ask your networking team to confirm private endpoints, DNS, firewalls, and serverless network connectivity configuration. Network failures cannot be corrected by SQL privileges.

### 1a. Install and check the tools (developer / release engineer, once per machine)

You need these on the machine used for sections 3-4 and 10 (a laptop or a CI runner). Check each with the command shown; every command must print a version.

| Tool | Check | Install |
|---|---|---|
| Git | `git --version` | https://git-scm.com/downloads |
| Python 3.12 (the version CI and serverless environment 3 use) | `python3 --version` | https://www.python.org/downloads/ |
| Azure CLI | `az version` | https://learn.microsoft.com/cli/azure/install-azure-cli |
| Databricks CLI (current, "unified" CLI, not the legacy `databricks-cli` pip package) | `databricks --version` | https://docs.databricks.com/dev-tools/cli/install.html |
| Java 17+ (PySpark runs the tests in section 10 step 4; without it they error) | `java -version` | https://adoptium.net/ |
| Azure CLI extensions `databricks` and `synapse` (for `az databricks access-connector` and `az synapse`) | `az extension list -o table` | `az extension add --name databricks` and `az extension add --name synapse` |
| GitHub CLI `gh` (optional; only for `scripts/05_github_setup.sh`) | `gh --version` | https://cli.github.com/ |

`bash scripts/00_check_tools.sh` runs all of these checks and adds the two Azure CLI extensions.

Then sign in once: `az login`, and for each environment `databricks auth login --host https://<workspace>.azuredatabricks.net --profile bridge-dev` (use `bridge-prod` for PROD). Confirm with `databricks auth describe --profile bridge-dev`.

Two things to confirm before going further:

1. In the Azure Portal / Databricks account console, the **DEV workspace has Unity Catalog attached (a metastore assigned)** and **serverless compute for notebooks and jobs is enabled** (account console > Settings > Feature enablement). Without both, nothing below works.
2. **Run the serverless compatibility smoke test (section 10, step 3a) now.** It needs only a DEV serverless notebook and tells you early whether the nightly job's start-up settings are accepted.

## 2. Who needs which permission?

| Identity / person | Minimum relevant access | Grant location | Verify |
|---|---|---|---|
| Azure identity administrator | Approved rights to create/reuse access connector and configure managed identities | Azure resource group and Entra | Azure access connector Identity pane |
| Synapse administrator | DDL and user/grant administration in **dedicated pool** | Synapse Studio / approved SQL client | Database objects and `sys.database_permissions` |
| Synapse **workspace** managed identity | `Storage Blob Data Contributor` on **staging container**, plus any necessary ACLs | Azure Storage IAM / ADLS ACL | Tiny approved CETAS test |
| Access connector managed identity | Synapse database principal with source `SELECT` and explicitly approved CETAS rights | Synapse dedicated-pool database | `SELECT DB_NAME(), SUSER_SNAME(), USER_NAME()` via credential |
| UC credential administrator | `CREATE SERVICE CREDENTIAL`/credential ownership, approved Azure connector permissions | Databricks Catalog Explorer / SQL and Azure | `SHOW GRANTS ON SERVICE CREDENTIAL` |
| Databricks job service principal | Workspace assignment; `ACCESS` service credential; `USE CONNECTION`; catalog/schema/table access; staging `READ FILES`/`WRITE FILES`; manifest `READ FILES`; webhook secret read | Databricks account/workspace/Unity Catalog/secret scope | Acceptance job as the **job identity** |
| UC/storage administrator | Existing storage credential/external location ownership and location grants | Catalog Explorer / SQL | `SHOW GRANTS ON EXTERNAL LOCATION` |
| GitHub deploy principal | Approved Databricks workspace deployment rights, and permission to set `run_as` to job principal | Entra federation, Databricks workspace | `databricks bundle validate` in GitHub Actions |
| Setup-notebook administrator (section 9) | `ACCESS` on the service credential; `USE CATALOG` and `CREATE SCHEMA` on the control and target catalogs, plus ownership or `MANAGE` so the notebook can `GRANT`; `USE CONNECTION` to see the JDBC connection | Unity Catalog (`scripts/uc_admin_setup.sql.template` sections B and F) | `00_admin_setup.py action=uc_setup` dry run, then apply |
| Person who runs the acceptance and trial jobs (section 10) | Member of `ROLLBACK_APPROVERS_GROUP` (acceptance) and `OPERATIONS_GROUP` (nightly), or job `CAN_MANAGE_RUN`; a GitHub deploy makes the deploy principal the job owner, so a human is **not** allowed to run the jobs otherwise | Databricks workspace groups | The **Run now** button is enabled |
| Consumers | `USE CATALOG`, `USE SCHEMA`, `SELECT` on target tables | Unity Catalog | Query as test consumer |

**Do I have the Unity Catalog rights?** "UC admin" is not a separate person you must find. It means whoever holds the privileges to grant inside Unity Catalog, and that can be you. A Databricks **workspace admin is not automatically a metastore admin**. You can run every UC step yourself if you:
- own the external locations and the service credential (you created them), or are a metastore admin;
- hold `CREATE SERVICE CREDENTIAL` and `CREATE CONNECTION` on the metastore (needed to create those two objects), or are a metastore admin;
- hold `USE CATALOG` and `CREATE SCHEMA` on the catalogs you reuse, and are the catalog owner or hold `MANAGE` so you can give the job principal `USE CATALOG` (a schema owner cannot grant that).

Check with `scripts/uc_check_privileges.sql.template` (read-only; render it with `scripts/render_sql.py` like the other template). Once `config/settings.json` exists (step 18), also run the Databricks-side test notebook `src/setup/01_permission_check.py` **as yourself** (step 19). It proves, with throw-away objects it removes again, that your user can use the catalogs, create a schema and table, get a Synapse token from the service credential, log in to the pool and hold the pool rights CETAS needs, read and write the staging folder, read the manifest folder, run a query through the JDBC connection, and read the webhook secret. It prints PASS/FAIL per check with the exact grant to ask for. Widgets: `source_schemas`, `target_catalog`, and optionally `driver_jar_path`, `operations_group`, `rollback_approvers_group`. If a right is missing, ask the catalog owner or a metastore admin for just that statement; the SQL is already written in `scripts/uc_admin_setup.sql.template`. Skip section A of that template if the catalogs already exist.

In Databricks, **UC service credential**, **storage credential**, and **JDBC connection** are three different objects. The job service principal and access-connector managed identity are also different. Do not grant broad metastore admin, database owner, or storage account Contributor privileges to the nightly job for convenience.

## 3. Register the job service principal (Entra and Databricks administrators)

1. Azure Portal > Microsoft Entra ID > App registrations: select an approved existing application or create one under your organisation's policy. Record the **application/client ID**. No new app is needed when an approved job principal already exists.
2. Databricks account console > User management > Service principals: add the existing Entra application to the account if absent; assign it to the DEV workspace.
3. A workspace administrator must allow the deployment identity to configure Jobs running as that service principal (`Service Principal User` / applicable `CAN_USE` run-as permissions in your workspace version).
4. Do not give the principal an Azure client secret for this package's default `service_credential` Synapse authentication. The job runs *as* the principal in Databricks, then uses the permitted UC service credential to obtain an Azure token.
5. Record the principal's exact registered name/application ID; inspect before issuing UC grants.

## 4. Create/reuse managed identity and UC service credential (Azure + UC administrators)

Follow `UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md` **sections 1–5 in order**. That guide includes Azure CLI variables, read-only connector inspection, optional creation, CLI service-credential creation, SQL `ACCESS` grant and verification. Verify that the actual connector identity is the one that Synapse will recognise. Do not assign the connector identity the Synapse workspace's staging-storage role just because it logs in to SQL.

**Script form of this section:** `source scripts/env.dev.sh`, then `bash scripts/01_azure_setup.sh inspect`, `CONFIRM=yes bash scripts/01_azure_setup.sh create-connector` (only if absent), `CONFIRM=yes bash scripts/02_databricks_cli_setup.sh create-credential`, and run section B of the rendered `scripts/uc_admin_setup.sql.template` (`mkdir -p build && python3 scripts/render_sql.py scripts/uc_admin_setup.sql.template > build/uc_admin_setup.sql`).

**Also grant `ACCESS` to the administrator who will run the setup notebook in section 9** (their user name/e-mail), otherwise `action=preflight` fails with a permission error for that person even though the job principal is correct:

```sql
GRANT ACCESS ON SERVICE CREDENTIAL `<uc-service-credential-name>` TO `<admin-user-email>`;
```

Remove that grant after DEV setup if your policy requires it.

The Databricks UI alternative: Catalog Explorer > External data > Credentials > Create credential > Service credential; select the approved Azure managed identity/access connector. The exact options depend on workspace features and permissions. The credential owner grants `ACCESS` to the job principal. If UI/CLI options do not match your workspace, check current product documentation or contact the UC administrator rather than guessing values.

## 5. Prepare ADLS (storage and UC administrators)

1. Confirm the **staging** and **upstream manifest** containers exist; they must be separate as required by the configuration contract.
2. Assign staging-container `Storage Blob Data Contributor` to the **Synapse workspace managed identity** (Azure Portal > Storage account > Containers > Access control). Check hierarchical namespace ACL traverse/write permissions where ACLs are used.
3. Ensure the approved UC storage credential gives Databricks access to the staging container. Create or inspect an **external location** covering `staging.root`; grant the job principal `READ FILES, WRITE FILES` on that location.
4. Ensure a separate external location covers the upstream manifest path; grant the job principal `READ FILES` only. Do not give the job write permission to upstream completion signals.
5. Verify allowed paths and storage firewall/network routes from **both** Synapse and serverless Databricks.
6. Review `infra/adls_lifecycle_policy.json` and `infra/README.md` with the storage administrator. Apply cleanup only to approved bridge staging prefixes; never to Unity Catalog managed Delta tables or the upstream manifest.

**Exact commands.** Each is dry-run until you add `CONFIRM=yes`:

```bash
source scripts/env.dev.sh
bash scripts/01_azure_setup.sh inspect                                    # shows the Synapse workspace identity and any existing lifecycle policy
CONFIRM=yes bash scripts/01_azure_setup.sh create-container               # only if the staging container does not exist
CONFIRM=yes bash scripts/01_azure_setup.sh grant-synapse-storage-role     # step 2: az role assignment create ... "Storage Blob Data Contributor"
CONFIRM=yes bash scripts/01_azure_setup.sh lifecycle                      # step 6: refuses to replace an existing account policy
```

The lifecycle rule (from `infra/adls_lifecycle_policy.json`) deletes blobs under `<container>/$BRIDGE_STAGING_PREFIX/` three days after they were last modified; `BRIDGE_STAGING_PREFIX` must equal `staging.prefix` in `config/settings.json`. `az storage account management-policy create` **replaces the whole lifecycle policy of the storage account**, so the script stops if one exists. Merge the bridge rule into the existing policy by hand, or re-run with `REPLACE_EXISTING_POLICY=yes` if the storage administrator approves. Role assignments can take a few minutes to apply.

Steps 3 and 4 (external locations and their grants) are SQL: render `scripts/uc_admin_setup.sql.template` and run section C as the UC/storage administrator. It contains the exact `CREATE EXTERNAL LOCATION` (commented, only if none covers the container), `GRANT READ FILES, WRITE FILES` on staging, and `GRANT READ FILES` on the manifest location.

Useful Databricks SQL checks (run with appropriate UC privileges; substitute real names):

```sql
SHOW EXTERNAL LOCATIONS;
DESCRIBE EXTERNAL LOCATION `staging_location_name`;
SHOW GRANTS ON EXTERNAL LOCATION `staging_location_name`;
SHOW GRANTS ON EXTERNAL LOCATION `manifest_location_name`;
```

The runtime principal must have the required grants, not merely the human testing interactively.

## 6. Synapse dedicated-pool setup (Synapse administrator ONLY)

**Before you start**

- **Who must run this.** `CREATE USER ... FROM EXTERNAL PROVIDER` only works when you are connected **as the Microsoft Entra admin of the Synapse workspace (or a member of the Entra admin group)**. A plain SQL-admin login fails with *"Only connections established with Active Directory accounts can create other Active Directory users"*. Check or set it in Azure Portal > Synapse workspace > Settings > Microsoft Entra ID > Set admin. Also confirm the pool is **Online** (not paused) and that your client IP is allowed in the Synapse workspace firewall (Portal > Synapse workspace > Networking).
- **What to enter as the login name.** For a system-assigned access connector the Entra display name of its managed identity is **the access connector's resource name** (the value of `BRIDGE_ACCESS_CONNECTOR` in Appendix A1). Confirm in Azure Portal > Microsoft Entra ID > Enterprise applications > filter "Managed Identities" > search that name, and check that the **Object ID** equals the `principalId` printed by `az databricks access-connector show` in A1. If two identities share the display name, stop and ask the Entra administrator.

**Steps**

1. Open Synapse Studio > Develop > SQL script. Connect to the **dedicated pool database**, not the serverless `Built-in` endpoint or master database.
2. Execute `sql/synapse/03_review_credential_scope.sql` read-only. Review existing credentials/data sources, approval for the broad external-source/file-format rights, and the staging destination.
3. Check with `scripts/synapse_00_check_master_key.sql` (no row means no key). If the database has **no database master key**, the Synapse administrator must create one under the approved secret-handling process. Execute the following separately using a generated, securely escrowed password; **never save the password or completed statement in Git, a notebook or query history used by the job**:

   `CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<administrator-supplied-strong-secret>';`

   If a key already exists, do not replace it. Ensure its custody, backup and recovery follow DBA policy. The setup SQL fails with a clear message instead of creating a master key without a password.
4. Open `sql/synapse/01_export_setup.sql`. Set its four variables at the top: staging container, storage account, **actual managed-identity Synapse login display name**, and first source schema.
5. Have the SQL administrator run the script in the approved SQL session. The Databricks setup notebook can **render** it, but refuses to execute Synapse DDL with the nightly managed-identity service credential.
6. For additional schemas, either list them all in `source_schemas` when you render the SQL in section 9 (it adds one `GRANT SELECT` per schema), or have the administrator approve and apply `GRANT SELECT ON SCHEMA::[schema] TO [actual-login];` by hand. Inspect resulting permissions. Do not accidentally grant privileges to the Databricks job service principal when the login identity is the connector's MI.
7. Verify `bridge_stage`, `bridge_parquet`, `bridge_msi` and `bridge_meta` names match the inventory `staging` section. Perform a tiny, approved CETAS export and check the Parquet output in staging.

The SQL setup is not an atomic all-or-nothing deployment. If it fails midway, inspect objects and permissions before retrying. Do not delete an existing database credential or data source to force success.

## 7. Create/test the separate Unity Catalog JDBC connection (UC administrator)

**Detailed instructions:** [JDBC_CONNECTION_SETUP.md](JDBC_CONNECTION_SETUP.md). Follow that guide completely, including driver JAR in a Unity Catalog volume, `READ VOLUME`, the runtime options allowlist, credentials and a real fallback test.

**Script form:** `scripts/synapse_10_jdbc_reader_master.sql` and `scripts/synapse_11_jdbc_reader_pool.sql` (the two scripts below), then sections D and E of the rendered `scripts/uc_admin_setup.sql.template` (driver volume, `CREATE CONNECTION` SQL, `USE CONNECTION` grant); `JDBC_CONNECTION_SETUP.md` has the same SQL and the UI route.

**First create the read-only SQL user that the JDBC connection will log in as (Synapse administrator).** The JDBC connection supports static credentials or OAuth M2M, not the service credential. For SQL authentication, run these in Synapse Studio, in two separate scripts. Generate the password in your password manager; never paste it in Git or a ticket.

```sql
-- Script 1 (scripts/synapse_10_jdbc_reader_master.sql): connect to database  master  on the Synapse workspace
CREATE LOGIN bridge_jdbc_reader WITH PASSWORD = '<generated-strong-password>';

-- Script 2 (scripts/synapse_11_jdbc_reader_pool.sql): connect to the DEDICATED POOL database
CREATE USER bridge_jdbc_reader FOR LOGIN bridge_jdbc_reader;
GRANT SELECT ON SCHEMA::[dbo] TO bridge_jdbc_reader;   -- repeat for every source schema
```

(SQL authentication must be enabled on the Synapse workspace. If your organisation allows only Entra authentication, use an OAuth M2M service principal for the connection instead and have the Synapse administrator create it with `CREATE USER [<app-name>] FROM EXTERNAL PROVIDER` plus the same `GRANT SELECT`.)

**This step is not accomplished by creating a service credential.** In Catalog Explorer > External data > Connections > Create connection, select the supported **JDBC** connection type for the SQL Server/Synapse endpoint, configure its URL, SQL Server JDBC driver and an approved authentication method supported by the workspace. Connection identity/secret policy requires explicit approval. Use the dedicated SQL pool endpoint and database. Databricks documents JDBC connections and Spark `databricks.connection` usage in the current JDBC connection documentation.

Run (SQL editor, as authorised administrator):

```sql
SHOW CONNECTIONS;
DESCRIBE CONNECTION `bridge_synapse_jdbc`;
GRANT USE CONNECTION ON CONNECTION `bridge_synapse_jdbc` TO `<registered-job-principal>`;
SHOW GRANTS ON CONNECTION `bridge_synapse_jdbc`;
```

Set `synapse.uc_jdbc_connection` to the actual connection name. Verify a small `spark.read.format("jdbc").option("databricks.connection", "bridge_synapse_jdbc").option("query", "SELECT TOP 1 ... FROM [schema].[approved_view]").load()` in an approved **serverless** test session as the **job principal**. Replace the query with a permitted view/column; use the runtime's supported JDBC driver. The connection must allow the package's `queryTimeout`, `fetchsize` and `preferTimestampNTZ` query options in addition to query/partition options. Run the acceptance fallback scenario too. A successful service-credential token test does **not** prove the separate JDBC connection works.

## 8. Configure notifications and upstream completion

1. The upstream owner writes the full daily `row_counts.csv` in the exact configured column format; then writes the `_SUCCESS` JSON marker **last** in the same dated directory. See `UPSTREAM_MANIFEST_SPEC.md`. Never simulate completion with an empty marker.
2. **Create the receiver (Azure Portal, Logic Apps administrator).** Create a Logic App (Consumption) > Logic app designer > Blank > trigger **When an HTTP request is received**; paste the JSON schema from `infra/summary_webhook_schema.json` into *Request Body JSON Schema*; add the action **Send an email (V2)** (or Teams) that formats `result`, `business_date`, `failed_tables`, `failures` and `recovery_cutoff_local_time`; deduplicate on `notification_id` (the same value is sent as the `Idempotency-Key` header; a Repair run can resend). Save, then copy **HTTP POST URL** from the trigger. Field meanings: `DATA_DICTIONARY.md` section 6.
3. **Store the URL as a secret (secrets administrator).** The URL is a credential; never put it in Git, a ticket or shell history:

   ```bash
   source scripts/env.dev.sh
   CONFIRM=yes bash scripts/02_databricks_cli_setup.sh create-secret-scope   # skip if the scope exists; a Key Vault-backed scope is created in the UI instead
   bash scripts/02_databricks_cli_setup.sh put-webhook-secret                # needs an interactive terminal; paste the URL when prompted
   CONFIRM=yes bash scripts/02_databricks_cli_setup.sh grant-secret-read     # READ for the job principal
   ```

   Then set `notifications.summary_webhook.secret_scope` and `url_secret_key` in `config/settings.json` to the **names**.
4. **What validates it.** The acceptance job (section 10 step 6) checks only that the job principal can read the secret and that it holds an HTTPS URL; it sends nothing. Actual delivery is first proven by `90_finalize` in your DEV trial run, and a failed delivery fails that task.
5. Agree with the business, before the inventory review in section 9: `mandatory`, `allow_empty`, per-table schema, expected sizes, 07:00 normal publication deadline and 11:00 same-day recovery deadline. The timezone is `Australia/Sydney`.

## 9. Setup mainly in Databricks (developer and approved admins)

1. **Create the Git folder and your settings file.**
   - Workspace > your user folder > Create > **Git folder**; paste the repository HTTPS URL, choose the provider, create. (First time only: User Settings > Linked accounts > Git integration: add your GitHub username and a personal access token with `repo` scope.)
   - Open the folder and confirm you can see `databricks.yml`, `src/`, `tools/` and `config/`.
   - Create `config/settings.json`: open `config/settings.example.json` > the "⋮" menu > **Clone** (or Create > File and paste the content) and name it `settings.json`. Replace every placeholder with DEV-only identities, catalogs, secret **names** (not values) and paths. `settings.json` is git-ignored, so it stays only in this working copy.
   - Never commit tokens, passwords or webhook URLs. To commit a reviewed inventory later: Git folder name > **Git...** > tick the file > message > Commit & Push (use a feature branch, then open a pull request).
2. Open `src/setup/00_admin_setup.py` on an **administrator-controlled serverless notebook** with `mssql-python==1.15.0` and `azure-identity` installed. Install the libraries through the notebook's Environment panel: on the right edge click the **Environment** (⚙/"Environment") icon > Environment version **3** > Dependencies > add one line per package: `mssql-python==1.15.0` and `azure-identity>=1.20.0,<2` > **Apply**. (Alternative: run `%pip install mssql-python==1.15.0 "azure-identity>=1.20.0,<2"` in the first cell, then `dbutils.library.restartPython()` in the second.) Verify in a new cell: `import mssql_python, azure.identity; print("ok")`. Run the notebook's first cell once so the widgets appear at the top, then set `settings_file=config/settings.json`. Keep `apply_changes=false` for read-only checks.
3. `action=preflight`: confirm Synapse database/login/user are the expected dedicated-pool identity. Token acquisition and login are not sufficient by themselves to authorise CETAS.
4. `action=synapse_setup`: render SQL with actual `synapse_login_identity` and `source_schemas` (comma-separated: the first schema fills the script's variable and each further schema gets its own `GRANT SELECT` appended and reviewed with the rest); hand the SQL to the Synapse admin to review and execute as in section 6. This action **cannot apply DDL** through the runtime service credential.
5. `action=inventory`: choose `source_schemas=dbo,sales`, `target_catalog`, `target_schema`, and unused `inventory_file=config/inventory.dev.json`. Optional widgets: `exclude_objects=dbo.InternalTable,sales.ObsoleteView`; `profile_tables=true` for base-table size metadata (can require DMV permissions). Run dry-run, then approved apply with `confirmation=APPLY_DEV_SETUP`. **Views always need manual `estimated_bytes` review**. Never overwrite a reviewed inventory automatically. Inspect every mapping and commit the reviewed environment inventory.
6. `action=uc_setup`: set `inventory_file`, `job_principal` and optional `consumer_group`. Review the SQL with the UC admin. Confirm schema/table names, Delta properties, external-location grants and the JDBC connection grant; only then execute approved apply. If a statement fails, earlier DDL may already be committed. Inspect and resume carefully.
7. Note: interactive notebook permissions belong to the admin using it, **not** to the nightly job. Acceptance must run under the real job principal.

If you prefer local tools instead of the notebook, follow `FIRST_RUN.md` and run `tools/generate_inventory.py` / `tools/render_uc_setup.py`. The local inventory generator requires ODBC Driver 18, `pyodbc` and a permitted Synapse connection.

## 10. GitHub deployment and DEV acceptance (release engineer)

1. Configure two GitHub Environments named `dev` and `prod` (script form: `scripts/05_github_setup.sh`, see Appendix A6); PROD must require reviewers. Configure GitHub OIDC federation on the approved deploy Entra application for the exact repo/environment subjects.
   Follow [GITHUB_OIDC_SETUP.md](GITHUB_OIDC_SETUP.md) for every click and permission. In 2026 GitHub may use immutable OIDC subjects, so the Entra federation must match the actual emitted subject.
2. Set the environment variables listed at the top of `.github/workflows/bundle-deploy.yml` (full table in Appendix A6): `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, optionally `AZURE_SUBSCRIPTION_ID`, `DATABRICKS_JOB_IDENTITY`, `NOTIFICATION_EMAIL`, `OPERATIONS_GROUP`, `ROLLBACK_APPROVERS_GROUP`, and optionally `EXPORT_CONCURRENCY` (default 4). Keep `NIGHTLY_PAUSE_STATUS=PAUSED` and `MAINTENANCE_PAUSE_STATUS=PAUSED` until approval.
3. Set real DEV/PROD workspace hosts in `databricks.yml`; complete and review `config/inventory.dev.json` and `config/inventory.prod.json` independently. The deployment helper selects only the target environment's inventory.
3a. **Serverless compatibility smoke test (do this before deploying).** The nightly notebooks set Parquet calendar-rebase Spark settings at start-up (`src/notebooks/_bootstrap.py`), and Databricks documents only a short list of Spark settings as changeable on serverless. In a new serverless notebook attached to DEV, run:

```python
for k in ("spark.sql.parquet.datetimeRebaseModeInRead", "spark.sql.parquet.int96RebaseModeInRead",
          "spark.sql.parquet.datetimeRebaseModeInWrite", "spark.sql.parquet.int96RebaseModeInWrite"):
    try:
        spark.conf.set(k, "CORRECTED"); print("accepted:", k, spark.conf.get(k))
    except Exception as e:
        print("REJECTED:", k, str(e)[:150])
```

All four lines should say `accepted: ... CORRECTED`. If any says REJECTED, **stop and tell the package developers**. The nightly notebooks will still start (they print a warning and carry on), but the acceptance job's Spark-settings check (check 12) will fail, and without these settings a table holding pre-1582 dates would fail instead of loading. Do not go live until the check passes.

4. On a developer machine or CI runner with Python, **Java 17+** (the tests start a local Spark), and the Databricks CLI installed and signed in, run the following. **For manual CLI runs, set the four required bundle variables**; GitHub Actions normally supplies these through its `dev`/`prod` Environment variables. Never substitute the Azure deploy principal for the job identity.

```bash
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
python tools/prepare_deploy.py --environment dev
BUNDLE_VAR_job_identity="<registered-job-principal-app-id>"
BUNDLE_VAR_notification_email="<approved-alert-email>"
BUNDLE_VAR_operations_group="<operations-group>"
BUNDLE_VAR_rollback_approvers_group="<rollback-approvers-group>"
export BUNDLE_VAR_job_identity BUNDLE_VAR_notification_email
export BUNDLE_VAR_operations_group BUNDLE_VAR_rollback_approvers_group
databricks bundle validate --target dev
databricks bundle deploy --target dev
```

**Verify:** `prepare_deploy` reports the DEV host and inventory version, `bundle validate` has no errors, and the deployed jobs show the correct `run_as` service principal with schedules still PAUSED. On a laptop, authenticate the Databricks CLI to DEV first with your approved profile or unified authentication mechanism; this example deliberately does not create a token.

5. Prefer the reviewed GitHub Actions deployment workflow for promotion. Deployments do **not** apply Azure RBAC, Synapse SQL or UC setup scripts for you.
6. **Create the acceptance scratch schema and run the acceptance job.** (Section G of `scripts/uc_admin_setup.sql.template` renders this.) A UC administrator runs (replace the names; use a DEV catalog). The person who runs the job must be in `ROLLBACK_APPROVERS_GROUP` (section 2):

```sql
CREATE SCHEMA IF NOT EXISTS `<dev-catalog>`.`bridge_acceptance_scratch`;
GRANT USE SCHEMA, CREATE TABLE, CREATE FUNCTION ON SCHEMA `<dev-catalog>`.`bridge_acceptance_scratch` TO `<registered-job-principal>`;
```

Also create (or pick) an **existing test group** in the Databricks account to act as `grant_principal`. Then run, from the machine in 1a: `databricks bundle run acceptance -t dev --params scratch_schema=<dev-catalog>.bridge_acceptance_scratch,grant_principal=<test-group> --profile bridge-dev`, or in the Databricks UI: Workflows/Jobs > `[dev <you>] synapse-full-refresh-acceptance` > the ▾ next to **Run now** > **Run now with different parameters**. Leaving either parameter empty makes the job fail at once. The output must end with `ALL ACCEPTANCE CHECKS PASSED`; if not, fix what it reports and rerun. Keep schedules paused. The acceptance job proves: serverless Spark settings, Synapse command SQL as the job identity, a one-row CETAS, staging read/write, the UC JDBC connection (including a partitioned read), Delta history/idempotency, the governance preflight, manifest/staging path access, and that the webhook secret is readable. It does **not** send a notification: confirm delivery on the first trial run, and confirm a *forced* JDBC fallback with step 6b. Then test 2–3 mappings with a real upstream marker; then the full DEV inventory.
6a. **Time rules for the DEV trial.** The job only loads *today's Sydney date*. A run with no parameters works only before the 07:00 publication cutoff; a run with `business_date=<today in Sydney>` works only until `recovery_cutoff_local_time` (11:00). To test in the afternoon or evening, set `execution.recovery_cutoff_local_time` (for example `"23:00"`) **in `config/inventory.dev.json` only** (never PROD), re-run `python tools/prepare_deploy.py --environment dev` and redeploy. Before each trial run the upstream owner (or you, in DEV) must have written, in the dated folder defined by `manifest.path_template`, the `row_counts.csv` and then `_SUCCESS` for today's Sydney date. Build them from `config/row_counts.example.csv` and `config/success_marker.example.json`: use the real table names, the **true current row counts** (`SELECT COUNT_BIG(*) FROM ...`) and `upstream_sequence` = `yyyymmdd00` (e.g. `2026102300`). Run the nightly job from Jobs > **Run now with different parameters** with `business_date=<today>` and `only_mappings=<2-3 mapping ids>`; mapping ids look like `dbo__Customer`. Running the same date a second time is skipped by the idempotency guard (see `UPSTREAM_MANIFEST_SPEC.md` section 7 for how to republish).

6b. **Forcing one table through the JDBC fallback (DEV only).** The package falls back whenever CETAS fails with a SQL error that is not a schema, access, data or capacity error (`classify_export_error` in `src/bridge/synapse.py`). One reversible way for a DEV test table (derived from the code; not yet exercised against a live pool, so confirm the result in `table_log`): the Synapse administrator runs `REVOKE CREATE TABLE FROM [<connector-login>];` in the dedicated pool, you run the nightly job for **one** mapping (`only_mappings=<id>`) and watch its `table_log` rows go `FALLBACK_REQUIRED` > `VALIDATED` > `PUBLISHED` with `method = 'JDBC'`; then the administrator runs `GRANT CREATE TABLE TO [<connector-login>];` and you confirm the next run uses CETAS again. Record the SQL error number printed in `table_log.error_code` (the package expects you to review it; see `additional_access_error_codes` in `settings.example.json`). If the fallback does not trigger, send the `table_log.detail` text to the package developers rather than editing code.

7. Inject an eligible failure and prove it affects only that table. Confirm the final notification and same-day repair workflow. Inspect `table_log`, `run_log`, and `plan`, then follow `RUNBOOK.md` for operator repair.

## 10a. Test on your own feature branch first (phase B, steps 22-26)

Develop and test in your own Databricks Git folder on a feature branch, running the **whole package as your own user**, before opening the pull request. Do it against your **own schemas**, not the shared DEV tables:

- **Why separate schemas.** Every target table remembers in its Delta log the newest night it accepted (the idempotent-write guard). A test run on the shared DEV table can make the later DEV run skip or fail. `tools/make_feature_inventory.py` (step 22) copies the reviewed DEV inventory and changes only where things are written: target schemas and the control schema become `feature_<you>_*`, and the staging folder becomes `bridge-stage-feature-<you>`. What is exported does not change.
- **Your rights.** Your user needs `CREATE SCHEMA` on the catalog (so it owns the personal schemas), `ACCESS` on the service credential (it is the same managed identity into Synapse, so no new Synapse login), `USE CONNECTION`, the staging and manifest external-location grants, and read on the webhook secret scope. For `uc_setup` (step 23) use your own e-mail as `job_principal`.
- **The bundle.** Set the same workspace host under `targets.feature` in `databricks.yml` as under `dev`. Step 24 runs `prepare_deploy.py --environment feature` and deploys with `-t feature`: development mode (jobs get a `[dev you]` prefix, schedules paused) and `run_as` your own user. Deploy with `BUNDLE_VAR_job_identity` set to your e-mail so the maintenance and rollback clusters are yours; step 24 does that. The GitHub workflows never use this target. Confirm with `databricks bundle validate -t feature` that your CLI version accepts `run_as: user_name` in the bundle.
- **Notifications.** Pass a TEST secret with `--webhook-secret-scope/--webhook-secret-key` to step 22, or you will notify the real DEV receiver.
- **Do not run a feature test and the DEV job at the same time.** They share the Synapse staging objects and the manifest folder for the same business date.
- **Time rules still apply.** Section 10 step 6a (today's Sydney date, 07:00 and 11:00 cutoffs, writing a test manifest) applies to feature runs too.
- **Clean up (step 26).** Drop the personal schemas through Unity Catalog with the generated `build/feature_reset.sql` (it refuses any schema not named `feature_<you>_*`). **Never delete a managed table's files in storage**: Unity Catalog would still list a broken table. A dropped managed table can be restored with `UNDROP` for a limited time, which would also restore its write guard, so recreate the tables after the drop instead (step 23). Delete `bridge-stage-feature-<you>` in storage by hand; the DEV lifecycle rule does not cover it.
- **Then** open the pull request. After merge the GitHub runner deploys DEV and you run the acceptance job and trial there again (steps 27-28), from clean DEV tables.

## 11. PROD promotion and go-live sign-off

1. Repeat identity, storage, Synapse, credential, connection, grant, secret and UC setup in PROD under PROD administrators. Never reuse DEV credentials or ADLS prefixes.
2. Record the **exact DEV-tested Git SHA**, acceptance Databricks Job run ID, successful CETAS and forced-JDBC-fallback evidence, test result and the approved change ticket. A push to `main` deploys DEV only and never starts PROD. To promote the exact tested commit, check `main` still points at the same SHA, then open GitHub Actions > `ci-cd` > Run workflow on `main`; choose `prod` and fill `dev_acceptance_evidence` with the approved ticket/run ID. If `main` has moved, test the new commit in DEV first. The protected PROD Environment reviewer must verify evidence before approving. Keep PROD schedules paused. Run PROD acceptance and an approved small trial.
3. Sign off the checklist below; unpause schedules only after approval. **To unpause:** set `NIGHTLY_PAUSE_STATUS=UNPAUSED` (and, if approved, `MAINTENANCE_PAUSE_STATUS=UNPAUSED`) on the `prod` GitHub Environment (for example `gh variable set NIGHTLY_PAUSE_STATUS --env prod --repo <owner>/<repo> --body UNPAUSED`, or GitHub > Settings > Environments > prod > Environment variables), then re-run the `ci-cd` workflow for `prod` on the same tested commit. Do **not** unpause only in the Databricks UI: the next deploy would pause it again. Unless predictive optimization is enabled, also set the maintenance job's `vacuum` parameter to `true` at that point (`RUNBOOK.md`). The nightly job is scheduled at 01:30 `Australia/Sydney` in the bundle; change this deliberately if your upstream completion notification comes later. Cutoffs are configured in the inventory and must be checked separately.

## Go-live acceptance checklist

- [ ] Every placeholder resolved; no plaintext secret committed
- [ ] Exact DEV and PROD principal identities verified independently
- [ ] Synapse master key provisioned/verified by administrator
- [ ] Source SELECT and CETAS permissions tested as actual login
- [ ] Staging and manifest external-location grants tested as job principal
- [ ] UC service credential token and dedicated-pool connection tested
- [ ] Separate UC JDBC connection tested on serverless
- [ ] JDBC driver JAR accessible in UC volume; connection option allowlist tested
- [ ] GitHub OIDC environment subject and deploy-principal Run-as permissions verified
- [ ] Target/control tables and correct reader/writer grants verified
- [ ] Upstream CSV and final `_SUCCESS` contract tested
- [ ] Complete automated test suite passed in CI
- [ ] DEV acceptance, 2–3-table trial and full inventory passed
- [ ] CETAS failure → JDBC fallback and JDBC failure → old Delta data retained tested
- [ ] Per-table independence, one final summary and webhook delivery tested
- [ ] Repair before 11:00 and cutoff refusal tested
- [ ] Protected same-commit PROD deployment validated; operator and owners signed off

## Troubleshooting entry points

| Symptom | First check |
|---|---|
| Notebook cannot find `tools/` | Open it from the **Git folder**, not an isolated workspace file |
| Service credential token denied | Credential `ACCESS` grant and actual notebook/job principal |
| Token works, Synapse login fails | `CREATE USER FROM EXTERNAL PROVIDER` identity/name, dedicated-pool endpoint, Entra identity and firewall |
| Synapse setup throws missing master key | DBA creates/verifies key, then reruns approved setup |
| CETAS permissions denied | SQL source SELECT, CETAS DDL grants, credentials/data-source review, Synapse workspace MI storage RBAC |
| Fallback fails | Distinct JDBC connection, `USE CONNECTION`, connection auth/driver, serverless networking and query support |
| Staging/manifest not readable | UC external location grants, storage credentials and network routing |
| UC setup partly applied | Check statements and existing objects; SQL setup is not one transaction |
| No nightly plan | Upstream manifest `_SUCCESS`, row counts, business date and inventory mapping IDs |
| Repair rejected | Consult `RUNBOOK.md` cutoff and source sequence/business-date gates |
| `pytest` errors before running any test | Java 17+ is missing (`java -version`); PySpark needs it |
| Some tests fail only on your laptop | Run `python -m pytest tests -q`; the suite pins its own time zone, so a failure is a real one: send the output to the developers |
| **Run now** is disabled or "permission denied" on a job | You are not in `OPERATIONS_GROUP` (nightly) or `ROLLBACK_APPROVERS_GROUP` (acceptance); see section 2 |
| Acceptance fails "rejects Spark conf" | Section 10 step 3a: serverless does not accept a Parquet setting; developers must change the package |
| A script only prints what it would do | That is the dry run; add `CONFIRM=yes` to the command to apply it |
| `render_sql.py` says a value is not set or contains a placeholder | Edit `scripts/env.dev.sh` and `source` it again |

For detailed implementation flow and each file's purpose, read `PACKAGE_GUIDE.md` and `CODE_STRUCTURE.md`. For operational recovery, read `RUNBOOK.md`. For exact service credential CLI/SQL commands, read `UNITY_CATALOG_SERVICE_CREDENTIAL_SETUP.md`.

## Appendix A. Copyable administrator setup commands (DEV first)

**Two Azure subscriptions.** `BRIDGE_SUBSCRIPTION_ID` is the subscription of the Databricks access connector. `BRIDGE_DATA_SUBSCRIPTION_ID` (set in `scripts/env.*.sh`) is the subscription of the Synapse workspace and the staging storage account. If everything is in one subscription, give both the same GUID. The scripts pass `--subscription` on every `az` call; the manual commands below that touch Synapse or storage must do the same with `BRIDGE_DATA_SUBSCRIPTION_ID`.

These commands supplement sections 3–7 without changing their order. The same commands are available as scripts in `scripts/` (dry-run by default). Run Azure commands in an approved administrator shell with Azure CLI installed and signed in (`az login`). Run Databricks CLI commands only after configuring an approved authentication profile (`databricks auth profiles`). Use a **separate set of values for PROD**. Every placeholder below must be replaced by a value recorded in section 1. Do not copy actual passwords into shell history or Git.

### A1. Inspect the access connector before creating anything (Azure identity administrator; MANUAL)

```bash
BRIDGE_SUBSCRIPTION_ID="<databricks-subscription-guid>"   # subscription of the access connector; Synapse/storage use BRIDGE_DATA_SUBSCRIPTION_ID
BRIDGE_RESOURCE_GROUP="<resource-group>"
BRIDGE_AZURE_REGION="<region>"
BRIDGE_ACCESS_CONNECTOR="<access-connector-name>"
BRIDGE_SERVICE_CREDENTIAL="<uc-service-credential-name>"
BRIDGE_DATABRICKS_PROFILE="<approved-databricks-cli-profile>"
az account set --subscription "$BRIDGE_SUBSCRIPTION_ID"
az account show --query '{subscription:id,tenant:tenantId,name:name}' -o table
az databricks access-connector show --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" --query '{id:id,principalId:identity.principalId}' -o json
```

If the connector is absent, stop for administrator approval. Only the authorised administrator may create the approved *system-assigned* connector:

```bash
az databricks access-connector create --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" --location "$BRIDGE_AZURE_REGION" --identity-type SystemAssigned
```

Record the exact connector resource ID and managed identity principal/object ID. User-assigned managed identities require a different approved configuration; consult the credential guide before proceeding.

### A2. Create or inspect the service credential (Unity Catalog administrator; MANUAL)

```bash
BRIDGE_CONNECTOR_ID=$(az databricks access-connector show --subscription "$BRIDGE_SUBSCRIPTION_ID" --resource-group "$BRIDGE_RESOURCE_GROUP" --name "$BRIDGE_ACCESS_CONNECTOR" --query id -o tsv)
databricks credentials list-credentials --profile "$BRIDGE_DATABRICKS_PROFILE"
databricks credentials create-credential --help
```

If the named credential does not exist and the administrator approves creation, use the CLI form supported by your installed version. The package's supported example is:

```bash
BRIDGE_CREDENTIAL_REQUEST=$(printf '{"name":"%s","purpose":"SERVICE","azure_managed_identity":{"access_connector_id":"%s"}}' "$BRIDGE_SERVICE_CREDENTIAL" "$BRIDGE_CONNECTOR_ID")
databricks credentials create-credential "$BRIDGE_SERVICE_CREDENTIAL" --purpose SERVICE --json "$BRIDGE_CREDENTIAL_REQUEST" --profile "$BRIDGE_DATABRICKS_PROFILE"
databricks credentials get-credential "$BRIDGE_SERVICE_CREDENTIAL" --profile "$BRIDGE_DATABRICKS_PROFILE"
```

Do not overwrite an existing credential. For the UI route use Databricks Catalog Explorer > External data > Credentials > Create credential > Service credential. Select the approved connector and confirm its identity. The UC administrator then uses a Databricks SQL editor:

```sql
SHOW SERVICE CREDENTIALS;
DESCRIBE SERVICE CREDENTIAL `<uc-service-credential-name>`;
GRANT ACCESS ON SERVICE CREDENTIAL `<uc-service-credential-name>` TO `<registered-job-principal>`;
SHOW GRANTS ON SERVICE CREDENTIAL `<uc-service-credential-name>`;
```

**Verify:** the service credential points to the approved connector and the *nightly run-as principal* has `ACCESS`. The service credential only authorises the Synapse command SQL identity; it is not the staging storage credential and not the JDBC fallback connection.

### A3. Storage and Synapse administration (MANUAL + SCRIPT)

In Azure Portal > Storage account > Containers > staging container > Access control (IAM), assign `Storage Blob Data Contributor` to the **Synapse workspace managed identity**, subject to approval. Confirm ADLS ACLs when ACL-based access is enforced. In Databricks Catalog Explorer > External data, inspect or create approved **storage** credentials and external locations covering (a) the staging root and (b) the separate upstream manifest root. Grant staging `READ FILES` and `WRITE FILES`, and upstream `READ FILES`, to the nightly principal. Verify the grants with `SHOW GRANTS ON EXTERNAL LOCATION` and actual read/write probes. The Azure resource creator and UC administrator may be different people.

The Synapse administrator opens Synapse Studio > Develop > SQL script, selects the **dedicated pool database**, then runs `sql/synapse/03_review_credential_scope.sql`. The DBA checks whether a database master key exists. If absent, the DBA provisions it using a generated, securely escrowed password in an approved administrator session; never run a password-bearing statement from the nightly notebook. The DBA then changes exactly the four values at the beginning of `sql/synapse/01_export_setup.sql` and executes that script. The SQL creates/reuses `bridge_meta`, `bridge_msi`, `bridge_stage`, and `bridge_parquet`, and grants CETAS permissions to the **connector identity's actual Synapse database user**. Additional source schemas need separately approved `GRANT SELECT` statements. Inspect the resulting objects and conduct a tiny real CETAS export before continuing.

**Verify:** the external data source points to the correct DEV staging container, there is no unintended broad source access, and a sample CETAS writes Parquet that Databricks can read. Synapse setup SQL is *not* executed by the Databricks setup notebook.

### A4. Configure UC JDBC fallback (UC/JDBC administrator; MANUAL)

In Databricks SQL, create an approved UC volume in an existing catalog/schema and grant `READ VOLUME` to the job principal. Upload the Microsoft SQL Server JDBC driver JAR to that volume through Catalog Explorer; record its exact `/Volumes/.../*.jar` path. In Catalog Explorer > External data > Connections > Create connection, choose JDBC, point the URL to `jdbc:sqlserver://<synapse-workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false`, enter approved connection-specific authentication, and set the Java dependency to the JAR volume path. Include `dbtable,query,partitionColumn,lowerBound,upperBound,numPartitions,queryTimeout,fetchsize,preferTimestampNTZ` in the external options allowlist if accepted by your workspace. If any option is rejected, stop and validate compatibility rather than removing it without code review.

```sql
SHOW CONNECTIONS;
DESCRIBE CONNECTION `<jdbc-connection-name>`;
GRANT USE CONNECTION ON CONNECTION `<jdbc-connection-name>` TO `<registered-job-principal>`;
SHOW GRANTS ON CONNECTION `<jdbc-connection-name>`;
```

**Verify:** a serverless task running as the job principal can query a small approved Synapse view using `spark.read.format("jdbc").option("databricks.connection", "<jdbc-connection-name>").option("query", "SELECT TOP 1 * FROM [dbo].[ApprovedSmallView]").load()`. Also perform the packaged partitioned fallback acceptance test. The UC service credential does *not* create or configure this JDBC connection. See `JDBC_CONNECTION_SETUP.md` only for alternate auth choices and error diagnosis.

### A5. Databricks setup actions (administrator/developer; SCRIPT)

In a Databricks Git folder, keep the entire repository layout. Copy `config/settings.example.json` to `config/settings.json` **only in the approved Git-folder working copy**; update all environment values. Open `src/setup/00_admin_setup.py` from that folder. Install `mssql-python==1.15.0` and `azure-identity` on the administrator's interactive serverless notebook environment. Do not attach the notebook to a production schedule. The notebook discovers `tools/databricks_admin_setup.py` relative to the current Git-folder working directory; if it reports it cannot find the helper, inspect `Path.cwd()` and open the notebook from the repository rather than copying the notebook alone.

| Run | Widgets (in addition to `settings_file=config/settings.json`) | Expected result |
|---|---|---|
| Preflight | `action=preflight`, `apply_changes=false` | Exact Synapse dedicated DB/login/user printed; stop if unexpected |
| Synapse SQL render | `action=synapse_setup`, `synapse_login_identity=<actual-connector-login>`, `source_schemas=dbo`, `apply_changes=false` | Reviewed SQL printed; DBA executes separately |
| Inventory dry run | `action=inventory`, `source_schemas=dbo,sales`, `target_catalog=<catalog>`, `target_schema=<schema>`, `inventory_file=config/inventory.dev.json`, `apply_changes=false` | Mapping count, no file saved |
| Inventory approved save | Same inputs, `apply_changes=true`, `confirmation=APPLY_DEV_SETUP` | New inventory file saved; never overwrites an existing inventory |
| UC SQL dry run | `action=uc_setup`, `inventory_file=config/inventory.dev.json`, `job_principal=<registered-job-principal>`, `apply_changes=false` | Generated table/grant statements printed |
| UC approved apply | Same inputs, `apply_changes=true`, `confirmation=APPLY_DEV_SETUP` | Statements executed one by one; inspect partial state on failure |

Review every source-to-target mapping, especially views, all columns, unsupported types, `mandatory`, `allow_empty`, `estimated_bytes`, recovery cutoffs and the separate JDBC connection name. Inventory generation cannot guess business criticality or reliable view sizes. After review, commit `config/inventory.dev.json` and later a separately reviewed `config/inventory.prod.json`. Do not commit passwords, tokens, webhook URLs or temporary acceptance data.

### A6. GitHub Environments and promotion (release engineer; MANUAL + AUTO)

Script form: `bash scripts/05_github_setup.sh environment | variables | federated-credential` (PROD needs `PROD_REVIEWER_USER_IDS`; the federated credential needs the exact `OIDC_SUBJECT` your repository emits, which the script never guesses).

In GitHub > repository Settings > Environments, create `dev` and `prod`. Require reviewers for `prod`. In Entra > App registrations > deploy application > Federated credentials, configure the GitHub OIDC issuer/audience and the subject matching the exact repository/environment. Record the resulting deploy identity and grant it approved Databricks deployment and job `run_as` rights. Configure the following environment variables separately in `dev` and `prod`:

| GitHub Environment variable | Required value |
|---|---|
| `AZURE_CLIENT_ID`, `AZURE_TENANT_ID` | Approved deploy application and tenant IDs |
| `AZURE_SUBSCRIPTION_ID` | Subscription if applicable |
| `DATABRICKS_JOB_IDENTITY` | Nightly Databricks service principal ID |
| `NOTIFICATION_EMAIL` | Failure alert recipient |
| `OPERATIONS_GROUP` | Approved operators |
| `ROLLBACK_APPROVERS_GROUP` | Restricted rollback group |
| `EXPORT_CONCURRENCY` | Approved Synapse capacity limit (start small) |
| `NIGHTLY_PAUSE_STATUS`, `MAINTENANCE_PAUSE_STATUS` | `PAUSED` until go-live |

Edit both target workspace hosts in `databricks.yml`. PR runs execute CI tests. Merging to `main` triggers **DEV only**. Check the workflow's selected inventory and Databricks job identity, then run acceptance and real DEV trials. Manual PROD promotion requires choosing `prod` in the workflow-dispatch interface and entering `dev_acceptance_evidence`; an authorised PROD reviewer confirms the evidence, protected `main` SHA and separate PROD values. PROD acceptance comes **before** unpausing any schedule.

### A7. Daily run and operator handoff (AUTO + operator)

The *upstream team* finishes the static Synapse source refresh, writes the complete dated `row_counts.csv` and writes `_SUCCESS` last. A Databricks Job at 01:30 `Australia/Sydney` (or another approved schedule) executes `00_plan.py` → `10_extract_validate_batch.py` → `20_serverless_jdbc_fallback.py` → `30_publish_batch.py` → `90_finalize.py` using the bundle's dependencies. There is no requirement to run these notebooks one by one interactively. `90_finalize.py` writes the final run status and invokes the configured summary webhook; Databricks job-level failure email is a separate alert channel and may generate an additional message. Operators inspect control tables and the final notification. A failed table retains its prior committed target data; perform a permitted same-day repair only before the 11:00 Sydney recovery cutoff, following the operator procedure in `RUNBOOK.md`. Do not manually write to control logs or fake a completed upstream marker.
