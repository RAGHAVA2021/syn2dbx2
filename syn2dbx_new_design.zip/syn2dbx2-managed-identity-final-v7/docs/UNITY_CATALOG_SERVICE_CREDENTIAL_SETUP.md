# Unity Catalog service credential — full script-first setup

**Target:** Azure Databricks 4A, using the access-connector managed identity
to authenticate to the **Synapse dedicated SQL pool**. Run for DEV, validate,
then repeat using independently approved PROD values.

This is an administrator-run procedure. It is **not** part of the nightly job.
Commands below are examples to execute one section at a time. Do not run the
whole document as an unattended script. Reuse existing approved Azure/UC
resources; creation commands are only for resources that do not exist.

## 1. Roles and required tools

| Operator | Required permissions |
|---|---|
| Azure administrator | Contributor/Owner on access connector resource group; permission to manage approved Azure RBAC |
| Databricks credential creator | UC metastore admin, or allowed user with CREATE SERVICE CREDENTIAL and Azure Contributor on access connector; an automation service principal must be account admin for managed-identity credential creation |
| Databricks credential owner/metastore admin | May grant ACCESS on credential |
| Synapse administrator | Can create Entra database user and grant limited SQL privileges |
| Databricks job principal | Workspace membership, ACCESS on service credential, required UC schema/location grants |

Install Azure CLI (including `databricks` extension) and recent Databricks
CLI. Execute:

```bash
az version
databricks version
az login
az account show --output table
databricks auth login --host https://<dev-workspace>.azuredatabricks.net --profile bridge-dev
databricks auth describe --profile bridge-dev
```

Use separate Databricks profiles for DEV and PROD. Credentials and access
connectors are *not* secrets to paste into the repository, but access tokens
and webhook URLs are.

## 2. Set variables once per environment

In a fresh shell, edit these six values before running any Azure command:

```bash
BRIDGE_SUBSCRIPTION_ID="<subscription-guid>"
BRIDGE_RESOURCE_GROUP="<approved-resource-group>"
BRIDGE_AZURE_REGION="<azure-region>"
BRIDGE_ACCESS_CONNECTOR="<connector-name>"
BRIDGE_SERVICE_CREDENTIAL="<uc-service-credential-name>"
BRIDGE_DATABRICKS_PROFILE="bridge-dev"
```

Select and inspect the intended subscription:

```bash
az account set --subscription "$BRIDGE_SUBSCRIPTION_ID"
az account show --query "{subscription:id,tenant:tenantId,name:name}" --output table
az group show --name "$BRIDGE_RESOURCE_GROUP" --query "{name:name,location:location}" --output table
```

The access connector should be in an approved region compatible with the
workspace. Do not reuse a PROD managed identity for DEV merely because it
already exists.

## 3. Inspect or create the Azure access connector

**Read-only check:**

```bash
az databricks access-connector show \
  --resource-group "$BRIDGE_RESOURCE_GROUP" \
  --name "$BRIDGE_ACCESS_CONNECTOR" \
  --query "{id:id,identity:identity,location:location}" --output json
```

If the resource does not exist, the Azure administrator must approve creation.
Then run this **once** for a system-assigned managed identity:

```bash
az databricks access-connector create \
  --resource-group "$BRIDGE_RESOURCE_GROUP" \
  --name "$BRIDGE_ACCESS_CONNECTOR" \
  --location "$BRIDGE_AZURE_REGION" \
  --identity-type SystemAssigned
```

Verify and record the actual connector resource ID and Entra object ID:

```bash
BRIDGE_CONNECTOR_ID=$(az databricks access-connector show \
  --resource-group "$BRIDGE_RESOURCE_GROUP" \
  --name "$BRIDGE_ACCESS_CONNECTOR" --query id -o tsv)
BRIDGE_MI_OBJECT_ID=$(az databricks access-connector show \
  --resource-group "$BRIDGE_RESOURCE_GROUP" \
  --name "$BRIDGE_ACCESS_CONNECTOR" --query identity.principalId -o tsv)
test -n "$BRIDGE_CONNECTOR_ID"
test -n "$BRIDGE_MI_OBJECT_ID"
az databricks access-connector show \
  --resource-group "$BRIDGE_RESOURCE_GROUP" \
  --name "$BRIDGE_ACCESS_CONNECTOR" \
  --query "{resourceId:id,principalId:identity.principalId}" -o json
```

For **user-assigned** identity, follow the approved Azure procedure, attach
its resource ID to the connector and include `managed_identity_id` in the
UC credential request below. Do not substitute its *object ID* for the
user-assigned identity's *Azure resource ID*.

**Do not grant Storage Blob Data Contributor to this identity just because it
authenticates to Synapse SQL.** Storage permissions for Synapse CETAS belong
to the **Synapse workspace** managed identity; Databricks staging access uses
the UC external-location storage credential.

## 4. Create the UC service credential using Databricks CLI

First inspect existing credentials:

```bash
databricks credentials list-credentials --profile "$BRIDGE_DATABRICKS_PROFILE"
```

If the proposed name already exists, inspect its connector before reusing it.
Never delete or overwrite an existing credential to solve a name conflict.

For a **system-assigned** identity, run as an authorised UC administrator:

```bash
BRIDGE_CREDENTIAL_REQUEST=$(printf \
  '{"name":"%s","purpose":"SERVICE","azure_managed_identity":{"access_connector_id":"%s"}}' \
  "$BRIDGE_SERVICE_CREDENTIAL" "$BRIDGE_CONNECTOR_ID")
databricks credentials create-credential "$BRIDGE_SERVICE_CREDENTIAL" \
  --purpose SERVICE \
  --json "$BRIDGE_CREDENTIAL_REQUEST" \
  --profile "$BRIDGE_DATABRICKS_PROFILE"
```

For a user-assigned identity the JSON object additionally requires
`"managed_identity_id":"<user-assigned-identity-resource-id>"`.
Use `databricks credentials create-credential --help` to confirm the CLI
version's syntax before making a production change.

Read-only verification:

```bash
databricks credentials get-credential "$BRIDGE_SERVICE_CREDENTIAL" \
  --profile "$BRIDGE_DATABRICKS_PROFILE"
```

The name must equal `synapse.auth.credential_name` in the selected inventory.
A service credential is a UC object; it is not an Entra application.

## 5. Grant job principal ACCESS using Databricks SQL

As credential owner/metastore admin, execute in a Databricks SQL editor or
SQL notebook, replacing the identifiers:

```sql
SHOW SERVICE CREDENTIALS;
DESCRIBE SERVICE CREDENTIAL `<uc-service-credential-name>`;
SHOW GRANTS ON SERVICE CREDENTIAL `<uc-service-credential-name>`;

GRANT ACCESS ON SERVICE CREDENTIAL `<uc-service-credential-name>`
TO `<databricks-job-service-principal-application-id>`;

SHOW GRANTS ON SERVICE CREDENTIAL `<uc-service-credential-name>`;
```

Resolve the exact account-level principal representation from your Databricks
identity administration before granting. If the application ID is not accepted
as the SQL principal identifier, use its registered Databricks principal name
as returned by administration. Do not grant ACCESS to `account users` or a
broad group merely to bypass a principal-name error.

This `ACCESS` grant is **not** a Synapse SQL grant, and it is **not** permission
to create unrelated UC connections. `CREATE CONNECTION` is separate.

## 6. Create the Synapse database user and grant CETAS permissions

**Prerequisite:** An approved Synapse DBA must verify the dedicated-pool
database master key exists. If absent, they must create it separately using
`CREATE MASTER KEY ENCRYPTION BY PASSWORD` and their organisation's secret
handling procedure. The package SQL deliberately refuses to create one without
that prerequisite. Never commit the key password. Run this section through an
approved Synapse **administrator connection**, not through the nightly service
credential used by the Databricks setup notebook.

The managed identity behind `BRIDGE_CONNECTOR_ID` must be able to log in to
Synapse's **dedicated pool**. Have the Synapse administrator resolve its Entra
display name and object ID, verify the intended identity, and connect to the
dedicated-pool database.

First execute `sql/synapse/03_review_credential_scope.sql` to review the
scope of powerful CETAS permissions. Obtain approval from the data owner.
Then open `sql/synapse/01_export_setup.sql`, set **four variables at the top**:

```sql
DECLARE @StagingContainer sysname = N'<staging-container>';
DECLARE @StorageAccount sysname = N'<storage-account>';
DECLARE @SynapseLoginIdentity sysname = N'<managed-identity-Entra-display-name>';
DECLARE @SourceSchema sysname = N'dbo';
```

Those lines show what to **replace inside the existing SQL**; they are not a
separate SQL script to execute first. The script creates/verifies export
objects and grants the login. Repeat SELECT grants for every source schema
approved for the package. Do not enter the Databricks *job principal* here
unless it really is the identity authenticated to Synapse.

Verify from Synapse SQL:

```sql
SELECT name, type_desc FROM sys.database_principals
WHERE name = '<managed-identity-Entra-display-name>';
SELECT name, location FROM sys.external_data_sources
WHERE name = 'bridge_stage';
SELECT name, format_type FROM sys.external_file_formats
WHERE name = 'bridge_parquet';
```

**Approval gate:** `ALTER ANY EXTERNAL DATA SOURCE` can grant access to all
database-scoped credentials in the pool. On a shared pool, stop if the
credential-scope review has not been explicitly accepted.

## 7. Configure the package

In `config/settings.json` (and generated DEV/PROD inventory), use:

```json
"auth": {
  "mode": "service_credential",
  "credential_name": "<uc-service-credential-name>"
}
```

Do **not** add `client_secret`, tenant or client secret keys for this mode.
The package's nightly `run_as` remains the *Databricks job principal*.
The fallback also needs its **separate UC JDBC connection**, configured in
`synapse.uc_jdbc_connection`; service-credential creation does not create
that connection automatically.

## 8. Verify token and login before the nightly job

Run this in an approved DEV **serverless Python notebook/job** as the intended
job principal, not only as a workspace administrator:

```python
credential_name = "<uc-service-credential-name>"
provider = dbutils.credentials.getServiceCredentialsProvider(credential_name)
token = provider.get_token("https://database.windows.net/.default")
assert token.token
print("Token acquired (token value intentionally not printed)")
```

Then use the package's **acceptance job** to make a small command SQL
connection to the dedicated pool. A valid token alone does not prove database
login, permission to CREATE EXTERNAL TABLE, serverless network access, or
successful CETAS. Test each of these before publishing anything.

The UC JDBC fallback connection must also be tested independently. Verify
`SHOW CONNECTIONS` and the job principal's connection privileges; then run
the package's deliberate fallback acceptance case.

## 9. Troubleshooting

| Symptom | Likely cause | Action |
|---|---|---|
| Cannot create UC credential | Missing UC privilege or Azure Contributor on connector | Recheck operator's roles; for service-principal creator, account admin requirement |
| Credential name already exists | Reused name | Inspect it; do not overwrite |
| `getServiceCredentialsProvider` denied | Job principal missing ACCESS | Verify exact job run-as principal and SHOW GRANTS |
| Token obtained but Synapse login rejected | Managed identity not registered/recognised in pool | Check Entra object and Synapse CREATE USER with admin |
| Synapse SELECT denied | Missing schema grant | Approve and grant SELECT only on required schemas |
| CETAS DDL denied | Missing database-level CETAS rights | Review permission scope before granting |
| CETAS file write fails | Synapse workspace identity lacks storage access or firewall blocks it | Check storage RBAC/network; this is not the UC service credential |
| Databricks cannot read stage | UC external location privileges / network | Check READ FILES and storage credentials |
| JDBC fallback fails | UC JDBC connection configured/authenticated separately | Diagnose and test connection, do not assume service credential covers it |

## 10. PROD change control

- Use independently reviewed PROD variables and the PROD Databricks CLI profile.
- Prefer a separate PROD access connector and service credential.
- Verify UC credential workspace isolation where appropriate.
- Record connector resource ID, managed identity object ID, UC credential name,
  Synapse database user, approved grants and acceptance result.
- Never run create/delete commands inside the nightly job.
- Do not delete a credential or connector during rollback; first inspect
  dependent jobs and any other consumers. Revoke only narrowly approved grants.

## Official references

- Azure Databricks: [Create service credentials](https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/cloud-services/service-credentials)
- Azure Databricks: [Manage service credentials](https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/cloud-services/manage-service-credentials)
- Azure Databricks: [Use service credentials](https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/cloud-services/use-service-credentials)
- Azure CLI: [access-connector commands](https://learn.microsoft.com/en-us/cli/azure/databricks/access-connector)
- Databricks CLI: [credentials commands](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/cli/reference/credentials-commands)
