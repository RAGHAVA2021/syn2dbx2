#!/usr/bin/env bash
# Databricks CLI setup for START_HERE sections 4 and 8.
#   source scripts/env.dev.sh
#   bash scripts/02_databricks_cli_setup.sh inspect
#   CONFIRM=yes bash scripts/02_databricks_cli_setup.sh create-credential   # UC credential administrator
#   CONFIRM=yes bash scripts/02_databricks_cli_setup.sh create-secret-scope  # secrets administrator
#   bash scripts/02_databricks_cli_setup.sh put-webhook-secret   # prompts for the URL; nothing is echoed or stored
#   CONFIRM=yes bash scripts/02_databricks_cli_setup.sh grant-secret-read
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_lib.sh
. "$HERE/_lib.sh"
need_cmd databricks
need BRIDGE_DATABRICKS_PROFILE
P=(--profile "$BRIDGE_DATABRICKS_PROFILE")

case "${1:-inspect}" in
  inspect)
    databricks auth describe "${P[@]}"
    echo "--- service credentials"; databricks credentials list-credentials --purpose SERVICE "${P[@]}"
    echo "--- secret scopes";       databricks secrets list-scopes "${P[@]}"
    ;;
  create-credential)
    need BRIDGE_SERVICE_CREDENTIAL BRIDGE_SUBSCRIPTION_ID BRIDGE_RESOURCE_GROUP BRIDGE_ACCESS_CONNECTOR
    need_cmd az
    connector_id=$(az databricks access-connector show --resource-group "$BRIDGE_RESOURCE_GROUP" \
      --name "$BRIDGE_ACCESS_CONNECTOR" --query id -o tsv)
    [ -n "$connector_id" ] || die "access connector not found; run scripts/01_azure_setup.sh inspect"
    if databricks credentials get-credential "$BRIDGE_SERVICE_CREDENTIAL" "${P[@]}" >/dev/null 2>&1; then
      echo "Credential '$BRIDGE_SERVICE_CREDENTIAL' already exists - inspect it, never overwrite it:"
      databricks credentials get-credential "$BRIDGE_SERVICE_CREDENTIAL" "${P[@]}"
      exit 0
    fi
    confirm "create UC service credential '$BRIDGE_SERVICE_CREDENTIAL' for connector $connector_id" || exit 0
    body=$(printf '{"name":"%s","purpose":"SERVICE","azure_managed_identity":{"access_connector_id":"%s"}}' \
      "$BRIDGE_SERVICE_CREDENTIAL" "$connector_id")
    databricks credentials create-credential "$BRIDGE_SERVICE_CREDENTIAL" --purpose SERVICE --json "$body" "${P[@]}"
    databricks credentials get-credential "$BRIDGE_SERVICE_CREDENTIAL" "${P[@]}"
    echo "Next: render scripts/uc_admin_setup.sql.template (python3 scripts/render_sql.py ... > build/uc_admin_setup.sql) and run its section B (GRANT ACCESS)."
    ;;
  create-secret-scope)
    need BRIDGE_SECRET_SCOPE
    if databricks secrets list-scopes -o json "${P[@]}" | grep -Fq "\"name\": \"$BRIDGE_SECRET_SCOPE\""; then
      echo "scope '$BRIDGE_SECRET_SCOPE' already exists"; exit 0
    fi
    confirm "create Databricks-backed secret scope '$BRIDGE_SECRET_SCOPE' (use the UI for a Key Vault-backed scope)" || exit 0
    databricks secrets create-scope "$BRIDGE_SECRET_SCOPE" "${P[@]}"
    ;;
  put-webhook-secret)
    need BRIDGE_SECRET_SCOPE BRIDGE_WEBHOOK_SECRET_KEY
    [ -t 0 ] || die "run this in an interactive terminal: the CLI prompts for the value so it never enters shell history"
    echo "Paste the Logic App HTTPS URL when prompted."
    databricks secrets put-secret "$BRIDGE_SECRET_SCOPE" "$BRIDGE_WEBHOOK_SECRET_KEY" "${P[@]}"
    ;;
  grant-secret-read)
    need BRIDGE_SECRET_SCOPE BRIDGE_JOB_PRINCIPAL
    confirm "give $BRIDGE_JOB_PRINCIPAL READ on scope $BRIDGE_SECRET_SCOPE" || exit 0
    databricks secrets put-acl "$BRIDGE_SECRET_SCOPE" "$BRIDGE_JOB_PRINCIPAL" READ "${P[@]}"
    databricks secrets list-acls "$BRIDGE_SECRET_SCOPE" "${P[@]}"
    databricks secrets list-secrets "$BRIDGE_SECRET_SCOPE" "${P[@]}"
    ;;
  *) die "unknown step '$1' (inspect | create-credential | create-secret-scope | put-webhook-secret | grant-secret-read)" ;;
esac
